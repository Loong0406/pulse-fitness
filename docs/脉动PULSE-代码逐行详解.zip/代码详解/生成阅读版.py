"""用实际源码与人工讲解生成离线 HTML 和逐文件 Markdown；不修改应用源码。
运行：python docs/代码详解/生成阅读版.py
"""
from pathlib import Path
import hashlib, html, json, re, sys
from xml.etree import ElementTree as ET
sys.stdout.reconfigure(encoding='utf-8')
sys.dont_write_bytecode = True
from 讲解数据 import NOTES, PURPOSE
import 讲解界面, 讲解页面, 讲解训练服务, 讲解测试, 讲解构建

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent

ATTR = {
'layout_width':'布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间',
'layout_height':'布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸',
'id':'控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项',
'orientation':'LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排',
'gravity':'当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向',
'layout_gravity':'当前控件相对父容器的对齐；区别于内部内容的 gravity',
'layout_weight':'在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合',
'layout_margin':'控件四周外边距，不属于控件内部可绘制区域',
'layout_marginTop':'顶部外边距','layout_marginBottom':'底部外边距','layout_marginStart':'语言起始边外边距，中文通常是左边',
'padding':'四边内边距，位于控件边界里面','paddingTop':'顶部内边距','paddingBottom':'底部内边距',
'paddingHorizontal':'左右内边距','paddingVertical':'上下内边距','background':'控件背景，可是颜色、drawable 或主题属性',
'text':'显示文字；@string 引用文字资源，\\n 表示换行','textColor':'文字颜色，可以引用状态颜色列表',
'textSize':'字号，sp 会随系统字体大小变化','fontFamily':'字体族；sans-serif-medium 使用系统中等字重无衬线字体',
'lineSpacingExtra':'每行额外行距','letterSpacing':'字母间距，数值以 em 为相对单位',
'minHeight':'最小高度，防止内容或触控区域过小','minWidth':'最小宽度',
'hint':'输入为空时的占位提示，不是实际输入值','inputType':'输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验',
'imeOptions':'输入法动作按钮类型，例如 actionNext/Done','nextFocusForward':'下一焦点的控件 ID，控制表单跳转顺序',
'maxLength':'允许输入的最大字符数，不代表自动验证内容正确','autofillHints':'向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信',
'buttonTint':'复选框按钮着色','baselineAligned':'是否对齐子文字基线，false 可避免表单左右控件基线约束',
'visibility':'visible 显示、invisible 隐藏但占位、gone 隐藏且不占位','alpha':'透明度，0 全透明，1 不透明',
'src':'ImageView 内容图像资源','importantForAccessibility':'no 表示装饰图不进入无障碍朗读顺序',
'accessibilityLiveRegion':'polite 表示内容更新时等读屏当前播报完成后提示','contentDescription':'读屏使用的文字描述',
'focusable':'是否可获键盘/无障碍焦点','focusableInTouchMode':'触摸模式下也允许获得焦点，可避免默认把焦点给输入框',
'clickable':'是否可点击；实际业务动作仍由 Java 监听器绑定','fillViewport':'ScrollView 内容不足一屏时也撑满可视高度',
'clipToPadding':'是否把绘制裁到内边距，false 可让滚动内容延伸到 padding 区','scrollbars':'滚动条显示方向/none',
'descendantFocusability':'父容器与子控件之间的焦点分配顺序','drawableTop':'放在 TextView 文字上方的图标',
'indeterminate':'进度条是否未知总进度；true 时显示持续加载动画','indeterminateTint':'不确定进度动画颜色',
'progressTint':'已完成进度颜色','progressBackgroundTint':'未完成进度背景颜色',
'textIsSelectable':'是否允许长按选择文字','labelFor':'声明这段文字是哪个输入控件的标签，帮助读屏理解',
'name':'在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名',
'exported':'是否允许其他应用直接启动组件；启动器 Activity 需要 true，内部页面 false',
'theme':'给应用或 Activity 指定主题','windowSoftInputMode':'adjustResize 让软键盘弹出时页面可用区域缩小',
'allowBackup':'是否允许系统备份应用数据，此工程 false','fullBackupContent':'旧备份规则开关，此工程 false',
'dataExtractionRules':'Android 数据提取规则资源，决定云备份及设备迁移内容','icon':'应用图标资源',
'label':'显示给用户的应用/组件名','supportsRtl':'支持从右向左语言布局，配合 start/end 而非写死 left/right',
'networkSecurityConfig':'网络安全规则 XML，debug 同名资源可覆盖 main 规则',
'width':'drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定',
'height':'drawable 自身逻辑高度','viewportWidth':'矢量内部坐标系宽度，与输出 dp 尺寸独立',
'viewportHeight':'矢量内部坐标系高度','fillColor':'路径填充色，transparent 表示不填充',
'strokeColor':'路径描边颜色','strokeWidth':'路径描边粗细，以矢量内部坐标单位计',
'strokeLineCap':'描边端点形状，round 为圆头','strokeLineJoin':'路径拐角连接形状，round 为圆角',
'color':'纯色、描边或 ripple 的颜色，依标签含义使用','radius':'圆角半径',
'topLeftRadius':'仅左上圆角半径','topRightRadius':'仅右上圆角半径','startColor':'渐变起始颜色',
'endColor':'渐变终止颜色','angle':'渐变方向角度','state_enabled':'状态列表条件：true 启用，false 禁用',
'cleartextTrafficPermitted':'是否允许明文 HTTP；main=false，debug 同名覆盖=true',
'domain':'备份数据域，如 sharedpref 为偏好设置，database 为数据库','path':'备份排除路径，. 表示该域所有路径',
'parent':'样式继承的父样式，未在当前样式覆盖的属性沿用父样式','style':'给控件应用一组命名样式，行内属性可覆盖同名样式属性',
'xmlns:android':'声明 android 前缀的命名空间，不会联网下载该 URL','version':'XML 文档声明版本',
'encoding':'XML 文档字符编码，此处 UTF-8',
'colorAccent':'平台组件强调色','windowBackground':'窗口底色','statusBarColor':'状态栏底色',
'navigationBarColor':'系统导航栏底色','windowLightStatusBar':'true 请求深色状态栏图标，false 请求浅色图标；Light 描述背景倾向',
'windowLightNavigationBar':'true 请求深色导航栏图标，false 请求浅色图标','buttonStyle':'应用默认按钮样式',
'windowActionModeOverlay':'上下文操作栏覆盖窗口内容','textAllCaps':'是否把可转换文字自动变大写',
'stateListAnimator':'视图状态动画，@null 关闭默认状态动画','singleLine':'输入/文字保持单行',
'drawablePadding':'复合图标与文字之间的间隔','colorBackground':'平台主题背景色','colorBackgroundFloating':'浮动窗口背景色',
'textColorPrimary':'主题主要文字颜色','textColorSecondary':'主题次要文字颜色','textColorHint':'输入提示文字颜色',
}
ELEMENT = {
'FrameLayout':'层叠容器，子视图可叠放','LinearLayout':'按方向排列子视图的容器','ScrollView':'纵向滚动容器，只能有一个直接子视图',
'HorizontalScrollView':'横向滚动容器','TextView':'显示文字','EditText':'接受用户输入','Button':'可点击按钮','CheckBox':'可勾选开关',
'ImageView':'显示图像','ImageButton':'使用图像作为内容的可点击按钮','Spinner':'下拉单选控件','ProgressBar':'显示确定或不确定进度','View':'通用视图，可用作分隔线',
'resources':'values 资源集合根节点','style':'可复用的主题/控件属性集合','item':'样式属性或状态列表分支','color':'命名颜色资源',
'string':'可翻译文字资源','vector':'Android 矢量图根节点','path':'矢量绘制路径','shape':'形状 drawable',
'solid':'形状填充','corners':'形状圆角','stroke':'形状边框','gradient':'渐变填充','ripple':'系统点击波纹背景',
'selector':'按状态顺序匹配资源，先匹配的分支优先','manifest':'Android 应用清单根节点','uses-permission':'声明应用所需权限',
'application':'声明 Application 和默认应用属性','activity':'声明可启动的页面组件','intent-filter':'声明组件能处理的隐式 Intent',
'action':'Intent 动作，MAIN 表示主入口','category':'Intent 分类，LAUNCHER 使入口出现在桌面启动器',
'network-security-config':'应用网络安全配置','base-config':'网络安全基础规则','data-extraction-rules':'系统数据提取规则',
'cloud-backup':'云备份范围','device-transfer':'换设备迁移范围','exclude':'从指定域排除指定路径',
}
PATH_COMMAND = {'M':('移动起点',2),'L':('直线到',2),'H':('水平线到',1),'V':('垂直线到',1),
'C':('三次贝塞尔曲线：两控制点、终点',6),'S':('平滑三次曲线：第二控制点、终点',4),
'Q':('二次曲线：控制点、终点',4),'T':('平滑二次曲线到',2),
'A':('椭圆弧：x/y半径、旋转角、大弧标志、顺时针标志、终点x/y',7),'Z':('闭合到本子路径起点',0)}

def value_note(value):
    if value.startswith('@+id/'): return '创建 ID '+value.split('/')[-1]+'。'
    if value.startswith('@id/'): return '引用控件 ID '+value.split('/')[-1]+'。'
    if value.startswith('@null'): return '显式置空，关闭或去除该项默认值。'
    if value.startswith('@'): return '引用资源 '+value+'，实际值见同名资源定义；night/v27 等目录可能覆盖。'
    if value.startswith('?'): return '从当前主题解析属性 '+value+'。'
    if value in ('match_parent','wrap_content'): return {'match_parent':'填满父布局分配的可用空间。','wrap_content':'以内容测量所需尺寸。'}[value]
    if re.fullmatch('#[0-9a-fA-F]+',value):
        return '十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。'
    if value.endswith('dp'): return '尺寸 '+value+'，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。'
    if value.endswith('sp'): return '字号 '+value+'，会响应用户系统字体缩放。'
    return ''

def path_note(value):
    result=[]
    for command,args in re.findall(r'([A-Za-z])([^A-Za-z]*)',value):
        info=PATH_COMMAND.get(command.upper())
        if not info: raise ValueError('未知矢量命令 '+command)
        nums=re.findall(r'-?\d*\.?\d+(?:[eE][+-]?\d+)?',args)
        meaning,size=info
        if size and len(nums)%size: raise ValueError('路径参数数量异常 '+value)
        groups=[','.join(nums[i:i+size]) for i in range(0,len(nums),size)] if size else []
        result.append(command+'：'+meaning+('（相对当前位置）' if command.islower() else '（绝对坐标）')+(' ['+'；'.join(groups)+']' if groups else ''))
    return '路径按以下顺序执行：'+'；'.join(result)+'。M 后若有多对坐标，首对移动、其余按直线处理。'

def xml_note(line):
    if not line.strip(): return '空行，只分隔内容，不产生资源或运行行为。'
    if line.lstrip().startswith('<!--'): return 'XML 注释：仅给维护者阅读，不生成界面；此处说明调试阶段允许本地 HTTP。'
    parts=[]
    for match in re.finditer(r'<([^>]+)>',line):
        body=match[1].strip()
        if body.startswith('?xml'): parts.append('声明 XML 版本及 UTF-8 文本编码。');continue
        if body.startswith('/'): parts.append('关闭 '+body[1:]+' 元素，结束它的嵌套作用域。');continue
        tag=body.split()[0].rstrip('/')
        meaning=ELEMENT.get(tag)
        if not meaning and tag.startswith('com.pulse.fitness.ui.widget.'):
            meaning='自定义原生控件 '+tag.split('.')[-1]+'，实际绘制由同名 Java 类实现'
        if not meaning: raise ValueError('未解释 XML 标签 '+tag)
        parts.append('元素 '+tag+'：'+meaning+'。')
        attrs=re.findall(r'([\w:]+)\s*=\s*"([^"]*)"',body)
        for key,value in attrs:
            if key=='android:pathData': parts.append('android:pathData='+value+'。'+path_note(value));continue
            lookup=key if key in ('xmlns:android',) else key.removeprefix('android:')
            if lookup not in ATTR: raise ValueError('未解释 XML 属性 '+key)
            parts.append(key+'="'+value+'"：'+ATTR[lookup]+'。'+value_note(value))
        if tag=='item':
            name=dict(attrs).get('name','').removeprefix('android:')
            if name:
                if name not in ATTR: raise ValueError('未解释样式项 '+name)
                text=re.match(r'([^<]*)',line[match.end():])[1]
                parts.append('该样式项 '+name+'：'+ATTR[name]+'；值为 '+text+'。'+value_note(text))
        if tag in ('string','color'):
            text=re.match(r'([^<]*)',line[match.end():])[1]
            parts.append('资源内容为“'+text+'”。'+value_note(text))
            placeholders=re.findall(r'%\d*\$?[sd]',text)
            if placeholders: parts.append('格式占位符 '+','.join(placeholders)+' 由 Java getString(id,参数) 在运行时替换；s 是文本，d 是整数。')
        if body.endswith('/'): parts.append('该元素以 /> 自闭合，没有嵌套子节点。')
    return '\n'.join(parts)

def java_note(p,number,line):
    name=p.stem;s=line.strip()
    if number in NOTES.get(name,{}): return NOTES[name][number], '人工业务讲解'
    if not s:return '空行，仅用于分隔成员或语句，不执行任何操作。','语法结构'
    if s.startswith('package '): return '声明本文件所属包 '+s[8:-1]+'；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。','语法结构'
    if s.startswith('import '):
        target=s[7:-1]; static=target.startswith('static ')
        return ('静态导入 ' if static else '导入类型命名空间 ')+target.removeprefix('static ')+('，后面可直接写枚举项或断言方法名。' if static else '，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。'),'语法结构'
    if s.startswith(('/**','//','*','*/')):
        special={
        ('MainActivity',65):'桥接输出实现：同一个 Android 文档 Sink 可以接收任意导出格式的文本。',
        ('PlanScreen',36):'迭代器用法：页面通过聚合提供的遍历接口访问日程，不依赖内部集合具体实现。',
        ('LocalPlanGenerator',20):'注释表达轮换相邻训练重点并排除高冲击的意图；真实实现是按训练日偏移三动作，不是完整肌群恢复算法。',
        ('WeekPlan',20):'原型复制：复制日程与处方聚合边界，并赋予新计划身份，不复用原计划 ID。',
        ('Repositories',10):'抽象工厂：同一后端创建一致的仓库产品族。',
        ('ExerciseQuery',5):'定义文法：OR 是多个 AND 分支用 | 连接；每个 AND 是多个 term 用 & 连接，因此 AND 优先。',
        ('ExerciseQuery',6):'term 支持自由文本、group:值、equipment:值。这不是可以执行任意程序的表达式。',
        ('CompatibleLlmAdapter',29):'昵称和性别不用于这里选择允许动作，向上游模型发请求前将删除这两个字段。',
        ('CompatibleLlmAdapter',62):'JSON Schema 希望在上游生成阶段限制结构与七个训练/恢复位置；实际支持取决于上游。',
        ('CompatibleLlmAdapter',63):'每组训练最多 45 秒、休息 45 秒，配合组数和动作数上限，使 schema 预算不超可用时长。',
        ('CompatibleLlmAdapter',75):'为计时和计次两种动作建立不同数量范围，避免把 30 秒误当 30 次。',
        ('ServerTest',37):'使用实际第一个动作 ID 构造非法替换，不假设策略排序一定把 wall_push 排在首位。',
        }
        return '源码注释，不参与执行。'+special.get((name,number),PURPOSE.get(name,'')),'语法结构'
    if re.fullmatch(r'[{};\s]+',s):return '关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。','语法结构'
    if s=='else {':return '前面的 if 条件不成立时才进入此分支；这里表示已经配置生成器，将尝试模型生成。','语法结构'
    if s=='});':return '结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。','语法结构'
    if re.match(r'(?:public |private |protected |static |final |abstract )*(class|interface|enum)\s',s) and s.endswith('{'):
        parent=re.search(r'extends ([\w<>.]+)',s);interfaces=re.search(r'implements (.+?)\s*\{',s)
        return '定义 '+s.split('{')[0].strip()+'。'+('继承 '+parent[1]+' 的实现与扩展点。' if parent else '')+('实现 '+interfaces[1]+' 契约。' if interfaces else '')+'本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。','语法结构'
    if name=='ExerciseCatalog' and 'add(m,new Exercise(' in s:
        args=s.split('new Exercise(',1)[1].rsplit('));',1)[0]
        tokens=re.findall(r'"(?:[^"\\]|\\.)*"|\b(?:BODYWEIGHT|DUMBBELL|GYM|true|false)\b',args)
        vals=[json.loads(v) if v.startswith('"') else v for v in tokens]
        labels=['稳定ID','中文名','部位','器械','是否计时','膝负荷','背负荷','冲击','要领']
        return '创建并注册一个共享动作；'+ '；'.join(k+'='+str(v) for k,v in zip(labels,vals))+'；步骤依次为 '+ ' → '.join(vals[9:])+'。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。','目录数据'
    raise ValueError(f'缺逐行解释 {p.relative_to(ROOT)}:{number}: {s}')

def config_note(rel,n,line):
    s=line.strip()
    key=rel if rel in NOTES else Path(rel).name
    if n in NOTES.get(key,{}):return NOTES[key][n],'人工配置讲解'
    if not s:return '空行，仅帮助阅读，不改变配置。','语法结构'
    if s.startswith(('#','//')):return '配置注释，不执行；正文记录该项的适用环境或工具生成来源。','语法结构'
    if re.fullmatch(r'[{}\s]+',s):return '结束当前配置块/条件/循环，按最近未关闭的花括号配对。','语法结构'
    if rel=='app/proguard-rules.pro':return '此文件当前只有注释，没有自定义压缩混淆规则；release 的 minify 目前关闭。','配置说明'
    if rel.endswith('gradle-daemon-jvm.properties'):
        k,v=s.split('=',1)
        if k=='toolchainVersion':return '要求运行 Gradle 守护进程的 JDK 主版本为 '+v+'，优先于普通 JAVA_HOME 选择；业务源码目标仍为 Java 17。','配置说明'
        platform=k.removeprefix('toolchainUrl.')
        return '在 '+platform+' 平台缺匹配 JDK 时的工具链下载 URL；这是 Gradle 自动生成记录。本次讲解不访问或下载它；本机已有匹配 JBR 可直接用。','配置说明'
    if rel.endswith('gradle-wrapper.properties'):
        k,v=s.split('=',1)
        meanings={'distributionBase':'下载解压的 Gradle 分发根目录，GRADLE_USER_HOME 是用户缓存目录',
        'distributionPath':'分发版本在根目录下的相对子目录','distributionSha256Sum':'下载 zip 的 SHA-256 校验值，帮助检测文件是否被篡改或损坏',
        'distributionUrl':'wrapper 选择的 Gradle 9.5.0 二进制分发地址，https\\: 是 properties 转义',
        'networkTimeout':'wrapper 网络操作超时，单位毫秒','validateDistributionUrl':'是否校验分发 URL',
        'zipStoreBase':'下载 zip 的缓存根目录','zipStorePath':'zip 在缓存根下的相对子目录'}
        if k in meanings:return k+'='+v+'：'+meanings[k]+'。','配置说明'
    if rel.endswith('.txt'):return '这行是打包进 APK assets 的用户可读文本，不是 Java 指令；AuthLegalActivity 按 UTF-8 逐行读取并显示。它描述的本机演示及数据范围以页面当前文字为准。','协议文本'
    raise ValueError(f'缺配置解释 {rel}:{n}: {s}')

def sources():
    paths=[]
    for base in ('app','core','server'):
        paths.extend((ROOT/base/'src').rglob('*.java'))
        paths.extend((ROOT/base/'src').rglob('*.xml'))
    paths.extend((ROOT/'app/src/main/assets').glob('*.txt'))
    paths.extend(ROOT.glob('*.kts'))
    paths.extend(ROOT.glob('*.properties'))
    paths.extend((ROOT/'gradle').glob('*.properties'))
    paths.extend((ROOT/'gradle/wrapper').glob('*.properties'))
    paths.extend((ROOT/'scripts').glob('*.ps1'))
    paths.extend(ROOT/base/'build.gradle.kts' for base in ('app','core','server'))
    paths.extend([ROOT/'app/proguard-rules.pro',ROOT/'docker-compose.yml',ROOT/'server/Dockerfile'])
    return sorted(set(paths),key=lambda p:p.relative_to(ROOT).as_posix())

def build():
    documents=[];missing=[]
    for p in sources():
        rel=p.relative_to(ROOT).as_posix(); lines=p.read_text(encoding='utf-8-sig').splitlines();rows=[]
        if p.suffix=='.xml': ET.fromstring(p.read_text(encoding='utf-8-sig'))
        for n,line in enumerate(lines,1):
            try:
                if p.suffix=='.java':explanation,kind=java_note(p,n,line)
                elif p.suffix=='.xml':explanation,kind=xml_note(line),'XML逐元素逐属性'
                else:explanation,kind=config_note(rel,n,line)
                if not explanation: raise ValueError('空解释 '+rel+':'+str(n))
                rows.append({'n':n,'code':line,'text':explanation,'kind':kind})
            except ValueError as failure:missing.append(str(failure))
        purpose=PURPOSE.get(p.stem,PURPOSE.get(rel,PURPOSE.get(p.name,'')))
        if not purpose:
            if '/res/' in rel:purpose='Android '+ ('调试覆盖资源' if '/debug/' in rel else '界面/主题/图形资源')+'；按每行元素及属性展开解释。'+('此限定目录仅在深色模式匹配时覆盖同名默认资源。' if 'night' in rel else '')+('v27 表示 API 27 及以上才参与资源匹配。' if 'v27' in rel else '')
            elif rel.endswith('.txt'):purpose='APK 内置协议文字，通过资产流读取，不会当程序执行。'
            elif p.name=='AndroidManifest.xml':purpose='Android 系统查找组件、权限、主题及桌面入口的清单，启动入口是 LoginActivity。'
            else:purpose='构建工具读取的工程配置，逐行说明其取值和实际影响。'
        documents.append({'path':rel,'title':p.name,'purpose':purpose,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows})
    if missing:
        print('\n'.join(missing));raise SystemExit(f'尚有 {len(missing)} 行需要补写；未覆盖行不会被通用句子隐藏。')
    return documents

def write(documents):
    folder=HERE/'逐文件';folder.mkdir(exist_ok=True)
    guide=(HERE/'先读这里.md').read_text(encoding='utf-8')
    index=['# 全项目逐行代码详解索引','',f'源码快照：2026-10-23。覆盖 {len(documents)} 个文件，{sum(len(d["rows"]) for d in documents)} 行，含空行与结构行。','',
    '先读 [学习路线与完整流程](先读这里.md)，再用浏览器打开 [离线阅读版](index.html)。每个分卷保留源码原行与行号，没有重新格式化业务文件。','']
    book=[guide,'\n# 逐文件逐行正文\n']
    for i,d in enumerate(documents,1):
        slug=f'{i:03d}-{d["title"]}.md';d['doc']=slug
        text=[f'# {d["path"]}', '',d['purpose'],'',f'原文件 SHA-256：`{d["sha256"]}`。行号仅对应此快照；修改源码后应重新核对。','',
              f'共 {len(d["rows"])} 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。','']
        lang='java' if d['path'].endswith('.java') else 'xml' if d['path'].endswith('.xml') else 'text'
        for row in d['rows']:
            text.extend([f'## 第 {row["n"]} 行', '',f'```{lang}',row['code'] if row['code'] else '// （原文件此行为空）' if lang=='java' else '（原文件此行为空）','```','',row['text'],''])
        content='\n'.join(text)
        (folder/slug).write_text(content,encoding='utf-8')
        index.append(f'{i}. [{d["path"]}](逐文件/{slug}) — {len(d["rows"])} 行')
        book.append(content)
    (HERE/'目录.md').write_text('\n'.join(index),encoding='utf-8')
    (HERE/'全项目逐行详解.md').write_text('\n\n'.join(book),encoding='utf-8')
    payload=json.dumps(documents,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    template=(HERE/'阅读器模板.html').read_text(encoding='utf-8')
    # 内容经 HTML 转义，不将源代码/说明解释为 HTML 或 JavaScript。
    guide_html=render_markdown(guide)
    output=template.replace('@@DATA@@',payload).replace('@@GUIDE@@',guide_html)
    (HERE/'index.html').write_text(output,encoding='utf-8')
    report={'snapshot':'2026-10-23','files':len(documents),'lines':sum(len(d['rows']) for d in documents),'explained':sum(len(d['rows']) for d in documents),
        'business_notes':sum(r['kind']=='人工业务讲解' for d in documents for r in d['rows']),
        'missing':0,'scope':'app/core/server Java、测试、XML、assets、Gradle配置、PowerShell脚本、Docker配置；不含工具生成物、第三方wrapper脚本、二进制及文档自身',
        'sources':[{'path':d['path'],'lines':len(d['rows']),'sha256':d['sha256']} for d in documents]}
    (HERE/'覆盖核对.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='sources'},ensure_ascii=False,indent=2))

def render_markdown(text):
    """只处理这份离线导读使用的 Markdown 子集，内容全部先转义。"""
    def inline(s):
        s=html.escape(s)
        s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
        return re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s)
    output=['<article class="intro">'];lines=text.splitlines();i=0
    while i<len(lines):
        line=lines[i]
        if not line.strip():i+=1;continue
        if line.startswith('```'):
            code=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
            output.append('<pre class="source">'+html.escape('\n'.join(code))+'</pre>');i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):
                cells=[x.strip() for x in lines[i].strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',c) for c in cells):rows.append(cells)
                i+=1
            output.append('<div class="table-scroll"><table>')
            for n,cells in enumerate(rows):
                tag='th' if n==0 else 'td';output.append('<tr>'+''.join('<'+tag+'>'+inline(c)+'</'+tag+'>' for c in cells)+'</tr>')
            output.append('</table></div>');continue
        heading=re.match(r'^(#{1,4}) (.*)',line)
        if heading:
            level=min(4,len(heading[1])+1);output.append(f'<h{level}>'+inline(heading[2])+f'</h{level}>');i+=1;continue
        if re.match(r'^\d+\. ',line):
            output.append('<ol>')
            while i<len(lines) and re.match(r'^\d+\. ',lines[i]):output.append('<li>'+inline(re.sub(r'^\d+\. ','',lines[i]))+'</li>');i+=1
            output.append('</ol>');continue
        output.append('<p>'+inline(line)+'</p>');i+=1
    output.append('</article>');return '\n'.join(output)

if __name__=='__main__':
    docs=build()
    if '--check' in sys.argv:print('覆盖检查通过：',len(docs),'个文件；',sum(len(d['rows']) for d in docs),'行。')
    else:write(docs)
