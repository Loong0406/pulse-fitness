from 讲解数据 import add

add('settings.gradle.kts', 'Gradle 项目入口，决定仓库和包含哪些模块；在 Android Studio 应打开包含它的 fitness-sever 文件夹。', '''
1 为插件解析配置 Google、MavenCentral、Gradle 插件门户；与普通依赖仓库分开。
2 开始配置所有模块共用的依赖解析规则。
3 禁止子模块自行声明仓库，依赖来源统一在这里管理。
4 业务依赖从 Google 和 MavenCentral 查找。
5 结束依赖解析配置块。
6 工程逻辑名 PulseFitness，影响 IDE 项目显示和模块命名。
7 总是包含纯 Java 核心模块 core 和可选 HTTP 网关 server。
8 没有传 -PserverOnly=true 时才包含 app；服务器机器可只构建 Java 模块，不要求 Android SDK。
''')
add('build.gradle.kts', '根工程只用 base 插件提供基础生命周期，不把整个工程误当一个 Android 应用。', '''
1 应用 Gradle base 插件；Android application 插件在 app/build.gradle.kts 中配置。
''')
add('app/build.gradle.kts', 'Android 模块构建配置。kts 是 Kotlin 构建脚本，不代表业务源码改成 Kotlin，业务仍为 Java。', '''
1 应用 Android application 插件 9.3.0，生成 APK 构建任务。
2 开始 Android 扩展配置块。
3 资源 R 和 BuildConfig 所属命名空间，不等同安装包标识但此处二者相同。
4 编译时使用 API 37 SDK，决定可以引用哪些平台 API；不代表只能装 Android 37。
5 开始各构建变体共用的默认配置。
6 应用安装身份 com.pulse.fitness，改变会被系统视为另一个应用。
7 最低 API 26，即 Android 8.0；更低系统不安装。
8 目标 API 37，系统按该级别启用相应兼容行为。
9 整数版本号 2，用于系统判断更新先后。
10 用户可见版本名称 1.1.0。
11 结束默认配置。
12 定义调试与发布变体。
13 保留默认 debug 行为，可调试并使用本地调试签名。
14 发布配置块开始。
15 发布暂时不启用代码压缩混淆。
16 指定默认优化规则和项目规则文件；只有启用对应收缩功能后才有实际混淆效果。
17 结束发布块。
18 结束变体配置块。
19 生成 BuildConfig，代码读取 DEBUG 区分调试和发布行为。
20 Java 编译选项块。
21 Java 源语言级别 17。
22 Java 目标字节码兼容级别 17；Android 还会经过 D8 转为 DEX，不是把 JVM class 原样运行在手机。
23 结束 Java 配置。
24 禁用三类 Lint 提示，不意味着所有问题均不存在；未禁用的检查仍执行。
25 结束 Android 配置块。
26 app 编译运行依赖 core 模块，不依赖 server 模块；网关是独立进程。
27 所有 Java 编译任务显式 UTF-8，保证中文源码按正确编码读取。
''')
add('core/build.gradle.kts', '纯 Java 核心库，独立于 Android，可快速运行领域单元测试。', '''
1 使用 java-library 插件，提供可被其他模块依赖的库。
2 开始 Java 配置。
3 Java 源语法级别 17。
4 目标字节码级别 17。
5 结束 Java 配置。
6 对每个 Java 编译任务使用 UTF-8。
7 开始依赖声明。
8 api 暴露 Gson 2.11.0，使依赖 core 的模块也能使用它。
9 JUnit 4.13.2 只用于测试，不打入生产运行依赖。
10 结束依赖块。
''')
add('server/build.gradle.kts', '独立 Java 应用模块，生成带依赖启动目录，可选运行，不自动部署模型。', '''
1 application 插件提供 run 和 installDist 等任务。
2 开始 Java 配置。
3 源语言级别 17。
4 目标字节码级别 17。
5 结束 Java 配置。
6 设置 Java 可执行入口类，installDist 生成的启动器调用它。
7 所有 Java 源码 UTF-8。
8 开始依赖配置。
9 服务器复用 core 的领域模型、规则、JSON 和校验器。
10 测试依赖 JUnit，不属于服务生产运行包。
11 结束依赖声明。
''')
add('gradle.properties', '工程级 Gradle 行为。编码设置用于当前 Windows 中文路径环境，源码编译编码仍各模块显式 UTF-8。', '''
3 Gradle JVM 最大堆 2048MiB；COMPAT 使用平台兼容默认字符编码，处理 Windows 中文路径参数文件。
4 允许 Gradle 并行执行可独立的项目任务，不代表业务线程自动变多。
5 启用 AndroidX 依赖体系支持；本项目页面主要使用平台原生 View。
6 使用非传递 R 类，各模块只生成自己的资源索引，减少资源耦合。
7 绕过 Android 插件对工程路径字符的检查，供本机中文目录使用，不修复所有第三方工具的路径兼容问题。
10 启用支持此属性的 Gradle 工具并行同步；实际能力取决于运行版本。
''')
add('local.properties', '当前电脑专用 Android SDK 路径，换电脑可由 Android Studio 重新生成。', '''
1 sdk.dir 指向现有 Android SDK；D\\: 中反斜杠转义 properties 的冒号，空格属于路径一部分。此设置不会新建盘符。
''')
add('scripts/Build.ps1', '统一构建验证脚本；只讲解而不在本次文档工作中执行构建或安装。', '''
1 定义可选开关 -Offline，传入时只使用已有缓存。
2 点调用 Common.ps1，让其中 JDK 选择及 ProjectRoot 变量在当前脚本作用域生效。
3 Gradle 任务数组依次指定核心/服务测试、Android Lint、debug APK、服务分发，plain 输出便于终端阅读。
4 -Offline 为 true 就追加 --offline；缺依赖缓存时会失败，不会凭空生成依赖。
5 & 调用本工程 wrapper；@arguments 将数组每项作为独立参数传入。
6 非零退出码立即 throw，防止把失败构建当成功交付。
7 创建 deliverables 文件夹，存在时 -Force 不报错，丢弃命令返回对象。
8 将生成的 debug APK 复制到交付路径，同名覆盖；这不会自动安装到手机。
9 打印交付文件相对路径。
''')
add('scripts/Common.ps1', '构建脚本共用的本机 JDK 选择，不修改系统全局 JAVA_HOME，只影响当前进程及其子进程。', '''
1 PowerShell 非终止错误提升为终止行为，便于脚本失败时停止。
2 从脚本目录的上一级计算项目根目录。
3 定义选择本项目 JDK 的函数，定义时不会立即执行函数体。
4 未发现守护进程 JDK 条件时默认最低 21。
5 拼出 Gradle daemon JVM 条件文件路径。
6 文件存在且匹配 toolchainVersion=数字时，提取版本号；(?m) 让 ^ 匹配每行行首。
7 候选数组先放当前进程 JAVA_HOME。
8 查 PATH 的 java.exe，找不到时静默继续。
9 从 java.exe 路径上溯两级取得 JDK 根目录。
10 拼出 Adoptium 安装目录。
11 若存在，枚举其直接子目录作为 JDK 候选，不递归修改文件。
12 再添加本机 Android Studio 和默认安装路径下的 jbr 候选。
13 逐个检查候选。
14 空候选跳过，防止 Join-Path 空参数错误。
15 每个 JDK 根目录下的 release 文件记录版本信息。
16 只有 release 文件存在才检查。
17 读取整个 release 文件文本。
18 从 JAVA_VERSION 中提取主版本号。
19 将捕获字符串转整数。
20 有 daemon 条件文件必须精确匹配主版本；没有则允许大于等于默认最低版本。
21 版本满足且 bin/java.exe 存在就设置当前进程 JAVA_HOME 并返回，首个有效候选优先。
25 没找到匹配 JDK 抛出明确错误，不静默使用错误版本。
27 实际执行 JDK 选择函数。
28 把当前工作目录切到项目根，后续相对路径统一。
''')
add('scripts/Start-Server.ps1', '可选启动 Java 网关，不下载或启动任何大模型；默认模型地址为空。', '''
1 定义可选模型地址、展示模型名、端口、回环监听地址，以及 LocalOnly 开关。
2 导入公共路径和 JDK 选择逻辑。
3 以 serverOnly 构建服务分发，不把 Android 模块纳入本次构建。
4 构建失败立即停止。
5 本机运行资料保存在工程内 .runtime。
6 创建目录；本脚本没有创建盘符的操作。
7 当前环境未设置 APP_TOKEN 才生成或复用本地开发令牌。
8 本地开发令牌文件路径。
9 文件存在就读入环境变量，后面不把实际令牌写到日志。
10 不存在则进入生成分支。
11 创建密码学随机数生成器。
12 准备 24 字节数组。
13 填充随机字节并释放随机源资源。
14 转成无短横线、小写十六进制，24 字节变 48 字符。
15 将开发令牌写入本机文件；这是开发便利机制，不是部署后的密钥管理系统。
18 设置传给 Java 子进程的监听地址、端口和模型名环境变量。
19 LocalOnly 则清空 AI_BASE_URL，否则用用户传入地址；两者都不会启动模型。
20 打印如何从本机文件取开发令牌及 Ctrl+C 停止说明，不输出令牌本身。
21 调用已选 JDK，classpath 指向服务依赖 jar，前台运行 FitnessServer；窗口关闭或 Ctrl+C 会结束服务。
''')
add('docker-compose.yml', '可选容器配置，仅定义 Java 网关；本次只是解释，不执行 docker compose。', '''
2 声明 compose 服务集合。
3 服务名称 server。
4 镜像通过本地 Dockerfile 构建。
5 构建上下文为项目根目录。
6 指定 server/Dockerfile。
7 除非人为停止，否则由容器运行器按策略重启服务。
8 端口映射列表开始。
9 宿主仅监听 127.0.0.1:8080，转到容器 8080；外部机器不能直接连此宿主绑定。
10 传入容器的环境变量开始。
11 容器内部监听 0.0.0.0，以便转发能到达；与宿主绑定范围是两回事。
12 容器 Java 服务端口 8080。
13 从外部环境或 .env 读取 APP_TOKEN；:? 在缺失/空时提示错误，不自动生成。
14 可选上游模型地址，未设则空，服务生成本地规则计划。
15 模型展示名未设时用 configured-model。
16 可选上游密钥，未设则空；这不是手机网关令牌。
''')
add('server/Dockerfile', '两阶段镜像：先编译 Java 分发，再将运行结果复制进较小 JRE 镜像；不包含模型。', '''
1 构建阶段使用 Temurin JDK 21，阶段名 build；若保留工程 daemon JDK25 条件，wrapper 仍可能下载匹配工具链，离线容器需提前准备。
2 构建工作目录 /workspace。
3 复制 wrapper 启动脚本和根构建文件，尚未复制 Android 模块。
4 复制 Gradle wrapper 目录及 daemon 条件文件。
5 复制 core 模块。
6 复制 server 模块。
7 给 Unix wrapper 执行权，再仅构建 Java 服务分发；--no-daemon 避免保留长期守护进程。
9 运行阶段使用 JRE 21，Java 17 目标字节码可运行在更高版本 JRE。
10 运行工作目录 /app。
11 从 build 阶段复制完整服务分发，包含启动器及依赖。
12 默认容器内监听全部地址和 8080 端口；非回环监听要求有效长度令牌。
13 以数值用户 10001 而非 root 运行。
14 声明使用 8080，不代表自动开放宿主端口。
15 容器主进程运行分发启动脚本。
''')
