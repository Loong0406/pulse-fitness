# app/build.gradle.kts

Android 模块构建配置。kts 是 Kotlin 构建脚本，不代表业务源码改成 Kotlin，业务仍为 Java。

原文件 SHA-256：`e9aba8f0b0e5947fe0a64715cfa4aa2ba8a5b69eed3f4ccfbed0d17f35de681e`。行号仅对应此快照；修改源码后应重新核对。

共 27 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
plugins { id("com.android.application") version "9.3.0" }
```

应用 Android application 插件 9.3.0，生成 APK 构建任务。

## 第 2 行

```text
android {
```

开始 Android 扩展配置块。

## 第 3 行

```text
    namespace = "com.pulse.fitness"
```

资源 R 和 BuildConfig 所属命名空间，不等同安装包标识但此处二者相同。

## 第 4 行

```text
    compileSdk { version = release(37) }
```

编译时使用 API 37 SDK，决定可以引用哪些平台 API；不代表只能装 Android 37。

## 第 5 行

```text
    defaultConfig {
```

开始各构建变体共用的默认配置。

## 第 6 行

```text
        applicationId = "com.pulse.fitness"
```

应用安装身份 com.pulse.fitness，改变会被系统视为另一个应用。

## 第 7 行

```text
        minSdk = 26
```

最低 API 26，即 Android 8.0；更低系统不安装。

## 第 8 行

```text
        targetSdk = 37
```

目标 API 37，系统按该级别启用相应兼容行为。

## 第 9 行

```text
        versionCode = 2
```

整数版本号 2，用于系统判断更新先后。

## 第 10 行

```text
        versionName = "1.1.0"
```

用户可见版本名称 1.1.0。

## 第 11 行

```text
    }
```

结束默认配置。

## 第 12 行

```text
    buildTypes {
```

定义调试与发布变体。

## 第 13 行

```text
        debug { }
```

保留默认 debug 行为，可调试并使用本地调试签名。

## 第 14 行

```text
        release {
```

发布配置块开始。

## 第 15 行

```text
            isMinifyEnabled = false
```

发布暂时不启用代码压缩混淆。

## 第 16 行

```text
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
```

指定默认优化规则和项目规则文件；只有启用对应收缩功能后才有实际混淆效果。

## 第 17 行

```text
        }
```

结束发布块。

## 第 18 行

```text
    }
```

结束变体配置块。

## 第 19 行

```text
    buildFeatures { buildConfig = true }
```

生成 BuildConfig，代码读取 DEBUG 区分调试和发布行为。

## 第 20 行

```text
    compileOptions {
```

Java 编译选项块。

## 第 21 行

```text
        sourceCompatibility = JavaVersion.VERSION_17
```

Java 源语言级别 17。

## 第 22 行

```text
        targetCompatibility = JavaVersion.VERSION_17
```

Java 目标字节码兼容级别 17；Android 还会经过 D8 转为 DEX，不是把 JVM class 原样运行在手机。

## 第 23 行

```text
    }
```

结束 Java 配置。

## 第 24 行

```text
    lint { disable += setOf("HardcodedText", "SetTextI18n", "OldTargetApi") }
```

禁用三类 Lint 提示，不意味着所有问题均不存在；未禁用的检查仍执行。

## 第 25 行

```text
}
```

结束 Android 配置块。

## 第 26 行

```text
dependencies { implementation(project(":core")) }
```

app 编译运行依赖 core 模块，不依赖 server 模块；网关是独立进程。

## 第 27 行

```text
tasks.withType<JavaCompile>().configureEach { options.encoding = "UTF-8" }
```

所有 Java 编译任务显式 UTF-8，保证中文源码按正确编码读取。
