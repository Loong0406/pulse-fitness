# app/proguard-rules.pro

构建工具读取的工程配置，逐行说明其取值和实际影响。

原文件 SHA-256：`a76d9ae0ee107c54cd3b06677cd7be604da1a3702202909c77c4dc4fffa42991`。行号仅对应此快照；修改源码后应重新核对。

共 2 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
# JSON is mapped explicitly through JsonCodec. Domain fields are kept for local session snapshots.
```

配置注释，不执行；正文记录该项的适用环境或工具生成来源。

## 第 2 行

```text
-keep class com.pulse.core.** { *; }
```

此文件当前只有注释，没有自定义压缩混淆规则；release 的 minify 目前关闭。
