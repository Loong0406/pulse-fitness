# app/src/debug/res/xml/network_security_config.xml

Android 调试覆盖资源；按每行元素及属性展开解释。

原文件 SHA-256：`a530079503822a6e4d570cd77d190bf3ce677feeccd9f0f2ca235150693e22ba`。行号仅对应此快照；修改源码后应重新核对。

共 3 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<?xml version="1.0" encoding="utf-8"?>
```

声明 XML 版本及 UTF-8 文本编码。

## 第 2 行

```xml
<!-- Local development only. Release requires HTTPS. -->
```

XML 注释：仅给维护者阅读，不生成界面；此处说明调试阶段允许本地 HTTP。

## 第 3 行

```xml
<network-security-config><base-config cleartextTrafficPermitted="true" /></network-security-config>
```

元素 network-security-config：应用网络安全配置。
元素 base-config：网络安全基础规则。
cleartextTrafficPermitted="true"：是否允许明文 HTTP；main=false，debug 同名覆盖=true。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 network-security-config 元素，结束它的嵌套作用域。
