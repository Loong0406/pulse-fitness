# app/src/main/AndroidManifest.xml

Android 系统查找组件、权限、主题及桌面入口的清单，启动入口是 LoginActivity。

原文件 SHA-256：`0b2199660382d9df629d798a5f1f05d7a5d6e9f67461d85d2286e5f80b34b214`。行号仅对应此快照；修改源码后应重新核对。

共 12 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<?xml version="1.0" encoding="utf-8"?>
```

声明 XML 版本及 UTF-8 文本编码。

## 第 2 行

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
```

元素 manifest：Android 应用清单根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。

## 第 3 行

```xml
    <uses-permission android:name="android.permission.INTERNET" />
```

元素 uses-permission：声明应用所需权限。
android:name="android.permission.INTERNET"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
    <application android:name=".PulseApplication" android:allowBackup="false" android:fullBackupContent="false" android:dataExtractionRules="@xml/data_extraction_rules" android:icon="@drawable/ic_launcher" android:label="脉动 PULSE" android:theme="@style/AppTheme" android:supportsRtl="true" android:networkSecurityConfig="@xml/network_security_config">
```

元素 application：声明 Application 和默认应用属性。
android:name=".PulseApplication"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
android:allowBackup="false"：是否允许系统备份应用数据，此工程 false。
android:fullBackupContent="false"：旧备份规则开关，此工程 false。
android:dataExtractionRules="@xml/data_extraction_rules"：Android 数据提取规则资源，决定云备份及设备迁移内容。引用资源 @xml/data_extraction_rules，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:icon="@drawable/ic_launcher"：应用图标资源。引用资源 @drawable/ic_launcher，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:label="脉动 PULSE"：显示给用户的应用/组件名。
android:theme="@style/AppTheme"：给应用或 Activity 指定主题。引用资源 @style/AppTheme，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:supportsRtl="true"：支持从右向左语言布局，配合 start/end 而非写死 left/right。
android:networkSecurityConfig="@xml/network_security_config"：网络安全规则 XML，debug 同名资源可覆盖 main 规则。引用资源 @xml/network_security_config，实际值见同名资源定义；night/v27 等目录可能覆盖。

## 第 5 行

```xml
        <activity android:name=".ui.WorkoutActivity" android:exported="false" />
```

元素 activity：声明可启动的页面组件。
android:name=".ui.WorkoutActivity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
android:exported="false"：是否允许其他应用直接启动组件；启动器 Activity 需要 true，内部页面 false。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
        <activity android:name=".ui.AuthLegalActivity" android:exported="false" android:theme="@style/LoginTheme" />
```

元素 activity：声明可启动的页面组件。
android:name=".ui.AuthLegalActivity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
android:exported="false"：是否允许其他应用直接启动组件；启动器 Activity 需要 true，内部页面 false。
android:theme="@style/LoginTheme"：给应用或 Activity 指定主题。引用资源 @style/LoginTheme，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 7 行

```xml
        <activity android:name=".ui.MainActivity" android:exported="false" />
```

元素 activity：声明可启动的页面组件。
android:name=".ui.MainActivity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
android:exported="false"：是否允许其他应用直接启动组件；启动器 Activity 需要 true，内部页面 false。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
        <activity android:name=".ui.LoginActivity" android:exported="true" android:theme="@style/LoginTheme" android:windowSoftInputMode="adjustResize">
```

元素 activity：声明可启动的页面组件。
android:name=".ui.LoginActivity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
android:exported="true"：是否允许其他应用直接启动组件；启动器 Activity 需要 true，内部页面 false。
android:theme="@style/LoginTheme"：给应用或 Activity 指定主题。引用资源 @style/LoginTheme，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:windowSoftInputMode="adjustResize"：adjustResize 让软键盘弹出时页面可用区域缩小。

## 第 9 行

```xml
            <intent-filter><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent-filter>
```

元素 intent-filter：声明组件能处理的隐式 Intent。
元素 action：Intent 动作，MAIN 表示主入口。
android:name="android.intent.action.MAIN"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该元素以 /> 自闭合，没有嵌套子节点。
元素 category：Intent 分类，LAUNCHER 使入口出现在桌面启动器。
android:name="android.intent.category.LAUNCHER"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 intent-filter 元素，结束它的嵌套作用域。

## 第 10 行

```xml
        </activity>
```

关闭 activity 元素，结束它的嵌套作用域。

## 第 11 行

```xml
    </application>
```

关闭 application 元素，结束它的嵌套作用域。

## 第 12 行

```xml
</manifest>
```

关闭 manifest 元素，结束它的嵌套作用域。
