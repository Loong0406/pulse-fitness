# app/src/main/java/com/pulse/fitness/AppContainer.java

组合根：集中装配存储、登录规则、线程池和 ViewModel，避免每个页面自己创建一套依赖。

原文件 SHA-256：`ec6f5a1fd30a9bf6b2dae7f363670bd18c6d58c7f40825cc8ad91a816692a587`。行号仅对应此快照；修改源码后应重新核对。

共 40 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness;
```

声明本文件所属包 com.pulse.fitness；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.*;
```

导入类型命名空间 android.content.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.os.*;
```

导入类型命名空间 android.os.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.fitness.data.*;
```

导入类型命名空间 com.pulse.fitness.data.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.core.data.*;
```

导入类型命名空间 com.pulse.core.data.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.core.auth.DemoPhoneAuth;
```

导入类型命名空间 com.pulse.core.auth.DemoPhoneAuth，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import java.net.URI;
```

导入类型命名空间 java.net.URI，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.util.concurrent.*;
```

导入类型命名空间 java.util.concurrent.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 13 行

```java
/** Singleton composition root. Domain classes still receive interfaces explicitly. */
```

源码注释，不参与执行。组合根：集中装配存储、登录规则、线程池和 ViewModel，避免每个页面自己创建一套依赖。

## 第 14 行

```java
public final class AppContainer {
```

定义 public final class AppContainer。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 15 行

```java
    private static volatile AppContainer instance;
```

volatile 保证其他线程看见完整初始化的单例引用；与 initialize 的双重检查锁配合。

## 第 16 行

```java
    public final SharedPreferences data,settings;
```

data 保存训练资料，settings 保存服务连接配置，二者都是应用私有 SharedPreferences。

## 第 17 行

```java
    public final SecureTokenStore tokens;
```

网关令牌的加密存储器，与手机号登录状态不同。

## 第 18 行

```java
    public final LocalSessionStore sessions;
```

本机演示登录或游客身份存储器。

## 第 19 行

```java
    public final DemoPhoneAuth phoneAuth=new DemoPhoneAuth(SystemClock::elapsedRealtime,new java.security.SecureRandom()::nextInt);
```

注入 Android 单调时钟和安全随机数，创建进程内共享的演示验证规则对象。

## 第 20 行

```java
    public final Repositories.Factory repositories;
```

仓库抽象工厂字段，外部业务按接口访问产品族。

## 第 21 行

```java
    public final TrainingFacade training;
```

对计划功能提供统一入口的门面。

## 第 22 行

```java
    public final ExecutorService worker=Executors.newFixedThreadPool(2);
```

两个后台工作线程，承载计划生成、连接检测，避免在主线程联网。

## 第 23 行

```java
    public final Handler main=new Handler(Looper.getMainLooper());
```

绑定主线程 Looper 的 Handler，用于把后台结果投递回 UI 线程。

## 第 24 行

```java
    public final FitnessViewModel viewModel;
```

应用级共享的 FitnessViewModel；这是普通 Java 类，不是 AndroidX ViewModel。

## 第 25 行

```java
    private AppContainer(Context context){
```

私有构造器只由单例初始化调用。

## 第 26 行

```java
        data=context.getSharedPreferences("pulse_data",Context.MODE_PRIVATE);settings=context.getSharedPreferences("pulse_settings",Context.MODE_PRIVATE);
```

打开 pulse_data 与 pulse_settings 两个独立的键值存储文件，MODE_PRIVATE 限于本应用沙箱。

## 第 27 行

```java
        tokens=new SecureTokenStore(settings);sessions=new LocalSessionStore(context.getSharedPreferences("pulse_auth",Context.MODE_PRIVATE));repositories=new PreferencesRepositoryFactory(data);training=new TrainingFacade(repositories);viewModel=new FitnessViewModel(this);
```

按依赖顺序创建令牌器、登录存储、Android 仓库、训练门面和 ViewModel；后者读取前面对象，所以顺序重要。

## 第 28 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 29 行

```java
    public static void initialize(Context context){if(instance==null)synchronized(AppContainer.class){if(instance==null)instance=new AppContainer(context.getApplicationContext());}}
```

双重检查：先无锁判断，没有实例再锁住类，再确认一次才创建；getApplicationContext 避免持有 Activity。

## 第 30 行

```java
    public static AppContainer get(){if(instance==null)throw new IllegalStateException("Application 未初始化");return instance;}
```

获取单例；若 Application 未先初始化则抛异常，而不是返回 null 造成后续隐蔽错误。

## 第 31 行

```java
    public String endpoint(){return settings.getString("endpoint",BuildConfig.DEBUG?"http://10.0.2.2:8080":"");}
```

优先读已保存地址；调试包默认 10.0.2.2:8080，是 Android 标准模拟器访问宿主机的地址，正式包默认空。

## 第 32 行

```java
    public void saveConnection(String endpoint,String token)throws Exception{
```

保存服务连接参数的方法，可能因 URI 或密钥操作失败而抛异常。

## 第 33 行

```java
        URI uri=URI.create(endpoint.trim());
```

去首尾空白并解析 URI。

## 第 34 行

```java
        if(uri.getHost()==null||uri.getUserInfo()!=null||uri.getQuery()!=null||uri.getFragment()!=null||endpoint.length()>2048||!("https".equals(uri.getScheme())||(BuildConfig.DEBUG&&"http".equals(uri.getScheme()))))throw new IllegalArgumentException(BuildConfig.DEBUG?"请输入完整的 http(s) 服务地址":"正式版本的服务地址必须使用 HTTPS");
```

要求主机存在，无内嵌账号、查询或片段，长度不超 2048；正式包只接受 https，调试包也允许 http。

## 第 35 行

```java
        if(token.length()>512||token.contains("\n")||token.contains("\r"))throw new IllegalArgumentException("服务令牌格式无效");
```

网关令牌最多 512 字符，禁止换行，避免组成非法 HTTP 头。

## 第 36 行

```java
        tokens.save(token);settings.edit().putString("endpoint",endpoint.trim().replaceAll("/+$","")).apply();
```

先加密保存令牌，再保存去掉末尾斜线的地址；apply 更新内存并安排异步落盘。

## 第 37 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 38 行

```java
    public Set<String> favorites(){return new HashSet<>(data.getStringSet("favorites",Collections.emptySet()));}
```

读取收藏集合后复制成新 HashSet，避免直接修改 SharedPreferences 返回的集合。

## 第 39 行

```java
    public void favorite(String id){Set<String> values=favorites();if(!values.add(id))values.remove(id);data.edit().putStringSet("favorites",values).apply();}
```

add 若成功表示原来未收藏；若失败表示已有，于是 remove 实现切换，再写回整份集合。

## 第 40 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
