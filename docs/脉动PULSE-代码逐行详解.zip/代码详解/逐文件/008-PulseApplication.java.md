# app/src/main/java/com/pulse/fitness/PulseApplication.java

Android 进程级初始化入口；由 Manifest 指定，早于首个 Activity 创建。

原文件 SHA-256：`8db537adc33a4d3d6b0553ccc60998321256a94dfa0914792f878398d57863d9`。行号仅对应此快照；修改源码后应重新核对。

共 5 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness;
```

声明本文件所属包 com.pulse.fitness；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import android.app.Application;
```

导入类型命名空间 android.app.Application，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
public final class PulseApplication extends Application {
```

定义 public final class PulseApplication extends Application。继承 Application 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 4 行

```java
    @Override public void onCreate(){super.onCreate();AppContainer.initialize(this);}
```

先执行 Android Application 基础初始化，再初始化唯一 AppContainer；传入 Application 而非短命页面。

## 第 5 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
