# app/src/main/java/com/pulse/fitness/data/LocalSessionStore.java

只保存本机演示身份/游客选择，不是服务器颁发的认证令牌；切换号码不会隔离训练档案。

原文件 SHA-256：`66115b898893e38b1d33851d5fe4827ccccde6da0268e3268277b8a624d9f890`。行号仅对应此快照；修改源码后应重新核对。

共 16 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.data;
```

声明本文件所属包 com.pulse.fitness.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.SharedPreferences;
```

导入类型命名空间 android.content.SharedPreferences，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.auth.DemoPhoneAuth;
```

导入类型命名空间 com.pulse.core.auth.DemoPhoneAuth，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 6 行

```java
/** Remembers a local demo identity or guest choice; never a server authentication token. */
```

源码注释，不参与执行。只保存本机演示身份/游客选择，不是服务器颁发的认证令牌；切换号码不会隔离训练档案。

## 第 7 行

```java
public final class LocalSessionStore {
```

定义 public final class LocalSessionStore。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 8 行

```java
    private final SharedPreferences prefs;
```

保存专用 pulse_auth 存储引用。

## 第 9 行

```java
    public LocalSessionStore(SharedPreferences prefs){this.prefs=prefs;}
```

构造器注入存储，避免此类自己找全局容器。

## 第 10 行

```java
    public boolean isPhoneSession(){return "PHONE_DEMO".equals(prefs.getString("mode",""))&&prefs.getString("phone","").matches("1[3-9][0-9]{9}");}
```

mode 必须为 PHONE_DEMO 且号码格式有效才算演示手机号身份；固定字符串在左避免 null.equals。

## 第 11 行

```java
    public boolean canEnterApp(){return isPhoneSession()||"GUEST".equals(prefs.getString("mode",""));}
```

演示手机号或 mode=GUEST 都可进入主界面。

## 第 12 行

```java
    public void enterPhoneDemo(String rawPhone){prefs.edit().putString("mode","PHONE_DEMO").putString("phone",DemoPhoneAuth.normalizePhone(rawPhone)).apply();}
```

规范化号码，保存 PHONE_DEMO 和号码；apply 异步落盘，不向外部发送请求。

## 第 13 行

```java
    public void enterGuest(){prefs.edit().putString("mode","GUEST").remove("phone").apply();}
```

写入 GUEST，删旧手机号，避免游客还显示上个身份号码。

## 第 14 行

```java
    public String maskedPhone(){String p=prefs.getString("phone","");return isPhoneSession()?p.substring(0,3)+" **** "+p.substring(7):"";}
```

仅有效演示身份显示前三位、星号、后四位；substring(7) 从第八位开始。

## 第 15 行

```java
    public void clear(){prefs.edit().clear().apply();}
```

只清空这个存储文件的键值，不会清除另两个文件的训练资料。

## 第 16 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
