# app/src/main/java/com/pulse/fitness/data/PreferencesRepositoryFactory.java

抽象工厂的 Android 持久化产品族，以 JSON 存在 SharedPreferences 中。

原文件 SHA-256：`4c0366faa449b102a422cec757c904116b90f4d0fdd3ac3fbfd19d5eac98d2d2`。行号仅对应此快照；修改源码后应重新核对。

共 36 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.data;
```

声明本文件所属包 com.pulse.fitness.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.SharedPreferences;
```

导入类型命名空间 android.content.SharedPreferences，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.google.gson.reflect.TypeToken;
```

导入类型命名空间 com.google.gson.reflect.TypeToken，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.data.Repositories;
```

导入类型命名空间 com.pulse.core.data.Repositories，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 10 行

```java
/** Abstract Factory's persistent Android family. No screen knows SharedPreferences. */
```

源码注释，不参与执行。抽象工厂的 Android 持久化产品族，以 JSON 存在 SharedPreferences 中。

## 第 11 行

```java
public final class PreferencesRepositoryFactory implements Repositories.Factory {
```

定义 public final class PreferencesRepositoryFactory implements Repositories.Factory。实现 Repositories.Factory 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 12 行

```java
    private final SharedPreferences prefs;
```

保存统一存储引用，三类仓库使用同一个数据文件。

## 第 13 行

```java
    public PreferencesRepositoryFactory(SharedPreferences prefs){this.prefs=prefs;}
```

由组合根注入存储。

## 第 14 行

```java
    public Repositories.Profiles profiles(){return new Repositories.Profiles(){
```

创建匿名档案仓库对象。

## 第 15 行

```java
        public UserProfile get(){try{String s=prefs.getString("profile",null);return s==null?null:JsonCodec.profile(s);}catch(RuntimeException e){return null;}}
```

读 profile 键；没有则返回 null，JSON 损坏也返回 null。异常在此被吞掉，UI 会表现成无档案。

## 第 16 行

```java
        public void save(UserProfile p){prefs.edit().putString("profile",JsonCodec.profile(p)).apply();}
```

将档案序列化后写入 profile 键，apply 异步落盘。

## 第 17 行

```java
    };}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 18 行

```java
    public Repositories.Plans plans(){return new Repositories.Plans(){
```

创建匿名计划仓库对象。

## 第 19 行

```java
        public WeekPlan get(){try{String s=prefs.getString("plan",null);return s==null?null:JsonCodec.plan(s);}catch(RuntimeException e){return null;}}
```

从 plan 键读取并重建计划；格式损坏返回 null，业务安全性由上层继续验证。

## 第 20 行

```java
        public void save(WeekPlan p){prefs.edit().putString("plan",JsonCodec.plan(p)).remove("session").remove("session_day").apply();}
```

保存新计划时同时删旧训练快照及日键，因为快照属于旧计划。

## 第 21 行

```java
        public void clear(){prefs.edit().remove("plan").remove("session").remove("session_day").apply();}
```

清除当前计划及其训练进度，不清除历史。

## 第 22 行

```java
    };}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 23 行

```java
    public Repositories.History history(){return new Repositories.History(){
```

创建匿名历史仓库对象。

## 第 24 行

```java
        public List<TrainingRecord> all(){return records();}
```

all 委托 records 读取并过滤记录。

## 第 25 行

```java
        public void add(TrainingRecord r){
```

开始保存一条完成记录。

## 第 26 行

```java
            List<TrainingRecord> list=new ArrayList<>(records());for(TrainingRecord old:list)if(old.id.equals(r.id))return;
```

复制历史列表，按 id 去重；重复完成回调不会再次插入相同会话。

## 第 27 行

```java
            list.add(0,r);prefs.edit().putString("history",JsonCodec.GSON.toJson(list)).remove("session").remove("session_day").apply();
```

新记录放最前，JSON 存 history，同时删本次未完成训练快照。

## 第 28 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 29 行

```java
        public void clear(){prefs.edit().remove("history").apply();}
```

只删除历史键。

## 第 30 行

```java
    };}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 31 行

```java
    private List<TrainingRecord> records(){
```

内部读取历史的方法。

## 第 32 行

```java
        try{List<TrainingRecord> result=JsonCodec.GSON.fromJson(prefs.getString("history","[]"),new TypeToken<List<TrainingRecord>>(){}.getType());
```

默认读取空数组；TypeToken 保留 List<TrainingRecord> 的泛型信息，防止只能得到原始 List。

## 第 33 行

```java
            if(result==null)return Collections.emptyList();result.removeIf(r->r==null||r.id==null||r.title==null||r.activeSeconds<0||r.completedSets<1);return Collections.unmodifiableList(result);
```

JSON null 转空列表；删除空对象、缺 ID/标题、负时长或零完成组的坏记录，再返回只读列表。

## 第 34 行

```java
        }catch(RuntimeException e){return Collections.emptyList();}
```

整段 JSON 损坏时返回空列表，页面显示空记录状态。

## 第 35 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 36 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
