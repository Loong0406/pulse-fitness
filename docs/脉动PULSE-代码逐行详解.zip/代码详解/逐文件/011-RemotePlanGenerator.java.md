# app/src/main/java/com/pulse/fitness/data/RemotePlanGenerator.java

手机调用可选 Java 网关；并非在手机部署或启动模型。网络操作由 ViewModel 放入后台线程。

原文件 SHA-256：`a5584dd1630d071c1480c1debc6181f5cfddc1d3762b53995ca500002687b9c3`。行号仅对应此快照；修改源码后应重新核对。

共 41 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.data;
```

声明本文件所属包 com.pulse.fitness.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.google.gson.*;
```

导入类型命名空间 com.google.gson.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.net.*;
```

导入类型命名空间 java.net.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import java.io.*;
```

导入类型命名空间 java.io.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import java.nio.charset.StandardCharsets;
```

导入类型命名空间 java.nio.charset.StandardCharsets，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 11 行

```java
public final class RemotePlanGenerator extends PlanGenerationTemplate {
```

定义 public final class RemotePlanGenerator extends PlanGenerationTemplate。继承 PlanGenerationTemplate 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 12 行

```java
    private final String endpoint,token;
```

保存网关地址和应用网关令牌。

## 第 13 行

```java
    public RemotePlanGenerator(String endpoint,String token){this.endpoint=endpoint;this.token=token;}
```

构造器注入连接信息。

## 第 14 行

```java
    @Override protected WeekPlan createCandidate(UserProfile p)throws Exception{
```

覆盖创建候选步骤，父类依然在前后校验。

## 第 15 行

```java
        JsonObject payload=JsonParser.parseString(request(endpoint+"/api/v1/plans",token,JsonCodec.profile(p))).getAsJsonObject();
```

将档案 JSON POST 到 /api/v1/plans，再把响应解析成对象。

## 第 16 行

```java
        return JsonCodec.plan(payload.get("plan").toString());
```

取响应中的 plan 并由 JsonCodec 重建领域对象。

## 第 17 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 18 行

```java
    public static String health(String endpoint,String token)throws Exception{return request(endpoint+"/health",token,null);}
```

检测网关 /health：body=null 使 request 保持默认 GET。

## 第 19 行

```java
    private static String request(String url,String token,String body)throws Exception{
```

共用 HTTP 请求函数，body 为空是 GET，否则 POST。

## 第 20 行

```java
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
```

打开 URL 对应的 HttpURLConnection。

## 第 21 行

```java
        try{
```

进入 try，配合 finally 确保释放连接。

## 第 22 行

```java
            connection.setConnectTimeout(8000);connection.setReadTimeout(body==null?10000:175000);
```

连接最多 8 秒；健康检测读取最多 10 秒，生成计划读取最多 175 秒。读取超时不等同于严格整个请求总时限。

## 第 23 行

```java
            connection.setInstanceFollowRedirects(false);connection.setRequestProperty("Accept","application/json");
```

禁止自动重定向以免令牌跟到其他地址；声明期望 JSON。

## 第 24 行

```java
            if(!token.isEmpty())connection.setRequestProperty("Authorization","Bearer "+token);
```

配置令牌非空才加 Bearer 认证头。

## 第 25 行

```java
            if(body!=null){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] bytes=body.getBytes(StandardCharsets.UTF_8);connection.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=connection.getOutputStream()){out.write(bytes);}}
```

有正文时设 POST、启用输出、声明 UTF-8 JSON；按实际字节数设置长度，以自动关闭流写出。

## 第 26 行

```java
            int code=connection.getResponseCode();InputStream input=code/100==2?connection.getInputStream():connection.getErrorStream();
```

先取 HTTP 状态码；2xx 读正常流，其他读错误流。

## 第 27 行

```java
            if(input==null)throw new IOException("服务未返回数据（"+code+"）");
```

服务没有正文流时抛出含状态码的 IO 错误。

## 第 28 行

```java
            byte[] bytes;try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
```

为读取流和累加字节缓冲建立自动关闭作用域。

## 第 29 行

```java
                byte[] buffer=new byte[4096];int count;while((count=in.read(buffer))!=-1){if(out.size()+count>262144)throw new IOException("返回数据过大");out.write(buffer,0,count);}bytes=out.toByteArray();
```

每次读最多 4096 字节；累计超过 262144 字节即拒绝，-1 表示结束。

## 第 30 行

```java
            }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 31 行

```java
            String text=new String(bytes,StandardCharsets.UTF_8);
```

将完整字节按 UTF-8 解码。

## 第 32 行

```java
            if(code/100!=2){String message="服务请求失败（"+code+"）";try{message=JsonParser.parseString(text).getAsJsonObject().get("error").getAsString();}catch(RuntimeException ignored){}throw new IOException(message);}
```

非 2xx 尝试提取 JSON error 文案，解析失败仍保留通用状态提示，最终以 IOException 抛出。

## 第 33 行

```java
            return text;
```

成功返回正文文本。

## 第 34 行

```java
        }finally{connection.disconnect();}
```

无论成功失败都 disconnect，释放网络连接。

## 第 35 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 36 行

```java
    public static final class Factory extends PlanGeneratorFactory {
```

远程生成器的具体工厂，不改变已有本地工厂。

## 第 37 行

```java
        private final String endpoint,token;
```

工厂自己保存创建产品所需的地址和令牌。

## 第 38 行

```java
        public Factory(String endpoint,String token){this.endpoint=endpoint;this.token=token;}
```

构造器保存工厂参数。

## 第 39 行

```java
        @Override protected PlanGenerator createGenerator(){return new RemotePlanGenerator(endpoint,token);}
```

工厂方法创建 RemotePlanGenerator；继承的 createSafeGenerator 还会给它加装饰器。

## 第 40 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 41 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
