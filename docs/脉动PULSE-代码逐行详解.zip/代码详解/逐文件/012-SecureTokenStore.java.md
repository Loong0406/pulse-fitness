# app/src/main/java/com/pulse/fitness/data/SecureTokenStore.java

加密保存访问 Java 网关的令牌；它不是模型供应商 API key，也不是手机号验证码。

原文件 SHA-256：`f11f5aae2722bd4aa0b0bbfb1e11d54f178dc95a58958d539f7534d90e7453eb`。行号仅对应此快照；修改源码后应重新核对。

共 31 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.data;
```

声明本文件所属包 com.pulse.fitness.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.SharedPreferences;
```

导入类型命名空间 android.content.SharedPreferences，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.security.keystore.*;
```

导入类型命名空间 android.security.keystore.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.util.Base64;
```

导入类型命名空间 android.util.Base64，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.security.KeyStore;
```

导入类型命名空间 java.security.KeyStore，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import javax.crypto.*;
```

导入类型命名空间 javax.crypto.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import javax.crypto.spec.GCMParameterSpec;
```

导入类型命名空间 javax.crypto.spec.GCMParameterSpec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 10 行

```java
/** Only the application gateway token is stored on-device, encrypted using Android Keystore. */
```

源码注释，不参与执行。加密保存访问 Java 网关的令牌；它不是模型供应商 API key，也不是手机号验证码。

## 第 11 行

```java
public final class SecureTokenStore {
```

定义 public final class SecureTokenStore。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 12 行

```java
    private static final String ALIAS="pulse_gateway_token";
```

Keystore 条目的固定别名，密钥本体由系统密钥库管理。

## 第 13 行

```java
    private final SharedPreferences prefs;
```

SharedPreferences 只保存密文和随机初始化向量。

## 第 14 行

```java
    public SecureTokenStore(SharedPreferences p){prefs=p;}
```

注入存储对象。

## 第 15 行

```java
    private SecretKey key()throws Exception{
```

获取或创建 AES SecretKey。

## 第 16 行

```java
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
```

打开 AndroidKeyStore 并加载，不提供文件密码。

## 第 17 行

```java
        if(store.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
```

已存在此别名就取密钥，不重复生成导致旧密文无法解开。

## 第 18 行

```java
        KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
```

从 AndroidKeyStore 获取 AES 密钥生成器。

## 第 19 行

```java
        g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return g.generateKey();
```

配置可加/解密，GCM 分组模式，无填充，然后生成密钥；按位或合并两个用途。

## 第 20 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 21 行

```java
    public void save(String value)throws Exception{
```

保存令牌入口，密码学失败可以向上传播。

## 第 22 行

```java
        if(value.isEmpty()){prefs.edit().remove("token").remove("token_iv").apply();return;}
```

空令牌表示清除：删密文和 IV 后立刻返回。

## 第 23 行

```java
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
```

创建 AES-GCM 加密器并用密钥初始化，系统为本次加密生成 IV。

## 第 24 行

```java
        prefs.edit().putString("token",Base64.encodeToString(c.doFinal(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)),Base64.NO_WRAP)).putString("token_iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).apply();
```

对 UTF-8 原文加密，密文和 IV 分别 Base64 编码存储；Base64 只是便于保存二进制，加密由前面的 AES 完成。

## 第 25 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
    public String get(){try{
```

读取和解密入口，用 try 覆盖可能的密钥、编码或密文异常。

## 第 27 行

```java
        String token=prefs.getString("token",null),iv=prefs.getString("token_iv",null);if(token==null||iv==null)return "";
```

密文或 IV 缺少任一就视为未配置，返回空串。

## 第 28 行

```java
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
```

创建解密器，使用相同密钥和 IV；128 为 GCM 认证标签的位数。

## 第 29 行

```java
        return new String(c.doFinal(Base64.decode(token,Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8);
```

解码密文，doFinal 验证并解密，再按 UTF-8 转成字符串。

## 第 30 行

```java
    }catch(Exception e){return "";}}
```

任意解密失败返回空串；不把原始密码学异常泄露到页面。

## 第 31 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
