# app/src/main/java/com/pulse/fitness/presentation/FitnessViewModel.java

应用级页面状态与用户意图。后台生成和主线程提交分离，用 revision 拒绝过期响应；不持有 Activity。

原文件 SHA-256：`c36cd3402e93a6bcd4d2f7bef7e9c2b45b7c476581e87044918aa915d392dfe4`。行号仅对应此快照；修改源码后应重新核对。

共 84 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.presentation;
```

声明本文件所属包 com.pulse.fitness.presentation；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.fitness.*;
```

导入类型命名空间 com.pulse.fitness.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.fitness.data.RemotePlanGenerator;
```

导入类型命名空间 com.pulse.fitness.data.RemotePlanGenerator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.data.*;
```

导入类型命名空间 com.pulse.core.data.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.core.util.*;
```

导入类型命名空间 com.pulse.core.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.google.gson.*;
```

导入类型命名空间 com.google.gson.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.util.concurrent.Future;
```

导入类型命名空间 java.util.concurrent.Future，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 13 行

```java
/** MVVM: views send intentions and observe immutable UI state; no Activity is retained. */
```

源码注释，不参与执行。应用级页面状态与用户意图。后台生成和主线程提交分离，用 revision 拒绝过期响应；不持有 Activity。

## 第 14 行

```java
public final class FitnessViewModel {
```

定义 public final class FitnessViewModel。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 15 行

```java
    public static final class UiState {
```

不可重新赋值字段组成一次 UI 状态快照。

## 第 16 行

```java
        public final UserProfile profile;public final WeekPlan plan;public final boolean busy;
```

快照包含档案、计划和是否忙碌。

## 第 17 行

```java
        public final String message,connection;
```

message 是计划操作提示，connection 是连接检测提示。

## 第 18 行

```java
        UiState(UserProfile profile,WeekPlan plan,boolean busy,String message,String connection){this.profile=profile;this.plan=plan;this.busy=busy;this.message=message;this.connection=connection;}
```

构造器逐项保存快照字段，页面只读。

## 第 19 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
    private final AppContainer container;
```

依赖组合根，获取仓库、线程和网络配置。

## 第 21 行

```java
    public final ObservableState<UiState> state;
```

页面订阅的状态容器。

## 第 22 行

```java
    private boolean busy;
```

当前是否正在生成，默认 false。

## 第 23 行

```java
    private String message="",connection="";
```

两类当前提示初始为空串。

## 第 24 行

```java
    private long revision;
```

请求版本号，档案变化或新生成会递增，用于屏蔽旧回调。

## 第 25 行

```java
    private Future<?> generation;
```

正在执行的后台生成任务句柄。

## 第 26 行

```java
    private ProfileCommand lastSave;
```

最近一次档案保存命令，支持一次撤销。

## 第 27 行

```java
    public FitnessViewModel(AppContainer c){container=c;state=new ObservableState<>(read());}
```

注入容器，立刻读取持久化状态生成初始可观察状态。

## 第 28 行

```java
    private UiState read(){
```

读取并组装一份状态。

## 第 29 行

```java
        UserProfile p=container.repositories.profiles().get();WeekPlan plan=container.training.current();
```

读取档案和当前计划。

## 第 30 行

```java
        if(plan!=null){try{if(p==null)throw new IllegalArgumentException();PlanSafety.validate(plan,p);}catch(RuntimeException invalid){container.training.invalidate();plan=null;}}
```

计划存在就对照当前档案检查；档案缺失或校验失败，清除旧计划并在本次状态里置空。

## 第 31 行

```java
        return new UiState(p,plan,busy,message,connection);
```

将数据与当前 busy/message/connection 组成新快照。

## 第 32 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
    public void refresh(){state.set(read());}
```

发布新快照，监听页面同步更新。

## 第 34 行

```java
    public List<TrainingRecord> history(){return container.repositories.history().all();}
```

从历史仓库读取只读历史列表。

## 第 35 行

```java
    public void saveProfile(UserProfile p){
```

保存用户档案的公开意图。

## 第 36 行

```java
        ProfileCommand command=new ProfileCommand(container.repositories.profiles(),p);command.execute();lastSave=command;
```

创建并执行保存命令，保留它用于撤销；失败时后续失效操作不执行。

## 第 37 行

```java
        cancel();container.training.invalidate();message="档案已保存。请根据新档案生成计划。";refresh();
```

取消旧生成、使旧计划失效、写提示、刷新状态。

## 第 38 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 39 行

```java
    public boolean canUndo(){return lastSave!=null&&lastSave.canUndo();}
```

有最近命令且命令可撤销时返回 true。

## 第 40 行

```java
    public void undo(){if(canUndo()){lastSave.undo();cancel();container.training.invalidate();message="已恢复上一次档案，请重新生成计划。";refresh();}}
```

恢复旧档案，取消旧请求并清旧计划，再发布提示；不会恢复旧计划。

## 第 41 行

```java
    private void cancel(){revision++;busy=false;if(generation!=null)generation.cancel(true);}
```

revision 增一，使旧回调失效；清忙碌，尝试中断 Future。网络操作不保证立即停止，因此版本检查仍必要。

## 第 42 行

```java
    public void generate(boolean remote){
```

开始生成计划，remote 为 true 选网关，false 选离线规则。

## 第 43 行

```java
        if(busy)return;
```

忙碌时忽略重复点击。

## 第 44 行

```java
        UserProfile p=container.repositories.profiles().get();
```

读取当前存档。

## 第 45 行

```java
        try{com.pulse.core.validation.ProfileValidator.validateForTraining(p);}catch(IllegalArgumentException e){message=e.getMessage();refresh();return;}
```

提前检查档案可否训练；失败就显示文案、刷新并结束。

## 第 46 行

```java
        if(remote&&container.endpoint().isEmpty()){message="请先在“我的”中设置 AI 服务地址";refresh();return;}
```

远程生成但无服务地址时提示先配置，避免发无意义请求。

## 第 47 行

```java
        busy=true;message=remote?"正在生成专属计划，模型推理可能需要 1–3 分钟…":"正在匹配本地训练计划…";
```

标为忙碌，并按来源给出等待提示。

## 第 48 行

```java
        long request=++revision;PlanGenerator generator=remote?new RemotePlanGenerator.Factory(container.endpoint(),container.tokens.get()).createSafeGenerator():new PlanGeneratorFactory.Local().createSafeGenerator();refresh();
```

递增并捕获本次 request 版本；用对应工厂创建安全包装生成器，立即刷新禁用相关按钮。

## 第 49 行

```java
        generation=container.worker.submit(()->{
```

把耗时工作提交双线程池，返回 Future 保存到 generation。

## 第 50 行

```java
            try{
```

后台 try 开始。

## 第 51 行

```java
                WeekPlan result=container.training.generate(generator);
```

门面读取档案并生成候选；这里没有直接写入当前计划。

## 第 52 行

```java
                container.main.post(()->{
```

把提交和状态更新投递主线程，后台线程不直接操作页面。

## 第 53 行

```java
                    if(request!=revision)return;
```

本次 request 与现版本不同就丢弃，防止旧档案生成结果覆盖新档案。

## 第 54 行

```java
                    try{container.training.commit(result);message=result.source==WeekPlan.Source.AI?"AI 计划已生成，动作与训练量已通过校验。":remote?"模型尚未就绪或输出未通过校验，当前为本地规则计划。":"本地规则计划已生成，可以离线训练。";}
```

门面再次校验后存储；按实际 Source 显示 AI 或本地来源，远程回退不会冒充 AI。

## 第 55 行

```java
                    catch(RuntimeException e){message=e.getMessage();}
```

提交失败写出可读错误。

## 第 56 行

```java
                    busy=false;refresh();
```

无论提交成功失败都结束忙碌并刷新。

## 第 57 行

```java
                });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 58 行

```java
            }catch(Exception e){container.main.post(()->{if(request!=revision)return;busy=false;message="生成失败："+friendly(e)+"。可检查服务连接，或选择本地计划。";refresh();});}
```

后台生成异常也切回主线程；先检查版本，再清忙碌、构造友好提示、刷新。

## 第 59 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 60 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 61 行

```java
    private static String friendly(Exception e){
```

将底层异常转成简短界面文字。

## 第 62 行

```java
        if(e instanceof java.net.ConnectException)return "无法连接服务";
```

无法建立连接时使用固定提示。

## 第 63 行

```java
        if(e instanceof java.net.SocketTimeoutException)return "服务连接超时";
```

网络读取超时使用固定提示。

## 第 64 行

```java
        String s=e.getMessage();return s==null?"服务暂时不可用":s.substring(0,Math.min(160,s.length()));
```

其他异常取消息，null 用默认，最长 160 字符。

## 第 65 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 66 行

```java
    public void copyPlan(){
```

复制新训练周期意图。

## 第 67 行

```java
        WeekPlan p=state.get().plan;if(p==null||busy)return;
```

无计划或正在生成则不复制。

## 第 68 行

```java
        container.training.commit(p.copyForNextWeek());container.data.edit().remove("session").remove("session_day").apply();message="已创建新的训练周期，历史记录已保留。";refresh();
```

用原型深复制计划并提交，清旧会话进度，保留历史，更新提示。

## 第 69 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 70 行

```java
    public void testConnection(String endpoint,String token){
```

保存并检测服务连接，输入来自“我的”表单。

## 第 71 行

```java
        try{container.saveConnection(endpoint,token);}catch(Exception e){connection="保存失败："+friendly(e);refresh();return;}
```

先校验并保存连接，失败直接显示保存错误并返回。

## 第 72 行

```java
        final long requestedRevision=revision;
```

记下当前 revision，数据被重置后可以拒绝此次检测结果。

## 第 73 行

```java
        connection="连接已保存，正在检测服务…";refresh();
```

立刻显示正在检测并刷新。

## 第 74 行

```java
        container.worker.submit(()->{
```

把 HTTP 健康检测放到后台。

## 第 75 行

```java
            String result;
```

声明检测结果文本，成功/失败分支都必须赋值。

## 第 76 行

```java
            try{JsonObject o=JsonParser.parseString(RemotePlanGenerator.health(container.endpoint(),container.tokens.get())).getAsJsonObject();
```

调 /health 并解析 JSON；使用当前容器连接信息。

## 第 77 行

```java
                if(!"ok".equals(JsonCodec.str(o,"status")))throw new IllegalArgumentException("服务状态异常");
```

status 必须是字符串 ok，否则当作异常。

## 第 78 行

```java
                result=o.get("modelConfigured").getAsBoolean()?"服务在线 · 模型："+o.get("model").getAsString()+"。可前往计划页生成，实际推理结果以计划来源为准。":"服务在线，尚未配置模型；目前可生成本地规则计划。";
```

modelConfigured 仅表示服务配置了模型，不证明推理一定成功；文案明确以最终计划来源为准。

## 第 79 行

```java
            }catch(Exception e){result="检测失败："+friendly(e)+"。请确认服务已启动和地址正确。";}
```

检测失败转友好提示，不让工作线程异常结束而无反馈。

## 第 80 行

```java
            String value=result;container.main.post(()->{if(requestedRevision!=revision)return;connection=value;refresh();});
```

将结果复制到供 Lambda 捕获的变量，再切回主线程；版本变化则忽略。

## 第 81 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 82 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 83 行

```java
    public void reset(){cancel();container.data.edit().clear().apply();container.settings.edit().clear().apply();container.sessions.clear();container.phoneAuth.clear();lastSave=null;message="本机个人数据已清除。";connection="";refresh();}
```

取消任务，清训练数据、服务设置、本机身份、演示码、撤销命令和提示，最后发布空状态。

## 第 84 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
