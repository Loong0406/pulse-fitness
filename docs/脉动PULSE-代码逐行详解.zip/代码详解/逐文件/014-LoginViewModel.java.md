# app/src/main/java/com/pulse/fitness/presentation/LoginViewModel.java

将“获取码、登录、游客进入”意图与 Activity 控件解耦；这里仍依赖具体本机存储类，并非完全平台无关。

原文件 SHA-256：`cf214aea3040ad6fb18588ddec40ee697509dc25abb7c11498a0a6f945c2d93f`。行号仅对应此快照；修改源码后应重新核对。

共 16 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.presentation;
```

声明本文件所属包 com.pulse.fitness.presentation；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.auth.DemoPhoneAuth;
```

导入类型命名空间 com.pulse.core.auth.DemoPhoneAuth，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.fitness.data.LocalSessionStore;
```

导入类型命名空间 com.pulse.fitness.data.LocalSessionStore，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 6 行

```java
/** Login intentions are independent of Activity widgets and Android storage details. */
```

源码注释，不参与执行。将“获取码、登录、游客进入”意图与 Activity 控件解耦；这里仍依赖具体本机存储类，并非完全平台无关。

## 第 7 行

```java
public final class LoginViewModel {
```

定义 public final class LoginViewModel。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 8 行

```java
    private final DemoPhoneAuth auth;
```

保存演示验证码规则对象。

## 第 9 行

```java
    private final LocalSessionStore sessions;
```

保存本机身份存储对象。

## 第 10 行

```java
    public LoginViewModel(DemoPhoneAuth auth,LocalSessionStore sessions){this.auth=auth;this.sessions=sessions;}
```

构造器注入两个依赖，本类不查找页面 View。

## 第 11 行

```java
    public DemoPhoneAuth.CodeDelivery requestCode(String phone,boolean agreed){requireAgreement(agreed);return auth.requestCode(phone);}
```

先检查协议勾选，再请求演示码，返回号码和码给界面。

## 第 12 行

```java
    public void login(String phone,String code,boolean agreed){requireAgreement(agreed);auth.verify(phone,code);sessions.enterPhoneDemo(phone);}
```

先检查协议，校验号码和码，只有校验成功才写入演示身份。

## 第 13 行

```java
    public int resendSeconds(){return auth.resendSeconds();}
```

把规则层剩余冷却秒数交给 UI；UI 不自己维护另一个截止时间。

## 第 14 行

```java
    public void enterGuest(){sessions.enterGuest();}
```

保存游客身份；当前体验流程不要求勾选手机号登录协议。

## 第 15 行

```java
    private void requireAgreement(boolean agreed){if(!agreed)throw new IllegalArgumentException("请先阅读并同意用户协议和隐私政策");}
```

没勾选则抛可读异常，由 Activity 显示在错误区域。

## 第 16 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
