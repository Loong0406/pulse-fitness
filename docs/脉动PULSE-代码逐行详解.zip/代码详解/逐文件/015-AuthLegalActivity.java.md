# app/src/main/java/com/pulse/fitness/ui/AuthLegalActivity.java

从 APK 内 assets 读取协议或隐私文本，无需网络。

原文件 SHA-256：`7b08602ed24caa34e0b40cd23a918d3a3f5607cd540642e42c276d6d18e37ba8`。行号仅对应此快照；修改源码后应重新核对。

共 21 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.app.Activity;
```

导入类型命名空间 android.app.Activity，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.os.Bundle;
```

导入类型命名空间 android.os.Bundle，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.fitness.R;
```

导入类型命名空间 com.pulse.fitness.R，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.io.*;
```

导入类型命名空间 java.io.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.nio.charset.StandardCharsets;
```

导入类型命名空间 java.nio.charset.StandardCharsets，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 9 行

```java
public final class AuthLegalActivity extends Activity {
```

定义 public final class AuthLegalActivity extends Activity。继承 Activity 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    public static final String PRIVACY="privacy";
```

Intent Extra 的键，true 为隐私政策，false 为用户协议。

## 第 11 行

```java
    @Override protected void onCreate(Bundle saved){
```

创建文档页面入口。

## 第 12 行

```java
        super.onCreate(saved);setContentView(R.layout.activity_auth_legal);Ui.insets(this,findViewById(R.id.auth_legal_root),0);
```

父类初始化、加载 XML、设置系统边距。

## 第 13 行

```java
        boolean privacy=getIntent().getBooleanExtra(PRIVACY,false);
```

读取要展示的文档类型，缺省为协议。

## 第 14 行

```java
        Ui.text(findViewById(R.id.auth_legal_root),R.id.auth_legal_title,getString(privacy?R.string.auth_privacy_title:R.string.auth_terms_title));
```

根据类型选中文标题资源，写到标题 TextView。

## 第 15 行

```java
        findViewById(R.id.auth_legal_back).setOnClickListener(v->finish());
```

返回按钮直接 finish，回到原登录页。

## 第 16 行

```java
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(getAssets().open(privacy?"auth_privacy.txt":"auth_terms.txt"),StandardCharsets.UTF_8))){
```

try-with-resources 以 UTF-8 打开资产流并包成逐行读取器，退出作用域自动关闭资源。

## 第 17 行

```java
            StringBuilder text=new StringBuilder();String line;while((line=reader.readLine())!=null)text.append(line).append('\n');
```

循环读到 null 为止，把每行及换行附到 StringBuilder。

## 第 18 行

```java
            Ui.text(findViewById(R.id.auth_legal_root),R.id.auth_legal_text,text.toString());
```

将完整文字显示到可滚动内容区域。

## 第 19 行

```java
        }catch(IOException failure){Ui.text(findViewById(R.id.auth_legal_root),R.id.auth_legal_text,getString(R.string.auth_read_error));}
```

读取失败时显示固定错误信息，不让页面崩溃。

## 第 20 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 21 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
