# app/src/main/java/com/pulse/fitness/ui/ExercisesScreen.java

动作库组合“文本表达式＋部位标签＋收藏”筛选；全部数据来自内置动作目录。

原文件 SHA-256：`a606619a8655c899340593342a2e96383668e2345edb99d5e54722516d3e81ab`。行号仅对应此快照；修改源码后应重新核对。

共 45 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.text.*;
```

导入类型命名空间 android.text.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.fitness.*;
```

导入类型命名空间 com.pulse.fitness.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.core.model.Exercise;
```

导入类型命名空间 com.pulse.core.model.Exercise，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.util.Set;
```

导入类型命名空间 java.util.Set，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 13 行

```java
public final class ExercisesScreen implements Screen {
```

定义 public final class ExercisesScreen implements Screen。实现 Screen 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 14 行

```java
    private final View root;private final Context context;
```

保存根 View 和上下文。

## 第 15 行

```java
    private String filter="全部";
```

默认筛选标签为全部。

## 第 16 行

```java
    public ExercisesScreen(Context c){
```

构造器开始创建页面。

## 第 17 行

```java
        context=c;root=Ui.screen(c,R.layout.screen_exercises);
```

加载动作库 XML。

## 第 18 行

```java
        LinearLayout filters=root.findViewById(R.id.exercise_filters);
```

取得横向标签容器。

## 第 19 行

```java
        for(String label:new String[]{"全部","上肢","下肢","核心","有氧","活动度","收藏"}){
```

为七个固定中文标签创建筛选按钮。

## 第 20 行

```java
            TextView chip=new TextView(c);chip.setText(label);chip.setTextSize(13);chip.setGravity(Gravity.CENTER);chip.setPadding(Ui.dp(c,16),0,Ui.dp(c,16),0);chip.setBackgroundResource(R.drawable.bg_chip);
```

用 TextView 做标签，设置文本、字号、居中、左右内边距和背景。

## 第 21 行

```java
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,Ui.dp(c,48));lp.setMarginEnd(Ui.dp(c,8));filters.addView(chip,lp);
```

宽 -2 为 WRAP_CONTENT，高 48dp，右间距 8dp，加入容器。

## 第 22 行

```java
            chip.setOnClickListener(v->{filter=label;for(int i=0;i<filters.getChildCount();i++)filters.getChildAt(i).setBackgroundResource(filters.getChildAt(i)==v?R.drawable.bg_accent:R.drawable.bg_chip);render();});
```

点击后更新 filter；遍历标签切换背景，重新渲染动作列表。

## 第 23 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 24 行

```java
        filters.getChildAt(0).setBackgroundResource(R.drawable.bg_accent);
```

初始把第一个“全部”标签设为强调背景。

## 第 25 行

```java
        ((EditText)root.findViewById(R.id.exercise_search)).addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int n,int f){}public void onTextChanged(CharSequence s,int a,int b,int count){render();}public void afterTextChanged(Editable e){}});
```

监听输入文本变化，仅 onTextChanged 调 render；前后回调留空以满足 TextWatcher 契约。

## 第 26 行

```java
        root.findViewById(R.id.exercise_count).setOnLongClickListener(v->{new android.app.AlertDialog.Builder(c).setTitle("高级筛选").setMessage("支持简单条件表达式：\ngroup:上肢 & equipment:徒手\n\n使用 & 组合条件，使用 | 表示满足任一条件；也可以直接输入动作名。").setPositiveButton("知道了",null).show();return true;});
```

长按数量文字显示表达式语法说明，返回 true 表示长按已经处理。

## 第 27 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 28 行

```java
    public View view(){return root;}
```

返回根视图。

## 第 29 行

```java
    public void bind(FitnessViewModel.UiState s){render();}
```

状态变化时重新渲染，参数 s 当前没有直接读取。

## 第 30 行

```java
    private void render(){
```

动作列表渲染入口。

## 第 31 行

```java
        LinearLayout list=root.findViewById(R.id.exercise_list);list.removeAllViews();String query=((EditText)root.findViewById(R.id.exercise_search)).getText().toString();
```

清旧行并读取搜索框字符串。

## 第 32 行

```java
        ExerciseQuery.Expression expression;
```

声明解释器生成的表达式变量。

## 第 33 行

```java
        try{expression=ExerciseQuery.parse(query);}catch(IllegalArgumentException e){Ui.text(root,R.id.exercise_count,e.getMessage());return;}
```

解析失败就把错误显示在数量位置并结束，不保留上次搜索结果。

## 第 34 行

```java
        Set<String> favorites=AppContainer.get().favorites();int count=0;
```

读取收藏集合快照，匹配数量从零开始。

## 第 35 行

```java
        for(Exercise e:ExerciseCatalog.all()){
```

遍历目录全部动作。

## 第 36 行

```java
            if(!expression.matches(e)||(filter.equals("收藏")&&!favorites.contains(e.id))||(!filter.equals("全部")&&!filter.equals("收藏")&&!e.group.equals(filter)))continue;
```

三类拒绝条件用 || 合并：表达式不匹配、收藏标签但未收藏、指定部位不符；满足任何一项就 continue。

## 第 37 行

```java
            count++;View row=LayoutInflater.from(context).inflate(R.layout.item_exercise,list,false);Ui.text(row,R.id.exercise_name,e.name);Ui.text(row,R.id.exercise_meta,e.group+"  ·  "+e.equipmentLabel+"  ·  "+(e.timed?"计时":"计次"));
```

匹配数量加一，加载动作行，显示名字、部位、器械及计量类型。

## 第 38 行

```java
            Ui.text(row,R.id.exercise_symbol,e.group.equals("核心")?"◎":e.group.equals("有氧")?"↗":e.group.equals("活动度")?"≈":"＋");
```

按部位选择简单符号，它不是实际动作识别结果。

## 第 39 行

```java
            TextView favorite=row.findViewById(R.id.exercise_favorite);favorite.setText(favorites.contains(e.id)?"★":"☆");favorite.setContentDescription((favorites.contains(e.id)?"取消收藏":"收藏")+e.name);
```

设置实心/空心收藏星，并为读屏说明收藏或取消收藏哪个动作。

## 第 40 行

```java
            favorite.setOnClickListener(v->{AppContainer.get().favorite(e.id);render();});row.setOnClickListener(v->Ui.detail(context,e));list.addView(row);
```

星号切换收藏后重绘；整行动作详情弹窗；最后加入列表。

## 第 41 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 42 行

```java
        Ui.text(root,R.id.exercise_count,count+" 个动作  ·  点击查看要领，长按此处查看筛选语法");
```

更新真实数量并提示详情和高级搜索入口。

## 第 43 行

```java
        if(count==0)list.addView(Ui.paragraph(context,filter.equals("收藏")?"还没有收藏。点击动作右侧的星标，留下常用动作。":"没有找到匹配动作，试试其他关键词。"));
```

零匹配显示与“收藏为空”或“搜索无结果”对应的空态。

## 第 44 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 45 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
