# app/src/main/java/com/pulse/fitness/ui/HomeScreen.java

首页视图组件，本身不是 Activity，由 MainActivity 放入页面容器。

原文件 SHA-256：`36921c4a58eeab81408854d69bc86984bbb5f3ada29074bb0abf9afb9ef37ca0`。行号仅对应此快照；修改源码后应重新核对。

共 44 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.graphics.Color;
```

导入类型命名空间 android.graphics.Color，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.fitness.R;
```

导入类型命名空间 com.pulse.fitness.R，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.time.*;
```

导入类型命名空间 java.time.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.time.format.DateTimeFormatter;
```

导入类型命名空间 java.time.format.DateTimeFormatter，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 13 行

```java
public final class HomeScreen implements Screen {
```

定义 public final class HomeScreen implements Screen。实现 Screen 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 14 行

```java
    private final View root;private final Context context;private final NavigationMediator navigation;
```

保存根 View、Android Context 和导航中介。

## 第 15 行

```java
    private FitnessViewModel.UiState state;
```

最近一次绑定的 UI 状态，用于部分点击事件。

## 第 16 行

```java
    public HomeScreen(Context c,FitnessViewModel vm,NavigationMediator navigation){
```

构造器接收上下文、共享 VM 和导航；其中 VM 参数当前未使用，数据通过 bind 传入。

## 第 17 行

```java
        context=c;this.navigation=navigation;root=Ui.screen(c,R.layout.screen_home);
```

保存依赖并加载首页 XML。

## 第 18 行

```java
        root.findViewById(R.id.home_avatar).setOnClickListener(v->navigation.show(NavigationMediator.Tab.PROFILE));
```

头像点击请求中介转“我的”。

## 第 19 行

```java
        root.findViewById(R.id.home_all_plan).setOnClickListener(v->navigation.show(NavigationMediator.Tab.PLAN));
```

全部计划入口请求中介转计划页。

## 第 20 行

```java
        root.findViewById(R.id.home_start).setOnClickListener(v->{if(state.profile==null)navigation.show(NavigationMediator.Tab.PROFILE);else if(state.plan==null)navigation.show(NavigationMediator.Tab.PLAN);else navigation.startTraining(state.plan.days.get(LocalDate.now().getDayOfWeek().getValue()-1));});
```

初始开练回调：缺档案去个人页，缺计划去计划页，否则找今天；bind 会用更完整的恢复日处理覆盖此回调。

## 第 21 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 22 行

```java
    public View view(){return root;}
```

返回根视图，供主容器挂载。

## 第 23 行

```java
    public void bind(FitnessViewModel.UiState s){
```

接收一份状态并刷新页面。

## 第 24 行

```java
        state=s;Ui.text(root,R.id.home_date,LocalDate.now().format(DateTimeFormatter.ofPattern("MM 月 dd 日  ·  EEEE",java.util.Locale.CHINA))+"  /  LET'S MOVE");
```

保存状态，用中国区域格式显示当前日期、星期及英文装饰文字。

## 第 25 行

```java
        Ui.text(root,R.id.home_greeting,s.profile==null?"今天，为自己开练。":s.profile.name+"，今天也要加油。" );
```

有档案显示昵称问候，无档案显示默认句子。

## 第 26 行

```java
        Ui.text(root,R.id.home_avatar,s.profile==null?"你":s.profile.name.substring(0,1));
```

头像用昵称第一个 UTF-16 字符；常见中文可用，复杂 emoji 可能不是完整字素。

## 第 27 行

```java
        Ui.text(root,R.id.home_subtitle,s.profile==null?"一点进步，也值得认真对待。":Ui.goal(s.profile)+"  ·  "+s.profile.daysPerWeek+" 天 / 周  ·  按自己的节奏前进");
```

显示目标、每周训练天数或默认副标题。

## 第 28 行

```java
        Ui.text(root,R.id.home_source,s.plan==null?"PERSONAL TRAINING":s.plan.source==WeekPlan.Source.AI?"AI PERSONAL PLAN":"LOCAL PERSONAL PLAN");
```

根据真实来源显示 AI/LOCAL 标识；无计划显示默认栏目名。

## 第 29 行

```java
        DayPlan today=s.plan==null?null:s.plan.days.get(LocalDate.now().getDayOfWeek().getValue()-1);
```

Java 星期值为周一 1 到周日 7，减 1 映射计划 0–6；无计划则 today=null。

## 第 30 行

```java
        Ui.text(root,R.id.home_plan_hint,today==null?"从一份专属计划开始":today.isRest()?"今天轻松恢复，明天继续进步":today.title);
```

无今日计划显示引导，恢复日显示恢复提示，否则显示日标题。

## 第 31 行

```java
        Ui.text(root,R.id.home_start,s.profile==null?"完善档案  ↗":s.plan==null?"创建计划  ↗":today.isRest()?"查看恢复日  ↗":"开始今日训练  ↗");
```

根据档案/计划/恢复状态设置主按钮文案；三元表达式按顺序选择。

## 第 32 行

```java
        root.findViewById(R.id.home_start).setEnabled(!s.busy);
```

生成期间禁用首页主按钮。

## 第 33 行

```java
        root.findViewById(R.id.home_start).setOnClickListener(v->{if(s.profile==null)navigation.show(NavigationMediator.Tab.PROFILE);else if(s.plan==null||today.isRest())navigation.show(NavigationMediator.Tab.PLAN);else navigation.startTraining(today);});
```

重新设置主按钮回调：档案缺失先填档案，计划缺失或恢复日转计划，其余才开练。

## 第 34 行

```java
        int count=0,seconds=0;for(TrainingRecord r:com.pulse.fitness.AppContainer.get().viewModel.history()){seconds+=r.activeSeconds;if(r.completedAt>=Ui.weekStart())count++;}
```

扫描全部历史，seconds 累加全部时长，count 只统计本周；因此首页分钟数是累计而次数是本周，阅读时注意两者口径。

## 第 35 行

```java
        Ui.text(root,R.id.home_sessions,count+" 次");Ui.text(root,R.id.home_minutes,(seconds/60)+" 分钟");
```

显示次数和向下取整的累计分钟。

## 第 36 行

```java
        LinearLayout week=root.findViewById(R.id.home_week);week.removeAllViews();int currentDay=LocalDate.now().getDayOfWeek().getValue()-1;
```

清空七日条，取得今日星期索引。

## 第 37 行

```java
        for(int i=0;i<7;i++){
```

循环创建七个星期格。

## 第 38 行

```java
            final int index=i;boolean train=s.plan!=null&&!s.plan.days.get(i).isRest();TextView chip=new TextView(context);
```

取是否训练日并创建 TextView；index 变量当前没有后续使用。

## 第 39 行

```java
            chip.setGravity(Gravity.CENTER);chip.setText("一二三四五六日".substring(i,i+1)+"\n\n"+(train?"●":"—"));chip.setTextSize(12);chip.setTextColor(Color.parseColor(i==currentDay?"#19271F":"#748076"));chip.setBackgroundResource(i==currentDay?R.drawable.bg_accent:R.drawable.bg_card);
```

设置居中、星期及圆点/横线、字号、颜色和今日强调背景。

## 第 40 行

```java
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);if(i>0)lp.setMarginStart(Ui.dp(context,5));week.addView(chip,lp);chip.setContentDescription("星期"+"一二三四五六日".charAt(i)+(train?"，训练日":"，恢复日"));chip.setOnClickListener(v->navigation.show(NavigationMediator.Tab.PLAN));
```

0 宽+权重 1 使七格均分；设置间距、读屏描述及跳转计划页点击事件。

## 第 41 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 42 行

```java
        Ui.text(root,R.id.home_tip,s.plan==null?"先完善档案，再为自己安排一周的训练节奏。":"绿色圆点为训练日。恢复和训练一样，都是进步的一部分。" );
```

根据是否有计划显示底部提醒。

## 第 43 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 44 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
