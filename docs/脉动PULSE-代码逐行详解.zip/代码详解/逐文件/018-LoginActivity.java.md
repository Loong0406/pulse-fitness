# app/src/main/java/com/pulse/fitness/ui/LoginActivity.java

登录页控制器：加载 XML、响应输入、演示码弹窗、生命周期倒计时与页面跳转。

原文件 SHA-256：`eea275bbe93da1bc7277a9672a0b0123d9211e8db95dd5de0670766906e50440`。行号仅对应此快照；修改源码后应重新核对。

共 86 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.app.Activity;
```

导入类型命名空间 android.app.Activity，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.app.AlertDialog;
```

导入类型命名空间 android.app.AlertDialog，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.content.Intent;
```

导入类型命名空间 android.content.Intent，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.os.Build;
```

导入类型命名空间 android.os.Build，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import android.os.Bundle;
```

导入类型命名空间 android.os.Bundle，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import android.os.Handler;
```

导入类型命名空间 android.os.Handler，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import android.os.Looper;
```

导入类型命名空间 android.os.Looper，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import android.view.View;
```

导入类型命名空间 android.view.View，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import android.view.inputmethod.EditorInfo;
```

导入类型命名空间 android.view.inputmethod.EditorInfo，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
import android.view.inputmethod.InputMethodManager;
```

导入类型命名空间 android.view.inputmethod.InputMethodManager，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 13 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 14 行

```java
import com.pulse.core.auth.DemoPhoneAuth;
```

导入类型命名空间 com.pulse.core.auth.DemoPhoneAuth，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 15 行

```java
import com.pulse.fitness.AppContainer;
```

导入类型命名空间 com.pulse.fitness.AppContainer，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 16 行

```java
import com.pulse.fitness.R;
```

导入类型命名空间 com.pulse.fitness.R，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 17 行

```java
import com.pulse.fitness.presentation.LoginViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.LoginViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 18 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 19 行

```java
/** Phone-code entry flow. The demo never sends SMS or authenticates a remote account. */
```

源码注释，不参与执行。登录页控制器：加载 XML、响应输入、演示码弹窗、生命周期倒计时与页面跳转。

## 第 20 行

```java
public final class LoginActivity extends Activity {
```

定义 public final class LoginActivity extends Activity。继承 Activity 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 21 行

```java
    public static final String FORCE_LOGIN="force_login";
```

强制显示登录页的 Intent 参数键；游客从“我的”点击登录时用它绕过自动进入主页。

## 第 22 行

```java
    private final Handler handler=new Handler(Looper.getMainLooper());
```

主线程 Handler，避免在其他线程更新按钮。

## 第 23 行

```java
    private LoginViewModel vm;
```

登录意图处理对象，onCreate 中创建。

## 第 24 行

```java
    private EditText phone,code;
```

手机号和验证码输入框引用。

## 第 25 行

```java
    private CheckBox agreed;
```

协议勾选框引用。

## 第 26 行

```java
    private Button sendCode;
```

获取验证码按钮引用。

## 第 27 行

```java
    private TextView error;
```

展示错误提示的文字控件。

## 第 28 行

```java
    private String pendingCode,pendingPhone;
```

暂存正在展示弹窗的验证码和号码，便于旋转屏幕后恢复弹窗。

## 第 29 行

```java
    private final Runnable countdown=new Runnable(){public void run(){if(sendCode==null)return;updateCountdown();handler.postDelayed(this,1000);}};
```

每次运行先更新倒计时，再延迟 1000ms 调度自身；这里的 this 是 Runnable，不是 Activity。

## 第 30 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 31 行

```java
    @Override protected void onCreate(Bundle saved){
```

Android 创建页面时回调，saved 为系统保存的临时界面状态。

## 第 32 行

```java
        super.onCreate(saved);AppContainer container=AppContainer.get();
```

先调用父类，再取得应用依赖容器。

## 第 33 行

```java
        if(container.sessions.canEnterApp()&&!getIntent().getBooleanExtra(FORCE_LOGIN,false)){openMain();return;}
```

已有游客/演示身份且没有强制登录标记时，直接进入主页并 return，后续控件不会初始化。

## 第 34 行

```java
        setContentView(R.layout.activity_login);View root=findViewById(R.id.auth_root);Ui.insets(this,root,0);
```

加载 activity_login.xml；取得根容器，使用 Ui.insets 避让系统栏和键盘。

## 第 35 行

```java
        vm=new LoginViewModel(container.phoneAuth,container.sessions);
```

用容器里的共享规则及会话存储创建 LoginViewModel。

## 第 36 行

```java
        phone=findViewById(R.id.auth_phone);code=findViewById(R.id.auth_code);agreed=findViewById(R.id.auth_agree);sendCode=findViewById(R.id.auth_get_code);error=findViewById(R.id.auth_error);
```

按 XML 中五个 id 绑定控件；R 是资源编译器生成的索引类。

## 第 37 行

```java
        if(Build.VERSION.SDK_INT>=28){findViewById(R.id.auth_headline).setAccessibilityHeading(true);findViewById(R.id.auth_title).setAccessibilityHeading(true);}
```

API 28 起将两个标题设为无障碍标题；版本判断避免旧系统调用不存在的方法。

## 第 38 行

```java
        root.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{
```

注册根布局尺寸变化回调，参数 l/t/r/b 是新边界，ol 等是旧边界。

## 第 39 行

```java
            View content=findViewById(R.id.auth_content);int width=(r-l)>Ui.dp(this,600)?Ui.dp(this,560):-1;
```

视口超过 600dp 就把内容限制为 560dp，否则宽度 -1 即 MATCH_PARENT。

## 第 40 行

```java
            if(content.getLayoutParams().width!=width){android.view.ViewGroup.LayoutParams p=content.getLayoutParams();p.width=width;content.setLayoutParams(p);}
```

仅宽度确实变化才更新 LayoutParams，避免无意义地触发重复布局。

## 第 41 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 42 行

```java
        sendCode.setOnClickListener(v->requestCode());
```

注册获取码按钮回调，点击时才执行 requestCode，不是注册时执行。

## 第 43 行

```java
        findViewById(R.id.auth_login).setOnClickListener(v->login());
```

注册登录按钮回调。

## 第 44 行

```java
        findViewById(R.id.auth_guest).setOnClickListener(v->{vm.enterGuest();openMain();});
```

游客按钮先保存游客选择，再进入主页。

## 第 45 行

```java
        findViewById(R.id.auth_terms).setOnClickListener(v->showLegal(false));
```

用户协议入口，false 表示非隐私文档。

## 第 46 行

```java
        findViewById(R.id.auth_privacy).setOnClickListener(v->showLegal(true));
```

隐私政策入口，true 表示读取隐私文档。

## 第 47 行

```java
        code.setOnEditorActionListener((view,action,event)->{if(action==EditorInfo.IME_ACTION_DONE){login();return true;}return false;});
```

键盘 Done 动作触发登录并返回 true 表示已处理；其他动作返回 false。

## 第 48 行

```java
        if(saved!=null){
```

系统提供恢复状态时进入恢复逻辑。

## 第 49 行

```java
            String oldError=saved.getString("error");if(oldError!=null&&!oldError.isEmpty())showError(oldError);
```

恢复非空错误信息并显示，避免旋转后错误提示突然消失。

## 第 50 行

```java
            pendingCode=saved.getString("pendingCode");pendingPhone=saved.getString("pendingPhone");
```

读取之前尚在显示的演示码和号码。

## 第 51 行

```java
            if(pendingCode!=null&&pendingPhone!=null)showDemoCode();
```

两者都存在才重新显示弹窗；输入框本身通常由 Android 根据 id 恢复文本。

## 第 52 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 53 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 54 行

```java
    @Override protected void onStart(){super.onStart();if(sendCode!=null)handler.post(countdown);}
```

页面可见时启动刷新；若 onCreate 已直接跳主页，sendCode 为空，不启动计时。

## 第 55 行

```java
    @Override protected void onStop(){handler.removeCallbacks(countdown);super.onStop();}
```

页面不可见时移除 Runnable，防止旧 Activity 持续被 Handler 引用。

## 第 56 行

```java
    @Override protected void onSaveInstanceState(Bundle out){
```

开始保存界面临时状态，用于旋转或系统重建。

## 第 57 行

```java
        super.onSaveInstanceState(out);if(error!=null)out.putString("error",error.getVisibility()==View.VISIBLE?error.getText().toString():"");
```

调父类保存控件状态；记录当前可见错误，否则保存空串。

## 第 58 行

```java
        out.putString("pendingCode",pendingCode);out.putString("pendingPhone",pendingPhone);
```

保存待展示码和号码；这是演示设计，真实验证码不应作为可信秘密保存在客户端。

## 第 59 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 60 行

```java
    private void requestCode(){
```

请求码的页面操作入口。

## 第 61 行

```java
        try{
```

try 包裹可能由格式、协议或冷却限制产生的参数异常。

## 第 62 行

```java
            DemoPhoneAuth.CodeDelivery delivery=vm.requestCode(phone.getText().toString(),agreed.isChecked());
```

从控件读取号码和勾选状态，交给 ViewModel；结果是本机生成的 CodeDelivery。

## 第 63 行

```java
            error.setVisibility(View.GONE);pendingPhone=delivery.phone;pendingCode=delivery.code;updateCountdown();showDemoCode();
```

隐藏旧错误，记住号码和码，立即更新按钮，再显示演示弹窗。

## 第 64 行

```java
        }catch(IllegalArgumentException failure){showError(failure.getMessage());}
```

捕获可预期参数错误，把异常提示显示给用户。

## 第 65 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 66 行

```java
    private void showDemoCode(){
```

开始构造演示码弹窗。

## 第 67 行

```java
        View body=Ui.screen(this,R.layout.dialog_demo_code);Ui.text(body,R.id.demo_code_value,pendingCode);
```

加载独立弹窗 XML，并将 pendingCode 写到码的文字控件。

## 第 68 行

```java
        String masked=pendingPhone.substring(0,3)+" **** "+pendingPhone.substring(7);
```

将号码中间四位替换为星号；规则层已保证号码有 11 位，所以下标有效。

## 第 69 行

```java
        Ui.text(body,R.id.demo_code_description,getString(R.string.auth_demo_code_explanation,masked));
```

将脱敏号码填进带占位符的说明资源。

## 第 70 行

```java
        new AlertDialog.Builder(this,R.style.AuthDialogTheme).setTitle(R.string.auth_demo_title).setView(body)
```

使用登录专用对话框主题，设置标题和自定义内容。

## 第 71 行

```java
                .setPositiveButton(R.string.auth_fill_code,(dialog,which)->{
```

设置正按钮“填入验证码”，下一行是点击后的动作。

## 第 72 行

```java
                    code.setText(pendingCode);pendingCode=null;pendingPhone=null;code.clearFocus();
```

填写输入框、清除待弹窗状态、取消焦点；此时尚未验证登录。

## 第 73 行

```java
                    InputMethodManager keyboard=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);keyboard.hideSoftInputFromWindow(code.getWindowToken(),0);
```

获取输入法服务并请求收起软键盘，令登录按钮更容易看见。

## 第 74 行

```java
                }).setNegativeButton(R.string.auth_manual_code,(dialog,which)->{pendingCode=null;pendingPhone=null;code.requestFocus();})
```

负按钮让用户手动输入，清空弹窗恢复标记并把焦点给验证码框。

## 第 75 行

```java
                .setOnCancelListener(dialog->{pendingCode=null;pendingPhone=null;}).show();
```

点击外部/返回取消弹窗也清空待展示状态；最后 show 才真正展示。

## 第 76 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 77 行

```java
    private void login(){
```

登录的页面操作入口。

## 第 78 行

```java
        try{vm.login(phone.getText().toString(),code.getText().toString(),agreed.isChecked());findViewById(R.id.auth_login).setEnabled(false);openMain();}
```

读取手机号、验证码及协议，交给 ViewModel；成功后禁用按钮并进入主页，防止重复点击。

## 第 79 行

```java
        catch(IllegalArgumentException failure){showError(failure.getMessage());}
```

失败时保留页面并显示参数错误。

## 第 80 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 81 行

```java
    private void updateCountdown(){int remaining=vm.resendSeconds();sendCode.setEnabled(remaining==0);sendCode.setText(remaining==0?getString(R.string.auth_get_code):getString(R.string.auth_resend_countdown,remaining));}
```

用业务截止时间计算 remaining；0 时启用获取按钮，非 0 显示带秒数的重发文案。时间按真实经过计算，不会因 Handler 延迟累计漂移。

## 第 82 行

```java
    private void showError(String message){error.setText(message);error.setVisibility(View.VISIBLE);}
```

设置错误文案并把 GONE 改为 VISIBLE；XML 的 liveRegion 帮助读屏提示变化。

## 第 83 行

```java
    private void showLegal(boolean privacy){startActivity(new Intent(this,AuthLegalActivity.class).putExtra(AuthLegalActivity.PRIVACY,privacy));}
```

启动协议 Activity，并通过布尔 Extra 告知读取哪份资产。

## 第 84 行

```java
    private void openMain(){startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();}
```

跳到 Main：CLEAR_TOP 可清理其上页面，SINGLE_TOP 可复用栈顶实例；随后 finish 关闭登录页。

## 第 85 行

```java
    public static void openFresh(Activity owner){owner.startActivity(new Intent(owner,LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));owner.finish();}
```

退出登录后创建干净登录任务：NEW_TASK|CLEAR_TASK 清除旧页面栈，防止返回键回到之前主页，再关闭调用页。

## 第 86 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
