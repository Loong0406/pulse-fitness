# app/src/main/java/com/pulse/fitness/ui/MainActivity.java

五个主页面的宿主与导航中介；负责切页、打开训练、调用系统文件选择器导出。

原文件 SHA-256：`37b8202ccffbc93e56bc0e29fdc6488658ff540cf296ba8aeed2a147203c585e`。行号仅对应此快照；修改源码后应重新核对。

共 71 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.app.*;
```

导入类型命名空间 android.app.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.content.*;
```

导入类型命名空间 android.content.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.graphics.Color;
```

导入类型命名空间 android.graphics.Color，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.os.Bundle;
```

导入类型命名空间 android.os.Bundle，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.fitness.*;
```

导入类型命名空间 com.pulse.fitness.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
import com.pulse.core.export.PlanExporter;
```

导入类型命名空间 com.pulse.core.export.PlanExporter，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 13 行

```java
import com.pulse.core.util.*;
```

导入类型命名空间 com.pulse.core.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 14 行

```java
import java.io.*;
```

导入类型命名空间 java.io.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 15 行

```java
import java.nio.charset.StandardCharsets;
```

导入类型命名空间 java.nio.charset.StandardCharsets，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 16 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 17 行

```java
public final class MainActivity extends Activity implements NavigationMediator {
```

定义 public final class MainActivity extends Activity implements NavigationMediator。继承 Activity 的实现与扩展点。实现 NavigationMediator 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 18 行

```java
    private final int[] navigation={R.id.nav_home,R.id.nav_plan,R.id.nav_exercise,R.id.nav_progress,R.id.nav_profile};
```

五个导航控件 ID，顺序必须与 Tab 枚举一致。

## 第 19 行

```java
    private FitnessViewModel vm;
```

共享业务 ViewModel 引用。

## 第 20 行

```java
    private Screen screen;
```

当前展示的 Screen 对象。

## 第 21 行

```java
    private Tab current=Tab.HOME;
```

默认显示首页。

## 第 22 行

```java
    private WeekPlan exportSnapshot;
```

正在导出的计划快照，避免用户选文件期间数据变化影响导出内容。

## 第 23 行

```java
    private boolean exportJson;
```

true 导出 JSON，false 导出易读文本。

## 第 24 行

```java
    private final ObservableState.Listener<FitnessViewModel.UiState> observer=state->{if(screen!=null)screen.bind(state);};
```

定义观察者：收到状态时只更新当前 Screen，不遍历全部页面。

## 第 25 行

```java
    @Override protected void onCreate(Bundle state){
```

页面创建入口。

## 第 26 行

```java
        super.onCreate(state);
```

调父类初始化。

## 第 27 行

```java
        if(!AppContainer.get().sessions.canEnterApp()){startActivity(new Intent(this,LoginActivity.class));finish();return;}
```

没有本机身份时跳登录、关闭自己并 return，不能继续初始化主界面。

## 第 28 行

```java
        setContentView(R.layout.activity_main);Ui.insets(this,findViewById(R.id.root),0);vm=AppContainer.get().viewModel;
```

加载主 XML、避让系统栏，并取得应用级 ViewModel。

## 第 29 行

```java
        for(int i=0;i<navigation.length;i++){final Tab tab=Tab.values()[i];findViewById(navigation[i]).setOnClickListener(v->show(tab));}
```

为五个导航绑定对应 Tab；用 final 局部变量使每个回调捕获自己的标签。

## 第 30 行

```java
        if(state!=null){try{current=Tab.valueOf(state.getString("tab","HOME"));String plan=state.getString("exportPlan");if(plan!=null)exportSnapshot=JsonCodec.plan(plan);exportJson=state.getBoolean("exportJson");}catch(RuntimeException ignored){}}
```

从系统状态恢复上次标签、导出快照和格式；坏状态忽略，使用默认值。

## 第 31 行

```java
        show(current);
```

展示恢复的标签或首页。

## 第 32 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
    @Override protected void onStart(){super.onStart();if(vm!=null){vm.refresh();vm.state.observe(observer);}}
```

可见时刷新并订阅；observe 会立即回调当前状态，故页面马上得到数据。

## 第 34 行

```java
    @Override protected void onStop(){if(vm!=null)vm.state.remove(observer);super.onStop();}
```

不可见时移除同一个观察者引用，避免隐藏 Activity 被状态容器留住。

## 第 35 行

```java
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("tab",current.name());if(exportSnapshot!=null)state.putString("exportPlan",JsonCodec.plan(exportSnapshot));state.putBoolean("exportJson",exportJson);}
```

保存当前标签及待导出快照、格式，用于系统重建。

## 第 36 行

```java
    @Override public void show(Tab tab){
```

实现中介的切页接口。

## 第 37 行

```java
        current=tab;
```

记录当前标签，供重建保存。

## 第 38 行

```java
        switch(tab){case HOME:screen=new HomeScreen(this,vm,this);break;case PLAN:screen=new PlanScreen(this,vm,this);break;case EXERCISES:screen=new ExercisesScreen(this);break;case PROGRESS:screen=new ProgressScreen(this,vm);break;default:screen=new ProfileScreen(this,vm,this);}
```

按标签创建对应 Screen；其他页面只依赖中介，无需引用彼此。

## 第 39 行

```java
        FrameLayout container=findViewById(R.id.page_container);container.removeAllViews();container.addView(screen.view());screen.bind(vm.state.get());
```

清空旧视图，把新 Screen 的 View 放进 FrameLayout，再绑定当前状态；切页会重新创建 Screen。

## 第 40 行

```java
        for(int i=0;i<navigation.length;i++){TextView item=findViewById(navigation[i]);boolean selected=i==tab.ordinal();item.setSelected(selected);item.setTextColor(Color.parseColor(selected?"#274D30":"#748076"));for(android.graphics.drawable.Drawable icon:item.getCompoundDrawables())if(icon!=null)icon.setTint(Color.parseColor(selected?"#274D30":"#748076"));}
```

按 ordinal 更新选中状态、文字及图标颜色；遍历复合 Drawable 为其着色。

## 第 41 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 42 行

```java
    @Override public void startTraining(DayPlan day){
```

响应某日“开练”意图。

## 第 43 行

```java
        if(day==null||day.isRest()){Ui.toast(this,"今天是恢复日，轻松活动即可。");return;}
```

空日程或恢复日只提示，不进入训练会话。

## 第 44 行

```java
        AppContainer c=AppContainer.get();WeekPlan plan=vm.state.get().plan;
```

取得容器及当前状态中的计划。

## 第 45 行

```java
        if(plan==null){show(Tab.PLAN);return;}
```

没计划就转计划页并结束。

## 第 46 行

```java
        String key=plan.id+":"+day.dayIndex;
```

用“计划ID:日索引”作为训练进度键，防止不同计划同一星期混用快照。

## 第 47 行

```java
        if(c.data.contains("session")&&!key.equals(c.data.getString("session_day",""))){
```

若有未结束快照且属于别的训练日，先处理冲突。

## 第 48 行

```java
            new AlertDialog.Builder(this).setTitle("有一场训练尚未结束").setMessage("开始新的训练会替换未完成进度。").setNegativeButton("保留进度",(d,w)->openWorkout(c.data.getString("session_day",""))).setPositiveButton("开始新的训练",(d,w)->{c.data.edit().remove("session").remove("session_day").apply();openWorkout(key);}).show();
```

提供保留旧进度/开始新训练两项；保留打开旧日键，新训练先删旧快照再打开新键。

## 第 49 行

```java
        }else openWorkout(key);
```

没冲突直接打开训练页。

## 第 50 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 51 行

```java
    private void openWorkout(String key){Intent intent=new Intent(this,WorkoutActivity.class);intent.putExtra("dayKey",key);startActivity(intent);}
```

创建显式 Intent，携带 dayKey，再启动 WorkoutActivity。

## 第 52 行

```java
    @Override public void exportPlan(){
```

开始导出交互。

## 第 53 行

```java
        WeekPlan p=vm.state.get().plan;if(p==null){Ui.toast(this,"请先生成训练计划");return;}
```

没计划先提示并返回。

## 第 54 行

```java
        new AlertDialog.Builder(this).setTitle("导出训练计划").setItems(new String[]{"易读文本 .txt","结构化数据 .json"},(dialog,which)->{
```

弹窗让用户选择文本或 JSON。

## 第 55 行

```java
            exportSnapshot=p;exportJson=which==1;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(exportJson?"application/json":"text/plain");intent.putExtra(Intent.EXTRA_TITLE,"PULSE-训练计划-"+java.time.LocalDate.now()+(exportJson?".json":".txt"));startActivityForResult(intent,41);
```

捕获计划快照；用 ACTION_CREATE_DOCUMENT 请求用户选保存位置，设置 MIME、默认文件名，41 是本次请求码。

## 第 56 行

```java
        }).show();
```

关闭回调定义并展示选择弹窗。

## 第 57 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 58 行

```java
    @Override protected void onActivityResult(int request,int result,Intent data){
```

系统文件选择返回时的回调。

## 第 59 行

```java
        super.onActivityResult(request,result,data);if(request!=41||result!=RESULT_OK||data==null||data.getData()==null||exportSnapshot==null)return;
```

先调父类；请求码不对、用户取消、无 URI 或快照缺失均直接返回。

## 第 60 行

```java
        try{
```

开始可失败的文件写入。

## 第 61 行

```java
            PlanExporter.Sink sink=new AndroidDocumentSink(getContentResolver(),data.getData());
```

用 ContentResolver 和用户授权 URI 创建 Android 输出目标。

## 第 62 行

```java
            PlanExporter exporter=exportJson?new PlanExporter.Json(sink):new PlanExporter.Text(sink);exporter.export(exportSnapshot);Ui.toast(this,"训练计划已导出");
```

按格式选导出器，交给共同 Sink，再提示成功；格式与目标两个维度可独立替换。

## 第 63 行

```java
        }catch(Exception e){Ui.toast(this,"导出失败，请选择可写入的位置");}finally{exportSnapshot=null;}
```

失败提示可写位置问题，finally 清导出快照，避免下一次误用。

## 第 64 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 65 行

```java
    /** Bridge implementation: the same sink supports every export format. */
```

源码注释，不参与执行。桥接输出实现：同一个 Android 文档 Sink 可以接收任意导出格式的文本。

## 第 66 行

```java
    private static final class AndroidDocumentSink implements PlanExporter.Sink {
```

系统文档写入的桥接实现，static 内部类避免隐式持有 Activity。

## 第 67 行

```java
        private final ContentResolver resolver;private final android.net.Uri uri;
```

保存系统内容解析器及文件 URI，不是假定绝对文件路径。

## 第 68 行

```java
        AndroidDocumentSink(ContentResolver resolver,android.net.Uri uri){this.resolver=resolver;this.uri=uri;}
```

构造器注入二者。

## 第 69 行

```java
        public void write(String text)throws IOException{try(OutputStream out=resolver.openOutputStream(uri,"wt")){if(out==null)throw new IOException("无法创建文件");out.write(text.getBytes(StandardCharsets.UTF_8));}}
```

以 wt 写入并截断文档；流为空抛 IOException，否则 UTF-8 写出，try 自动关闭。无需申请整个存储盘权限。

## 第 70 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 71 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
