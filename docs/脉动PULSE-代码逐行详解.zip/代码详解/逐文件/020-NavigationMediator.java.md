# app/src/main/java/com/pulse/fitness/ui/NavigationMediator.java

页面之间的导航契约，各 Screen 不直接引用其他 Screen。

原文件 SHA-256：`4aa479f64a80b82e92ddf881e4a8c98a1217ae2b45c382586602d4e1c355d198`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.DayPlan;
```

导入类型命名空间 com.pulse.core.model.DayPlan，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 4 行

```java
/** Mediator: independent screens communicate through navigation intentions. */
```

源码注释，不参与执行。页面之间的导航契约，各 Screen 不直接引用其他 Screen。

## 第 5 行

```java
public interface NavigationMediator {
```

定义 public interface NavigationMediator。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 6 行

```java
    enum Tab { HOME, PLAN, EXERCISES, PROGRESS, PROFILE }
```

五个 Tab 枚举，声明顺序与底部导航 ID 数组一致。

## 第 7 行

```java
    void show(Tab tab);
```

请求展示某个标签。

## 第 8 行

```java
    void startTraining(DayPlan day);
```

请求开始指定日计划的训练。

## 第 9 行

```java
    void exportPlan();
```

请求导出当前计划，由宿主决定系统交互细节。

## 第 10 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
