# app/src/main/java/com/pulse/fitness/ui/PlanScreen.java

计划页面：明确模型数据发送范围，区分离线/AI 来源，展示周计划和动作详情。

原文件 SHA-256：`41e9003b13370c97bc1cbacaac7c8be65f0069ab9b1c3a51beeebb8b8175663a`。行号仅对应此快照；修改源码后应重新核对。

共 46 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.app.AlertDialog;
```

导入类型命名空间 android.app.AlertDialog，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.fitness.R;
```

导入类型命名空间 com.pulse.fitness.R，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 12 行

```java
public final class PlanScreen implements Screen {
```

定义 public final class PlanScreen implements Screen。实现 Screen 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 13 行

```java
    private final View root;private final Context context;private final FitnessViewModel vm;private final NavigationMediator navigation;
```

保存视图、Context、VM、导航四个依赖。

## 第 14 行

```java
    private WeekPlan rendered;
```

记录上次渲染的计划对象引用，减少重复重建七天列表。

## 第 15 行

```java
    public PlanScreen(Context c,FitnessViewModel vm,NavigationMediator navigation){
```

构造器接收依赖。

## 第 16 行

```java
        context=c;this.vm=vm;this.navigation=navigation;root=Ui.screen(c,R.layout.screen_plan);
```

保存依赖并加载 screen_plan。

## 第 17 行

```java
        root.findViewById(R.id.plan_ai).setOnClickListener(v->{
```

AI 按钮点击回调开始。

## 第 18 行

```java
            if(vm.state.get().profile==null){navigation.show(NavigationMediator.Tab.PROFILE);return;}
```

没档案先跳个人页并返回。

## 第 19 行

```java
            new AlertDialog.Builder(c).setTitle("为你生成专属计划").setMessage("将年龄、身高体重、目标、训练经验、器械、可用时间和动作限制发送到你配置的 AI 服务。模型调用由该服务完成，模型不会收到昵称或性别。请确认服务地址可信。").setNegativeButton("取消",null).setPositiveButton("同意并生成",(d,w)->vm.generate(true)).show();
```

显示数据发送说明，只有点“同意并生成”才调用 generate(true)，取消不发送。

## 第 20 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 21 行

```java
        root.findViewById(R.id.plan_local).setOnClickListener(v->{if(vm.state.get().profile==null)navigation.show(NavigationMediator.Tab.PROFILE);else vm.generate(false);});
```

本地按钮无档案转个人页，否则 generate(false)。

## 第 22 行

```java
        root.findViewById(R.id.plan_copy).setOnClickListener(v->new AlertDialog.Builder(c).setTitle("开始新的训练周期").setMessage("沿用这份计划创建新周期；未完成的训练进度会重置，历史记录会保留。").setNegativeButton("取消",null).setPositiveButton("创建新周期",(d,w)->vm.copyPlan()).show());
```

复制周期先确认会重置未完成训练，确认后调用 VM 的 copyPlan。

## 第 23 行

```java
        root.findViewById(R.id.plan_export).setOnClickListener(v->navigation.exportPlan());
```

导出请求交给中介，由宿主 Activity 与系统文档选择器交互。

## 第 24 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 25 行

```java
    public View view(){return root;}
```

返回页面根视图。

## 第 26 行

```java
    public void bind(FitnessViewModel.UiState s){
```

根据状态更新计划页。

## 第 27 行

```java
        Ui.text(root,R.id.plan_summary,s.profile==null?"先完善档案，让训练围绕你的实际情况展开。":Ui.goal(s.profile)+"  /  "+Ui.equipment(s.profile)+"  /  每周 "+s.profile.daysPerWeek+" 天  /  每次 "+s.profile.minutesPerSession+" 分钟");
```

显示目标、器械、周频率和时间预算，无档案显示引导。

## 第 28 行

```java
        Ui.text(root,R.id.plan_source,s.plan==null?"✦ 训练计划，因人而异":s.plan.source==WeekPlan.Source.AI?"✦ 大模型生成 · 已通过规则校验":"◉ 本地规则计划 · 可离线使用");
```

根据 plan.source 显示真实来源，不根据用户点过哪个按钮推断。

## 第 29 行

```java
        Ui.text(root,R.id.plan_note,s.plan==null?"告诉我们你的目标、时间和身体情况，创建一份有训练、有恢复的一周计划。":s.plan.note);
```

无计划显示说明，有计划显示生成的 note。

## 第 30 行

```java
        Ui.text(root,R.id.plan_message,s.message);root.findViewById(R.id.plan_loading).setVisibility(s.busy?View.VISIBLE:View.GONE);
```

显示 VM 提示，按 busy 切换进度条 VISIBLE/GONE。

## 第 31 行

```java
        root.findViewById(R.id.plan_ai).setEnabled(!s.busy);root.findViewById(R.id.plan_local).setEnabled(!s.busy);root.findViewById(R.id.plan_copy).setEnabled(!s.busy&&s.plan!=null);root.findViewById(R.id.plan_export).setEnabled(s.plan!=null);
```

忙碌时禁用两种生成与复制；复制/导出还要求计划存在。

## 第 32 行

```java
        Ui.text(root,R.id.plan_ai,s.busy?"正在安排你的训练…":"✦ 生成 AI 专属计划");
```

忙碌时替换 AI 按钮文案。

## 第 33 行

```java
        if(rendered==s.plan&&((LinearLayout)root.findViewById(R.id.plan_days)).getChildCount()>0)return;
```

若计划对象未变且已有列表，就跳过后续重建。上面的提示和按钮仍会更新。

## 第 34 行

```java
        rendered=s.plan;LinearLayout list=root.findViewById(R.id.plan_days);list.removeAllViews();
```

记住新引用并清空日程容器。

## 第 35 行

```java
        if(s.plan==null){list.addView(Ui.paragraph(context,"计划还未开始。\n点击上方按钮，创建属于你的第一周。"));return;}
```

无计划添加空态文字并返回。

## 第 36 行

```java
        // Iterator: screens traverse the aggregate without accessing its collection implementation.
```

源码注释，不参与执行。迭代器用法：页面通过聚合提供的遍历接口访问日程，不依赖内部集合具体实现。

## 第 37 行

```java
        for(DayPlan day:s.plan){
```

利用 WeekPlan 的 Iterable 遍历，不依赖其内部列表的具体类。

## 第 38 行

```java
            View item=LayoutInflater.from(context).inflate(R.layout.item_day,list,false);Ui.text(item,R.id.day_number,"周"+"一二三四五六日".charAt(day.dayIndex));Ui.text(item,R.id.day_title,day.title);
```

根据 item_day XML 创建行，不立刻挂载；填星期和标题。

## 第 39 行

```java
            Ui.text(item,R.id.day_meta,day.isRest()?"休息 / 轻松活动 / 保持睡眠":day.exercises.size()+" 个动作 · 约 "+PlanStatisticsVisitor.minutes(day)+" 分钟（含热身放松）");
```

恢复日显示休息说明，否则显示动作数及访问者估计分钟。

## 第 40 行

```java
            View start=item.findViewById(R.id.day_start);start.setVisibility(day.isRest()?View.GONE:View.VISIBLE);start.setEnabled(!s.busy);start.setOnClickListener(v->navigation.startTraining(day));
```

恢复日隐藏开练按钮，忙碌时禁用，训练日点击交给导航。

## 第 41 行

```java
            LinearLayout moves=item.findViewById(R.id.day_exercises);
```

取得本日动作容器。

## 第 42 行

```java
            for(Prescription p:day.exercises){TextView line=Ui.paragraph(context,ExerciseCatalog.get(p.exerciseId).name+"\n"+Ui.rx(p));line.setTextSize(12);line.setMinHeight(Ui.dp(context,48));line.setOnClickListener(v->Ui.detail(context,ExerciseCatalog.get(p.exerciseId)));moves.addView(line);}
```

为每个处方创建说明行，点击查目录并弹动作详情；最小高度 48dp 便于触控。

## 第 43 行

```java
            list.addView(item);
```

把完整一天的视图加入七天容器。

## 第 44 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 45 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 46 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
