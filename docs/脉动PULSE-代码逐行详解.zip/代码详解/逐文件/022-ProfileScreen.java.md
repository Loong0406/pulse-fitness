# app/src/main/java/com/pulse/fitness/ui/ProfileScreen.java

个人资料表单、网关连接配置及本机身份入口。下拉框下标与枚举声明顺序相互约定。

原文件 SHA-256：`20de94c36302a610e6f2f0e5c7e6bd6eeb30704176c43bacc10881d9cc0e393d`。行号仅对应此快照；修改源码后应重新核对。

共 68 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.app.AlertDialog;
```

导入类型命名空间 android.app.AlertDialog，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.app.Activity;
```

导入类型命名空间 android.app.Activity，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.content.Intent;
```

导入类型命名空间 android.content.Intent，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.fitness.*;
```

导入类型命名空间 com.pulse.fitness.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import com.pulse.core.model.UserProfile;
```

导入类型命名空间 com.pulse.core.model.UserProfile，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
import java.util.Locale;
```

导入类型命名空间 java.util.Locale，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 13 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 14 行

```java
public final class ProfileScreen implements Screen {
```

定义 public final class ProfileScreen implements Screen。实现 Screen 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 15 行

```java
    private final View root;private final Context context;private final FitnessViewModel vm;
```

保存根布局、Context 和共享 VM。

## 第 16 行

```java
    private final int[] minuteOptions={15,20,30,40,45,60};
```

分钟候选值数组；与显示标签一一对应。

## 第 17 行

```java
    public ProfileScreen(Context c,FitnessViewModel vm,NavigationMediator navigation){
```

构造器接收导航，供保存成功后切计划页。

## 第 18 行

```java
        context=c;this.vm=vm;root=Ui.screen(c,R.layout.screen_profile);
```

保存依赖并加载个人页。

## 第 19 行

```java
        options(R.id.profile_sex,new String[]{"不透露","女","男"});options(R.id.profile_goal,new String[]{"减脂塑形","增肌力量","改善体能"});
```

为性别和目标下拉框设置固定顺序标签。

## 第 20 行

```java
        options(R.id.profile_experience,new String[]{"刚开始训练","已有规律训练","有长期训练经验"});options(R.id.profile_equipment,new String[]{"徒手 / 居家","哑铃 + 徒手","健身房 / 综合器械"});
```

设置经验与器械选项，顺序匹配相应枚举 ordinal。

## 第 21 行

```java
        options(R.id.profile_days,new String[]{"每周 2 天","每周 3 天","每周 4 天","每周 5 天"});options(R.id.profile_minutes,new String[]{"15 分钟","20 分钟","30 分钟","40 分钟","45 分钟","60 分钟"});
```

设置每周天数 2–5 和分钟选项。

## 第 22 行

```java
        populate(vm.state.get().profile);
```

将已存档案或默认值填入表单。

## 第 23 行

```java
        ((EditText)root.findViewById(R.id.profile_endpoint)).setText(AppContainer.get().endpoint());((EditText)root.findViewById(R.id.profile_token)).setText(AppContainer.get().tokens.get());
```

将保存的网关地址、解密后的网关令牌填到连接输入框；令牌输入框在 XML 中使用密码样式。

## 第 24 行

```java
        root.findViewById(R.id.profile_save).setOnClickListener(v->{
```

点击保存开始执行回调。

## 第 25 行

```java
            try{
```

try 覆盖数字解析及校验异常。

## 第 26 行

```java
                UserProfile p=new UserProfile.Builder().name(value(R.id.profile_name)).age(Integer.parseInt(value(R.id.profile_age))).sex((String)spinner(R.id.profile_sex).getSelectedItem())
```

从表单读取昵称、整数年龄、性别选项，开始 Builder 链。

## 第 27 行

```java
                        .body(Double.parseDouble(value(R.id.profile_height)),Double.parseDouble(value(R.id.profile_weight)))
```

身高体重用 Double.parseDouble，非数字在此抛 NumberFormatException。

## 第 28 行

```java
                        .goal(UserProfile.Goal.values()[position(R.id.profile_goal)]).experience(UserProfile.Experience.values()[position(R.id.profile_experience)]).equipment(UserProfile.Equipment.values()[position(R.id.profile_equipment)])
```

按下拉下标选择对应枚举；界面顺序变化必须同步修改映射。

## 第 29 行

```java
                        .schedule(position(R.id.profile_days)+2,minuteOptions[position(R.id.profile_minutes)])
```

天数下标加 2，分钟下标查 minuteOptions，避免把位置误当实际分钟。

## 第 30 行

```java
                        .limitations(checked(R.id.profile_knees),checked(R.id.profile_back),checked(R.id.profile_low_impact),checked(R.id.profile_professional)).build();
```

读取四个复选框，建成新档案。

## 第 31 行

```java
                vm.saveProfile(p);Ui.toast(c,"档案已保存");navigation.show(NavigationMediator.Tab.PLAN);
```

VM 保存成功后提示，并由导航切换计划页；失败不会切页。

## 第 32 行

```java
            }catch(NumberFormatException e){Ui.text(root,R.id.profile_error,"请输入有效的年龄、身高和体重");}
```

数字格式错误显示专用说明。

## 第 33 行

```java
            catch(IllegalArgumentException e){Ui.text(root,R.id.profile_error,e.getMessage());}
```

其他参数校验失败显示业务规则文案。

## 第 34 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 35 行

```java
        root.findViewById(R.id.profile_undo).setOnClickListener(v->{vm.undo();populate(vm.state.get().profile);Ui.toast(c,"已撤销档案修改");});
```

撤销后重新填表，并提示；按钮是否可用由 bind 管理。

## 第 36 行

```java
        root.findViewById(R.id.profile_connect).setOnClickListener(v->vm.testConnection(value(R.id.profile_endpoint),value(R.id.profile_token)));
```

读取连接表单，调用保存并检测网关。

## 第 37 行

```java
        root.findViewById(R.id.profile_account_action).setOnClickListener(v->{
```

账号操作按钮回调开始。

## 第 38 行

```java
            if(!AppContainer.get().sessions.isPhoneSession()){c.startActivity(new Intent(c,LoginActivity.class).putExtra(LoginActivity.FORCE_LOGIN,true));return;}
```

当前是游客则强制打开登录页，保留底下主界面，不自动跳回主页。

## 第 39 行

```java
            new AlertDialog.Builder(c).setTitle(R.string.auth_sign_out_title).setMessage(R.string.auth_sign_out_message).setNegativeButton(R.string.auth_cancel,null).setPositiveButton(R.string.auth_account_sign_out,(d,w)->{
```

演示身份则先弹退出确认。

## 第 40 行

```java
                AppContainer.get().sessions.clear();AppContainer.get().phoneAuth.clear();LoginActivity.openFresh((Activity)c);
```

确认后清身份和演示码，打开新的登录任务；训练档案与历史保留。

## 第 41 行

```java
            }).show();
```

结束并显示退出弹窗。

## 第 42 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 43 行

```java
        root.findViewById(R.id.profile_delete).setOnClickListener(v->new AlertDialog.Builder(c).setTitle("清除本机个人数据？").setMessage("这会删除登录状态、档案、计划、训练记录、收藏、训练进度和服务连接信息。操作无法恢复。").setNegativeButton("取消",null).setPositiveButton("清除数据",(dialog,which)->{vm.reset();LoginActivity.openFresh((Activity)c);Ui.toast(c,"本机数据已清除");}).show());
```

清个人数据的不可恢复操作先确认，再 reset、回新登录页并提示；范围包括服务连接及训练资料。

## 第 44 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 45 行

```java
    public View view(){return root;}
```

返回根视图。

## 第 46 行

```java
    public void bind(FitnessViewModel.UiState s){
```

根据共享状态更新部分动态区域。

## 第 47 行

```java
        root.findViewById(R.id.profile_undo).setEnabled(vm.canUndo());Ui.text(root,R.id.profile_connection_status,s.connection);
```

根据命令是否可撤销控制按钮，显示连接检测结果。

## 第 48 行

```java
        boolean phone=AppContainer.get().sessions.isPhoneSession();
```

读取当前是否有效演示手机号身份。

## 第 49 行

```java
        Ui.text(root,R.id.profile_account_title,context.getString(phone?R.string.auth_account_demo:R.string.auth_account_guest));
```

选择“演示账号”或“游客”的标题。

## 第 50 行

```java
        Ui.text(root,R.id.profile_account_note,phone?context.getString(R.string.auth_account_phone_note,AppContainer.get().sessions.maskedPhone()):context.getString(R.string.auth_account_guest_note));
```

演示身份显示脱敏手机号说明；游客显示本机数据说明。

## 第 51 行

```java
        Ui.text(root,R.id.profile_account_action,context.getString(phone?R.string.auth_account_sign_out:R.string.auth_account_sign_in));
```

按身份显示退出登录或手机号登录按钮文案。

## 第 52 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 53 行

```java
    private void populate(UserProfile raw){
```

根据档案填表的方法。

## 第 54 行

```java
        UserProfile p=raw==null?UserProfile.defaults():raw;
```

无档案时使用默认档案，只预填，不自动保存。

## 第 55 行

```java
        edit(R.id.profile_name,p.name);edit(R.id.profile_age,String.valueOf(p.age));edit(R.id.profile_height,number(p.heightCm));edit(R.id.profile_weight,number(p.weightKg));
```

文本框依次填昵称、年龄、身高和体重。

## 第 56 行

```java
        spinner(R.id.profile_sex).setSelection(p.sex.equals("女")?1:p.sex.equals("男")?2:0);spinner(R.id.profile_goal).setSelection(p.goal.ordinal());spinner(R.id.profile_experience).setSelection(p.experience.ordinal());spinner(R.id.profile_equipment).setSelection(p.equipment.ordinal());spinner(R.id.profile_days).setSelection(p.daysPerWeek-2);
```

性别按文本映射，其余枚举用 ordinal；周天数减 2 映射下拉位置。

## 第 57 行

```java
        int minute=0;for(int i=0;i<minuteOptions.length;i++)if(minuteOptions[i]==p.minutesPerSession)minute=i;spinner(R.id.profile_minutes).setSelection(minute);
```

遍历分钟候选找精确匹配下标；找不到默认第 0 项，即 15 分钟。

## 第 58 行

```java
        check(R.id.profile_knees,p.protectKnees);check(R.id.profile_back,p.protectBack);check(R.id.profile_low_impact,p.lowImpact);check(R.id.profile_professional,p.needsProfessional);
```

填写四个限制勾选框。

## 第 59 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 60 行

```java
    private String number(double value){return value==(int)value?String.valueOf((int)value):String.format(Locale.ROOT,"%.1f",value);}
```

整数 double 显示无小数，否则显示一位；Locale.ROOT 避免某些地区用逗号作小数点。

## 第 61 行

```java
    private void edit(int id,String s){((EditText)root.findViewById(id)).setText(s);}
```

按 id 找输入框并设置文本。

## 第 62 行

```java
    private void check(int id,boolean value){((CheckBox)root.findViewById(id)).setChecked(value);}
```

按 id 找复选框并设置勾选。

## 第 63 行

```java
    private String value(int id){return ((EditText)root.findViewById(id)).getText().toString().trim();}
```

读取输入框文本并去首尾空白。

## 第 64 行

```java
    private boolean checked(int id){return ((CheckBox)root.findViewById(id)).isChecked();}
```

读取复选框当前状态。

## 第 65 行

```java
    private Spinner spinner(int id){return root.findViewById(id);}
```

根据 id 返回 Spinner，利用泛型 findViewById 推断类型。

## 第 66 行

```java
    private int position(int id){return spinner(id).getSelectedItemPosition();}
```

返回下拉选中的零起点位置。

## 第 67 行

```java
    private void options(int id,String[] labels){ArrayAdapter<String> adapter=new ArrayAdapter<>(context,android.R.layout.simple_spinner_dropdown_item,labels);spinner(id).setAdapter(adapter);}
```

用系统下拉样式创建 ArrayAdapter 并设置到 Spinner；适配器把数组转换为选项视图。

## 第 68 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
