# app/src/main/java/com/pulse/fitness/ui/ProgressScreen.java

从真实完成记录计算累计统计与本周图表，最近 50 条仅限制显示，不限制累计口径。

原文件 SHA-256：`8ce002bfbf704ed6e2191d079d33ead7b64ccac655d5e2783ce890875bd56ae8`。行号仅对应此快照；修改源码后应重新核对。

共 32 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.fitness.R;
```

导入类型命名空间 com.pulse.fitness.R，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.fitness.ui.widget.WeeklyChartView;
```

导入类型命名空间 com.pulse.fitness.ui.widget.WeeklyChartView，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.core.model.TrainingRecord;
```

导入类型命名空间 com.pulse.core.model.TrainingRecord，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.text.SimpleDateFormat;
```

导入类型命名空间 java.text.SimpleDateFormat，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
import java.time.*;
```

导入类型命名空间 java.time.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 13 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 14 行

```java
public final class ProgressScreen implements Screen {
```

定义 public final class ProgressScreen implements Screen。实现 Screen 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 15 行

```java
    private final View root;private final Context context;private final FitnessViewModel vm;
```

保存视图、上下文和 VM。

## 第 16 行

```java
    public ProgressScreen(Context c,FitnessViewModel vm){context=c;this.vm=vm;root=Ui.screen(c,R.layout.screen_progress);}
```

构造并加载进度页布局。

## 第 17 行

```java
    public View view(){return root;}
```

返回视图。

## 第 18 行

```java
    public void bind(FitnessViewModel.UiState s){
```

重新绑定状态时计算统计，参数 s 本身未用。

## 第 19 行

```java
        List<TrainingRecord> records=vm.history();int seconds=0,sets=0;float[] week=new float[7];
```

读取记录，累计秒数和组数从 0 开始；七元素数组存周一至周日分钟数。

## 第 20 行

```java
        for(TrainingRecord r:records){seconds+=r.activeSeconds;sets+=r.completedSets;
```

遍历全部记录，累计时长和完成组数。

## 第 21 行

```java
            if(r.completedAt>=Ui.weekStart()){int day=Instant.ofEpochMilli(r.completedAt).atZone(ZoneId.systemDefault()).getDayOfWeek().getValue()-1;week[day]+=r.activeSeconds/60f;}}
```

本周起点以后记录才进入周图；按本地时区换算完成星期，除 60f 保留小数分钟。

## 第 22 行

```java
        Ui.text(root,R.id.progress_total,records.size()+" 次训练");Ui.text(root,R.id.progress_meta,(seconds/60)+" 分钟投入  /  "+sets+" 组动作完成");
```

显示累计次数、整分钟及组数。

## 第 23 行

```java
        ((WeeklyChartView)root.findViewById(R.id.progress_chart)).setMinutes(week);
```

向自定义 WeeklyChartView 传七天数据，触发其重绘。

## 第 24 行

```java
        LinearLayout history=root.findViewById(R.id.progress_history);history.removeAllViews();
```

清空历史视图容器。

## 第 25 行

```java
        if(records.isEmpty())history.addView(Ui.paragraph(context,"还没有训练记录。\n完成计划中的一场训练后，你的足迹会出现在这里。"));
```

空列表显示完成第一场训练的引导。

## 第 26 行

```java
        int shown=0;for(TrainingRecord r:records){if(shown++>=50)break;
```

最多渲染前 50 条，shown++ 先比较旧值再递增。

## 第 27 行

```java
            TextView card=Ui.paragraph(context,r.title+"\n"+new SimpleDateFormat("MM 月 dd 日  HH:mm",Locale.CHINA).format(new Date(r.completedAt))+"  ·  "+Ui.clock(r.activeSeconds)+"  ·  "+r.completedSets+" 组");
```

用本地时间格式化完成时刻，并显示本场时长及组数。

## 第 28 行

```java
            card.setBackgroundResource(R.drawable.bg_card);int padding=Ui.dp(context,18);card.setPadding(padding,padding,padding,padding);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=Ui.dp(context,12);history.addView(card,lp);
```

设置卡片背景、18dp 内边距及 12dp 下间距，再添加。

## 第 29 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 30 行

```java
        if(records.size()>50)history.addView(Ui.paragraph(context,"展示最近 50 次训练，累计统计包含全部记录。"));
```

超过 50 条时说明“展示有限、累计包含全部”。

## 第 31 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 32 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
