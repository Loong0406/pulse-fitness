# app/src/main/java/com/pulse/fitness/ui/Screen.java

主界面视图组件公共接口，简化宿主 Activity 的统一处理。

原文件 SHA-256：`5ed3ebfc3652e3cbbd51bc9e1bff4499c58875359e44cf78c0708c10f0338c70`。行号仅对应此快照；修改源码后应重新核对。

共 4 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import android.view.View;
```

导入类型命名空间 android.view.View，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import com.pulse.fitness.presentation.FitnessViewModel;
```

导入类型命名空间 com.pulse.fitness.presentation.FitnessViewModel，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
public interface Screen {View view();void bind(FitnessViewModel.UiState state);}
```

view 返回可挂载的 Android View；bind 接收状态并更新控件。这不是 Activity 生命周期接口。
