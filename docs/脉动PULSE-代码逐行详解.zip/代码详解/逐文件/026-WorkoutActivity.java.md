# app/src/main/java/com/pulse/fitness/ui/WorkoutActivity.java

Android 负责计时、渲染、生命周期保存；WorkoutSession 负责状态逻辑。计时动作目标是文字提示，完成组仍由用户手动确认。

原文件 SHA-256：`5619b06155643c365bf479f4e1a7a72c1fb35401b3454a2f7d881dde88d73320`。行号仅对应此快照；修改源码后应重新核对。

共 68 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui;
```

声明本文件所属包 com.pulse.fitness.ui；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.app.*;
```

导入类型命名空间 android.app.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.os.*;
```

导入类型命名空间 android.os.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.view.*;
```

导入类型命名空间 android.view.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.widget.*;
```

导入类型命名空间 android.widget.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.fitness.*;
```

导入类型命名空间 com.pulse.fitness.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.core.session.WorkoutSession;
```

导入类型命名空间 com.pulse.core.session.WorkoutSession，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 12 行

```java
/** Session clock and rendering are Android concerns; transitions live in the pure-Java State object. */
```

源码注释，不参与执行。Android 负责计时、渲染、生命周期保存；WorkoutSession 负责状态逻辑。计时动作目标是文字提示，完成组仍由用户手动确认。

## 第 13 行

```java
public final class WorkoutActivity extends Activity {
```

定义 public final class WorkoutActivity extends Activity。继承 Activity 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 14 行

```java
    private final Handler handler=new Handler(Looper.getMainLooper());
```

主线程计时 Handler。

## 第 15 行

```java
    private WorkoutSession session;
```

当前训练领域会话。

## 第 16 行

```java
    private String dayKey;
```

计划 ID 与日索引组成的唯一日键。

## 第 17 行

```java
    private long lastTick;
```

上次已计入的单调时刻毫秒。

## 第 18 行

```java
    private boolean completionShown;
```

本 Activity 是否已显示过完成弹窗。

## 第 19 行

```java
    private final Runnable ticker=new Runnable(){public void run(){
```

周期 Runnable 开始，this 指向计时任务自身。

## 第 20 行

```java
        if(session==null)return;long now=SystemClock.elapsedRealtime();int seconds=(int)((now-lastTick)/1000);
```

无会话就停止；用 elapsedRealtime 计算距上次累计过去的完整秒，不简单假设每回调等于一秒。

## 第 21 行

```java
        if(seconds>0){session.tick(seconds);lastTick+=seconds*1000L;render();if(session.seconds()%5==0)persist();}
```

有整秒才推进状态、推进 lastTick，重绘；总秒数整除 5 时保存一次。由于回调会跳秒，这不是严格每五秒必存，离开页面另有保存。

## 第 22 行

```java
        handler.postDelayed(this,250);
```

每 250 毫秒调度一次自己，减少可见秒钟滞后。

## 第 23 行

```java
    }};
```

结束 Runnable 对象定义。

## 第 24 行

```java
    @Override protected void onCreate(Bundle saved){
```

创建页面入口。

## 第 25 行

```java
        super.onCreate(saved);setContentView(R.layout.activity_workout);Ui.insets(this,findViewById(R.id.workout_root),Ui.dp(this,24));
```

加载训练 XML，根布局避让系统并额外加 24dp 内边距。

## 第 26 行

```java
        dayKey=getIntent().getStringExtra("dayKey");AppContainer c=AppContainer.get();WeekPlan plan=c.viewModel.state.get().plan;
```

读取传入 dayKey，取得当前计划。

## 第 27 行

```java
        try{
```

开始检查输入和恢复快照。

## 第 28 行

```java
            if(plan==null||dayKey==null||!dayKey.startsWith(plan.id+":"))throw new IllegalArgumentException();
```

没计划、没键或键不属于当前计划就拒绝，防止旧页面继续训练已失效计划。

## 第 29 行

```java
            int index=Integer.parseInt(dayKey.substring(dayKey.lastIndexOf(':')+1));DayPlan day=plan.days.get(index);
```

从最后一个冒号之后解析日索引，再从当前七天列表取日程。

## 第 30 行

```java
            String snapshot=saved!=null?saved.getString("snapshot"):dayKey.equals(c.data.getString("session_day",""))?c.data.getString("session",null):null;
```

优先用系统重建快照；否则仅在持久化 session_day 匹配时读取本机快照。

## 第 31 行

```java
            if(snapshot==null)session=new WorkoutSession(day);
```

没快照创建全新热身会话。

## 第 32 行

```java
            else{try{session=new WorkoutSession(day,JsonCodec.GSON.fromJson(snapshot,WorkoutSession.Snapshot.class));}catch(RuntimeException corrupt){session=new WorkoutSession(day);Ui.toast(this,"旧进度无法恢复，已重新开始本次训练");}}
```

有快照用 Gson 恢复 Snapshot，再交领域构造器检查；损坏则提示并新开本日训练。

## 第 33 行

```java
        }catch(RuntimeException invalid){Ui.toast(this,"训练计划已更新，请重新选择训练日");finish();return;}
```

dayKey 等外部输入无效则提示重新选择并关闭，不继续访问空会话。

## 第 34 行

```java
        findViewById(R.id.workout_close).setOnClickListener(v->finish());
```

关闭按钮 finish，onStop 会自动暂停存进度。

## 第 35 行

```java
        findViewById(R.id.workout_primary).setOnClickListener(v->{session.primary();persist();render();if(session.complete())complete();});
```

主按钮让状态机执行主动作，再保存和渲染；若完成则走历史保存。

## 第 36 行

```java
        findViewById(R.id.workout_pause).setOnClickListener(v->{if(session.phase().equals("PAUSED"))finish();else{session.pause();persist();render();}});
```

暂停按钮：已暂停时返回主界面，否则暂停、保存、刷新。

## 第 37 行

```java
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::finish);
```

API 33 起注册系统返回手势回调直接 finish；生命周期统一处理保存。

## 第 38 行

```java
        render();if(session.complete())complete();
```

首次渲染；恢复到完成状态时也显示完成结果。

## 第 39 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 40 行

```java
    @Override protected void onStart(){super.onStart();lastTick=SystemClock.elapsedRealtime();handler.post(ticker);}
```

页面可见时重新设计时基准并启动任务，不把离开期间算成活跃训练。

## 第 41 行

```java
    @Override protected void onStop(){handler.removeCallbacks(ticker);if(session!=null&&!session.complete()){session.pause();persist();}super.onStop();}
```

不可见时移除任务，未完成的会话自动暂停并保存；再调父类。

## 第 42 行

```java
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(session!=null)out.putString("snapshot",JsonCodec.GSON.toJson(session.snapshot()));}
```

把领域快照 JSON 放 Bundle，帮助旋转和系统重建恢复。

## 第 43 行

```java
    private void persist(){if(session==null||session.complete())return;AppContainer.get().data.edit().putString("session_day",dayKey).putString("session",JsonCodec.GSON.toJson(session.snapshot())).apply();}
```

未完成才把 dayKey 与快照 JSON 一次写入存储；完成记录保存时由历史仓库清快照。

## 第 44 行

```java
    private void render(){
```

渲染页面入口。

## 第 45 行

```java
        if(session==null)return;Prescription rx=session.current();String phase=session.phase();
```

无会话则返回；否则取当前处方和状态名。

## 第 46 行

```java
        Ui.text(findViewById(R.id.workout_root),R.id.workout_heading,session.day().title);Ui.text(findViewById(R.id.workout_root),R.id.workout_elapsed,Ui.clock(session.seconds()));
```

显示日标题及累计训练时长。

## 第 47 行

```java
        String title,target,cue,label;
```

声明本次渲染的标题、目标、要领、阶段标签。

## 第 48 行

```java
        switch(phase){
```

按状态选择要显示的内容。

## 第 49 行

```java
            case "WARMUP":title="先唤醒身体。";target=Ui.clock(session.remaining());cue="建议用约 4 分钟轻松踏步、活动肩踝，在舒适范围内逐渐进入状态。准备好后手动开始训练。";label="01 / WARM UP";break;
```

热身显示倒计时和四分钟建议，手动确认后进入训练。

## 第 50 行

```java
            case "REST":title="休息，也有意义。";target=Ui.clock(session.remaining());cue="调整呼吸。接下来："+session.exercise().name+"。\n"+session.exercise().cue;label="RECOVER / NEXT SET";break;
```

休息显示剩余秒与接下来动作的名称及要领。

## 第 51 行

```java
            case "COOLDOWN":title="把节奏，慢下来。";target=Ui.clock(session.remaining());cue="建议用约 4 分钟缓慢走动、自然呼吸，并在舒适范围内轻柔放松。完成后保存训练记录。";label="03 / COOL DOWN";break;
```

放松显示四分钟建议和剩余秒，确认才保存记录。

## 第 52 行

```java
            case "PAUSED":title="休息一下，随时回来。";target="已暂停";cue="进度已保存在本机。点击“继续训练”会从暂停的位置恢复。";label="YOUR PACE / PAUSED";break;
```

暂停显示已暂停及本机恢复说明。

## 第 53 行

```java
            case "COMPLETE":title="这一次，为自己。";target="完成 ✓";cue="你又为自己积累了一点进步。";label="SESSION COMPLETE";break;
```

完成显示成功文字。

## 第 54 行

```java
            default:title=session.exercise().name;target=rx.amount+(session.exercise().timed?" 秒":" 次");cue=session.exercise().cue+"\n\n"+String.join("\n",session.exercise().steps);label="02 / MOVE WITH INTENTION";
```

默认为正式训练：目标是处方次数/秒数，正文来自目录的要领和步骤；没有摄像头或动作计数功能。

## 第 55 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 56 行

```java
        View root=findViewById(R.id.workout_root);Ui.text(root,R.id.workout_phase,label);Ui.text(root,R.id.workout_name,title);Ui.text(root,R.id.workout_target,target);Ui.text(root,R.id.workout_cue,cue);
```

将上面选择的四项内容统一写入对应控件。

## 第 57 行

```java
        Ui.text(root,R.id.workout_set,phase.equals("RUNNING")?"动作 "+(session.exerciseIndex()+1)+" / "+session.day().exercises.size()+"  ·  第 "+(session.setIndex()+1)+" / "+rx.sets+" 组":"按自己的节奏，完成每一步");
```

Running 显示“第几动作、第几组”，给索引加一转为人类序号；其他状态显示节奏提示。

## 第 58 行

```java
        Ui.text(root,R.id.workout_primary,session.action());Ui.text(root,R.id.workout_pause,phase.equals("PAUSED")?"返回并保留进度":"暂停训练");
```

主按钮文字来自状态对象；暂停状态的次按钮变成返回并保留进度。

## 第 59 行

```java
        findViewById(R.id.workout_primary).setEnabled(!session.complete());findViewById(R.id.workout_pause).setEnabled(!session.complete());
```

完成状态禁用两按钮，防止重复推进。

## 第 60 行

```java
        int total=0;for(Prescription p:session.day().exercises)total+=p.sets;ProgressBar progress=findViewById(R.id.workout_progress);progress.setMax(total);progress.setProgress(session.snapshot().completedSets);
```

累加今日总组数，进度条最大值为总组数，当前值为快照完成组数。

## 第 61 行

```java
        if(phase.equals("PAUSED")||session.complete())getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
```

活跃训练时保持屏幕亮，暂停或完成清此标志；仅影响当前窗口。

## 第 62 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 63 行

```java
    private void complete(){
```

记录完成并显示结果入口。

## 第 64 行

```java
        if(completionShown)return;completionShown=true;handler.removeCallbacks(ticker);
```

Activity 内防止重复弹窗，同时停止计时回调。

## 第 65 行

```java
        AppContainer c=AppContainer.get();c.repositories.history().add(session.record(System.currentTimeMillis()));c.viewModel.refresh();
```

用当前日历时刻生成记录，历史仓库再按会话 ID 去重，刷新主界面共享状态。

## 第 66 行

```java
        new AlertDialog.Builder(this).setTitle("训练完成，做得很好。").setMessage("本次投入 "+Ui.clock(session.seconds())+"，完成 "+session.snapshot().completedSets+" 组动作。\n记录已保存在本机。").setCancelable(false).setPositiveButton("完成",(d,w)->finish()).show();
```

显示时长和组数，弹窗不可取消，点完成关闭；记录只在本机。

## 第 67 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 68 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
