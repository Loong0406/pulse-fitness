# app/src/main/java/com/pulse/fitness/ui/widget/ExerciseArtView.java

装饰性人物绘制，不能用来检测或指导真实关节角度；要领来自动作文字。

原文件 SHA-256：`fde1792eba3277bbaeca8b28416c9753b38dc5edf568ad8e598ffbf06c948f06`。行号仅对应此快照；修改源码后应重新核对。

共 20 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui.widget;
```

声明本文件所属包 com.pulse.fitness.ui.widget；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.graphics.*;
```

导入类型命名空间 android.graphics.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.util.AttributeSet;
```

导入类型命名空间 android.util.AttributeSet，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.view.View;
```

导入类型命名空间 android.view.View，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
/** Decorative vector illustration. Written technique, not this drawing, guides the movement. */
```

源码注释，不参与执行。装饰性人物绘制，不能用来检测或指导真实关节角度；要领来自动作文字。

## 第 9 行

```java
public final class ExerciseArtView extends View {
```

定义 public final class ExerciseArtView extends View。继承 View 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
```

创建抗锯齿画笔，减少斜线边缘锯齿。

## 第 11 行

```java
    public ExerciseArtView(Context c,AttributeSet a){super(c,a);}
```

XML inflate 自定义 View 时使用 Context+AttributeSet 构造器。

## 第 12 行

```java
    @Override protected void onDraw(Canvas canvas){
```

重绘时 Android 调用 onDraw。

## 第 13 行

```java
        super.onDraw(canvas);canvas.save();float scale=Math.min(getWidth()/320f,getHeight()/200f);canvas.translate(getWidth()/2f-160*scale,getHeight()/2f-100*scale);canvas.scale(scale,scale);
```

先画父类并保存画布状态；以 320×200 为设计空间按较小比例缩放，移动到视图中心，保持比例。

## 第 14 行

```java
        p.setColor(Color.rgb(195,227,121));canvas.drawCircle(160,100,78,p);p.setColor(Color.rgb(170,199,104));p.setStrokeWidth(1);canvas.drawLine(55,174,265,174,p);
```

用绿色画圆背景和水平基准线；坐标是设计空间，不是实际设备像素。

## 第 15 行

```java
        p.setColor(Color.rgb(41,67,44));canvas.drawCircle(168,39,14,p);p.setStrokeWidth(19);p.setStrokeCap(Paint.Cap.ROUND);
```

深色画头部圆，设置身体较粗圆头线条。

## 第 16 行

```java
        canvas.drawLine(160,67,145,111,p);p.setStrokeWidth(13);canvas.drawLine(157,71,119,91,p);canvas.drawLine(119,91,93,71,p);canvas.drawLine(163,73,199,91,p);canvas.drawLine(199,91,226,71,p);
```

依次用线段画躯干和两条屈肘手臂；drawLine 四个数是起点 x/y 和终点 x/y。

## 第 17 行

```java
        p.setColor(Color.rgb(87,115,63));p.setStrokeWidth(19);canvas.drawLine(145,111,114,139,p);canvas.drawLine(114,139,98,170,p);canvas.drawLine(151,113,188,132,p);canvas.drawLine(188,132,210,170,p);
```

换色、加粗，画左右大腿和小腿。

## 第 18 行

```java
        p.setColor(Color.rgb(34,53,37));p.setStrokeWidth(8);canvas.drawLine(80,69,105,69,p);canvas.drawLine(80,59,80,79,p);canvas.drawLine(105,59,105,79,p);canvas.drawLine(214,69,239,69,p);canvas.drawLine(214,59,214,79,p);canvas.drawLine(239,59,239,79,p);canvas.restore();
```

深色细线画左右手持器械示意，最后 restore 恢复画布变换，不影响其他控件。

## 第 19 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
