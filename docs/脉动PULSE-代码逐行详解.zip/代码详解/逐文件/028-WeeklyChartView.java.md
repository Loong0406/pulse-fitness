# app/src/main/java/com/pulse/fitness/ui/widget/WeeklyChartView.java

原生 Canvas 周训练柱状图，数据来自进度页真实历史，零数据不会伪造柱高。

原文件 SHA-256：`6f048130598c0e793cd5f91c68aff66d853a646250c7064d5bc31a8289a802a6`。行号仅对应此快照；修改源码后应重新核对。

共 26 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.fitness.ui.widget;
```

声明本文件所属包 com.pulse.fitness.ui.widget；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import android.content.Context;
```

导入类型命名空间 android.content.Context，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import android.graphics.*;
```

导入类型命名空间 android.graphics.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import android.util.AttributeSet;
```

导入类型命名空间 android.util.AttributeSet，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import android.view.View;
```

导入类型命名空间 android.view.View，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.util.Locale;
```

导入类型命名空间 java.util.Locale，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 9 行

```java
/** Native chart uses actual records only; zero values remain zero. */
```

源码注释，不参与执行。原生 Canvas 周训练柱状图，数据来自进度页真实历史，零数据不会伪造柱高。

## 第 10 行

```java
public final class WeeklyChartView extends View {
```

定义 public final class WeeklyChartView extends View。继承 View 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 11 行

```java
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
```

共用抗锯齿 Paint，避免每帧分配新画笔。

## 第 12 行

```java
    private float[] values=new float[7];
```

七天数据初始全 0。

## 第 13 行

```java
    public WeeklyChartView(Context c,AttributeSet a){super(c,a);}
```

XML 创建自定义控件所需构造器。

## 第 14 行

```java
    public void setMinutes(float[] minutes){values=minutes.clone();StringBuilder b=new StringBuilder("本周训练分钟数：");for(int i=0;i<7;i++)b.append("周").append("一二三四五六日".charAt(i)).append(String.format(Locale.CHINA," %.1f 分钟，",values[i]));setContentDescription(b.toString());invalidate();}
```

复制传入数组，构建七天读屏描述，再 invalidate 请求下一帧重绘；调用方应提供恰好七项。

## 第 15 行

```java
    @Override protected void onDraw(Canvas c){
```

Android 重绘回调。

## 第 16 行

```java
        super.onDraw(c);float density=getResources().getDisplayMetrics().density,padding=22*density,width=getWidth()-padding*2,height=getHeight()-62*density;
```

先调用父类，取得密度、左右 22dp 留白、可用宽高；Canvas 的数值坐标最终按 px 计算。

## 第 17 行

```java
        float max=15;for(float v:values)max=Math.max(max,v);paint.setTextSize(11*density);paint.setTextAlign(Paint.Align.CENTER);
```

Y 轴比例分母至少 15 分钟，数据更大时扩展；设置文字尺寸与水平居中对齐。

## 第 18 行

```java
        for(int i=0;i<7;i++){
```

遍历七天。

## 第 19 行

```java
            float x=padding+width*(i+0.5f)/7,bar=width/7*0.42f,bottom=height+20*density;
```

每天均分宽度算 x 中点，柱宽占每天槽宽 42%，算共同基线 bottom。

## 第 20 行

```java
            paint.setColor(Color.rgb(234,238,227));c.drawRoundRect(x-bar/2,22*density,x+bar/2,bottom,6*density,6*density,paint);
```

先画淡色圆角轨道柱，表示图表可用范围。

## 第 21 行

```java
            if(values[i]>0){float h=height*Math.min(1,values[i]/max);paint.setColor(Color.rgb(177,211,105));c.drawRoundRect(x-bar/2,bottom-h,x+bar/2,bottom,6*density,6*density,paint);}
```

数据大于零才画实际绿色柱；高度=可用高×该日/最大值，限定比例最多 1。

## 第 22 行

```java
            paint.setColor(Color.rgb(94,111,93));c.drawText(String.valueOf("一二三四五六日".charAt(i)),x,getHeight()-14*density,paint);
```

在底部绘制星期文字。

## 第 23 行

```java
            if(values[i]>0)c.drawText(String.valueOf(Math.round(values[i])),x,Math.max(15*density,bottom-height*values[i]/max-5*density),paint);
```

正值才画四舍五入分钟数，y 用 Math.max 避免文字跑出顶部。

## 第 24 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 25 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
