# app/src/main/res/color/auth_code_text.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`dba5e96eebb5a784a5b97129bba88af24d53f9c3f2402f955a89566c80723e34`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<selector xmlns:android="http://schemas.android.com/apk/res/android"><item android:state_enabled="false" android:color="@color/auth_secondary"/><item android:color="@color/auth_action"/></selector>
```

元素 selector：按状态顺序匹配资源，先匹配的分支优先。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
元素 item：样式属性或状态列表分支。
android:state_enabled="false"：状态列表条件：true 启用，false 禁用。
android:color="@color/auth_secondary"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
元素 item：样式属性或状态列表分支。
android:color="@color/auth_action"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 selector 元素，结束它的嵌套作用域。
