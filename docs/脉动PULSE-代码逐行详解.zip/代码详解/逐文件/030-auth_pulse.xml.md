# app/src/main/res/drawable/auth_pulse.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`b50f3a1b18814e68e69cae7999c4c2c10309a1d51ad9119f3b393eaf143ed960`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="180dp" android:height="120dp" android:viewportWidth="180" android:viewportHeight="120"><path android:fillColor="@android:color/transparent" android:strokeColor="@color/auth_primary" android:strokeWidth="10" android:strokeLineJoin="round" android:strokeLineCap="round" android:pathData="M-5,65L38,65L60,16L88,110L116,42L145,65L185,65"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="180dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 180dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="120dp"：drawable 自身逻辑高度。尺寸 120dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="180"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="120"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeColor="@color/auth_primary"：路径描边颜色。引用资源 @color/auth_primary，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeWidth="10"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineJoin="round"：路径拐角连接形状，round 为圆角。
android:strokeLineCap="round"：描边端点形状，round 为圆头。
android:pathData=M-5,65L38,65L60,16L88,110L116,42L145,65L185,65。路径按以下顺序执行：M：移动起点（绝对坐标） [-5,65]；L：直线到（绝对坐标） [38,65]；L：直线到（绝对坐标） [60,16]；L：直线到（绝对坐标） [88,110]；L：直线到（绝对坐标） [116,42]；L：直线到（绝对坐标） [145,65]；L：直线到（绝对坐标） [185,65]。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
