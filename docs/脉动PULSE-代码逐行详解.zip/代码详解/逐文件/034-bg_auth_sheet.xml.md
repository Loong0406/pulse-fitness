# app/src/main/res/drawable/bg_auth_sheet.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`8a3f4900dc30c9e34c7e7f1e5e42261e750afe2f385d21c1bc896ec92e98b7e6`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<shape xmlns:android="http://schemas.android.com/apk/res/android"><solid android:color="@color/auth_surface"/><corners android:topLeftRadius="28dp" android:topRightRadius="28dp"/></shape>
```

元素 shape：形状 drawable。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
元素 solid：形状填充。
android:color="@color/auth_surface"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
元素 corners：形状圆角。
android:topLeftRadius="28dp"：仅左上圆角半径。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:topRightRadius="28dp"：仅右上圆角半径。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 shape 元素，结束它的嵌套作用域。
