# app/src/main/res/drawable/bg_button.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`45727e0368a12ef23a547e365eaf2499983c3584846ea59d564002fc8753642d`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<ripple xmlns:android="http://schemas.android.com/apk/res/android" android:color="#3048734D"><item><shape><solid android:color="@color/lime"/><corners android:radius="16dp"/></shape></item></ripple>
```

元素 ripple：系统点击波纹背景。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:color="#3048734D"：纯色、描边或 ripple 的颜色，依标签含义使用。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
元素 item：样式属性或状态列表分支。
元素 shape：形状 drawable。
元素 solid：形状填充。
android:color="@color/lime"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/lime，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
元素 corners：形状圆角。
android:radius="16dp"：圆角半径。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 shape 元素，结束它的嵌套作用域。
关闭 item 元素，结束它的嵌套作用域。
关闭 ripple 元素，结束它的嵌套作用域。
