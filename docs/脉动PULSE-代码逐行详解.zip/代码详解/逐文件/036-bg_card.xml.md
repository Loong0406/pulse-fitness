# app/src/main/res/drawable/bg_card.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`4dcd046ad06d4f6d4a2d5c87585c0f8b194a54e7d81303c5c0c4ca064c34424c`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<shape xmlns:android="http://schemas.android.com/apk/res/android"><solid android:color="@color/white"/><corners android:radius="24dp"/><stroke android:width="1dp" android:color="@color/line"/></shape>
```

元素 shape：形状 drawable。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
元素 solid：形状填充。
android:color="@color/white"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/white，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
元素 corners：形状圆角。
android:radius="24dp"：圆角半径。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。
元素 stroke：形状边框。
android:width="1dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 1dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:color="@color/line"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/line，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 shape 元素，结束它的嵌套作用域。
