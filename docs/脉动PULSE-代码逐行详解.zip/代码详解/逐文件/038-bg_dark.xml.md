# app/src/main/res/drawable/bg_dark.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`1352a0d11d4a745bb822b0a041d5810612d016f7a8979ba56c3a68ad7ee4a330`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<shape xmlns:android="http://schemas.android.com/apk/res/android"><gradient android:startColor="#213B2A" android:endColor="#122319" android:angle="315"/><corners android:radius="28dp"/></shape>
```

元素 shape：形状 drawable。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
元素 gradient：渐变填充。
android:startColor="#213B2A"：渐变起始颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:endColor="#122319"：渐变终止颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:angle="315"：渐变方向角度。
该元素以 /> 自闭合，没有嵌套子节点。
元素 corners：形状圆角。
android:radius="28dp"：圆角半径。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 shape 元素，结束它的嵌套作用域。
