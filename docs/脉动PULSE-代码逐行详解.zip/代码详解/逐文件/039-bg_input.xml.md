# app/src/main/res/drawable/bg_input.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`d156facaeeddb56dd984fedaabad76bd6bbf70d0cca2d501d0bdd1963d0945aa`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<shape xmlns:android="http://schemas.android.com/apk/res/android"><solid android:color="#F9FAF6"/><corners android:radius="14dp"/><stroke android:width="1dp" android:color="@color/line"/></shape>
```

元素 shape：形状 drawable。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
元素 solid：形状填充。
android:color="#F9FAF6"：纯色、描边或 ripple 的颜色，依标签含义使用。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
该元素以 /> 自闭合，没有嵌套子节点。
元素 corners：形状圆角。
android:radius="14dp"：圆角半径。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。
元素 stroke：形状边框。
android:width="1dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 1dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:color="@color/line"：纯色、描边或 ripple 的颜色，依标签含义使用。引用资源 @color/line，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 shape 元素，结束它的嵌套作用域。
