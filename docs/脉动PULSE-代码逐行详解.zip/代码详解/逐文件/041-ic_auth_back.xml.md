# app/src/main/res/drawable/ic_auth_back.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`1fe878cd1c6a82a998925c38bf17be83fc717875b8510eed4af0edcdb6d8c383`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="@android:color/transparent" android:strokeColor="@color/auth_on_surface" android:strokeWidth="1.8" android:strokeLineCap="round" android:strokeLineJoin="round" android:pathData="M15,5L8,12L15,19"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="24dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="24dp"：drawable 自身逻辑高度。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="24"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="24"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeColor="@color/auth_on_surface"：路径描边颜色。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeWidth="1.8"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineCap="round"：描边端点形状，round 为圆头。
android:strokeLineJoin="round"：路径拐角连接形状，round 为圆角。
android:pathData=M15,5L8,12L15,19。路径按以下顺序执行：M：移动起点（绝对坐标） [15,5]；L：直线到（绝对坐标） [8,12]；L：直线到（绝对坐标） [15,19]。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
