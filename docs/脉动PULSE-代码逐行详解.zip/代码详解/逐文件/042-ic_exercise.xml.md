# app/src/main/res/drawable/ic_exercise.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`edbb203c63b2553fbb468812e798a2daeff3952e7736b647b620405478484179`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="23dp" android:height="23dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="@android:color/transparent" android:strokeColor="#748076" android:strokeWidth="1.8" android:strokeLineCap="round" android:pathData="M3,8L3,16 M6,5L6,19 M6,12L18,12 M18,5L18,19 M21,8L21,16"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="23dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="23dp"：drawable 自身逻辑高度。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="24"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="24"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeColor="#748076"：路径描边颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:strokeWidth="1.8"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineCap="round"：描边端点形状，round 为圆头。
android:pathData=M3,8L3,16 M6,5L6,19 M6,12L18,12 M18,5L18,19 M21,8L21,16。路径按以下顺序执行：M：移动起点（绝对坐标） [3,8]；L：直线到（绝对坐标） [3,16]；M：移动起点（绝对坐标） [6,5]；L：直线到（绝对坐标） [6,19]；M：移动起点（绝对坐标） [6,12]；L：直线到（绝对坐标） [18,12]；M：移动起点（绝对坐标） [18,5]；L：直线到（绝对坐标） [18,19]；M：移动起点（绝对坐标） [21,8]；L：直线到（绝对坐标） [21,16]。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
