# app/src/main/res/drawable/ic_home.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`166d64b0b6e579a437c6ae4a94f272f0fa885ea7a4213cc7d956960cc2241a4b`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="23dp" android:height="23dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="@android:color/transparent" android:strokeColor="#748076" android:strokeWidth="1.7" android:strokeLineJoin="round" android:pathData="M3,10L12,3L21,10L21,21L15,21L15,14L9,14L9,21L3,21Z"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="23dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="23dp"：drawable 自身逻辑高度。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="24"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="24"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeColor="#748076"：路径描边颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:strokeWidth="1.7"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineJoin="round"：路径拐角连接形状，round 为圆角。
android:pathData=M3,10L12,3L21,10L21,21L15,21L15,14L9,14L9,21L3,21Z。路径按以下顺序执行：M：移动起点（绝对坐标） [3,10]；L：直线到（绝对坐标） [12,3]；L：直线到（绝对坐标） [21,10]；L：直线到（绝对坐标） [21,21]；L：直线到（绝对坐标） [15,21]；L：直线到（绝对坐标） [15,14]；L：直线到（绝对坐标） [9,14]；L：直线到（绝对坐标） [9,21]；L：直线到（绝对坐标） [3,21]；Z：闭合到本子路径起点（绝对坐标）。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
