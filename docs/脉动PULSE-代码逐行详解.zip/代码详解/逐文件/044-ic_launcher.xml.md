# app/src/main/res/drawable/ic_launcher.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`09afaba3abcc3da7ad9d620447dab43fe80a4481f8c0602cc135919f22dd5dd3`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108"><path android:fillColor="#19271F" android:pathData="M0,0h108v108h-108z"/><path android:strokeColor="#D8F875" android:strokeWidth="7" android:strokeLineCap="round" android:strokeLineJoin="round" android:fillColor="@android:color/transparent" android:pathData="M21,57L35,57L45,34L59,76L70,49L87,49"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="108dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 108dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="108dp"：drawable 自身逻辑高度。尺寸 108dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="108"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="108"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="#19271F"：路径填充色，transparent 表示不填充。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:pathData=M0,0h108v108h-108z。路径按以下顺序执行：M：移动起点（绝对坐标） [0,0]；h：水平线到（相对当前位置） [108]；v：垂直线到（相对当前位置） [108]；h：水平线到（相对当前位置） [-108]；z：闭合到本子路径起点（相对当前位置）。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
元素 path：矢量绘制路径。
android:strokeColor="#D8F875"：路径描边颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:strokeWidth="7"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineCap="round"：描边端点形状，round 为圆头。
android:strokeLineJoin="round"：路径拐角连接形状，round 为圆角。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:pathData=M21,57L35,57L45,34L59,76L70,49L87,49。路径按以下顺序执行：M：移动起点（绝对坐标） [21,57]；L：直线到（绝对坐标） [35,57]；L：直线到（绝对坐标） [45,34]；L：直线到（绝对坐标） [59,76]；L：直线到（绝对坐标） [70,49]；L：直线到（绝对坐标） [87,49]。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
