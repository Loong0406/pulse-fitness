# app/src/main/res/drawable/ic_person.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`eac4484bfbcfe376038c99cc4dbbbf27dee86ec91c279649d428f8d8a24bddd3`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="23dp" android:height="23dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="@android:color/transparent" android:strokeColor="#748076" android:strokeWidth="1.7" android:strokeLineCap="round" android:pathData="M16,7A4,4 0,1 1,8 7A4,4 0,1 1,16 7 M4,21C4,12 20,12 20,21"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="23dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="23dp"：drawable 自身逻辑高度。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="24"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="24"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeColor="#748076"：路径描边颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:strokeWidth="1.7"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineCap="round"：描边端点形状，round 为圆头。
android:pathData=M16,7A4,4 0,1 1,8 7A4,4 0,1 1,16 7 M4,21C4,12 20,12 20,21。路径按以下顺序执行：M：移动起点（绝对坐标） [16,7]；A：椭圆弧：x/y半径、旋转角、大弧标志、顺时针标志、终点x/y（绝对坐标） [4,4,0,1,1,8,7]；A：椭圆弧：x/y半径、旋转角、大弧标志、顺时针标志、终点x/y（绝对坐标） [4,4,0,1,1,16,7]；M：移动起点（绝对坐标） [4,21]；C：三次贝塞尔曲线：两控制点、终点（绝对坐标） [4,12,20,12,20,21]。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
