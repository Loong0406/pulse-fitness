# app/src/main/res/drawable/ic_plan.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`1408a0e75e40191cc8e42fbabb4578d0b02833d7317fe768e73f093534368cce`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="23dp" android:height="23dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="@android:color/transparent" android:strokeColor="#748076" android:strokeWidth="1.7" android:strokeLineCap="round" android:pathData="M5,5L19,5L19,21L5,21Z M8,3L8,7 M16,3L16,7 M8,11L16,11 M8,15L14,15"/></vector>
```

元素 vector：Android 矢量图根节点。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:width="23dp"：drawable 自身逻辑宽度或描边宽度，具体语义由 vector/stroke 标签决定。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:height="23dp"：drawable 自身逻辑高度。尺寸 23dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:viewportWidth="24"：矢量内部坐标系宽度，与输出 dp 尺寸独立。
android:viewportHeight="24"：矢量内部坐标系高度。
元素 path：矢量绘制路径。
android:fillColor="@android:color/transparent"：路径填充色，transparent 表示不填充。引用资源 @android:color/transparent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:strokeColor="#748076"：路径描边颜色。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:strokeWidth="1.7"：路径描边粗细，以矢量内部坐标单位计。
android:strokeLineCap="round"：描边端点形状，round 为圆头。
android:pathData=M5,5L19,5L19,21L5,21Z M8,3L8,7 M16,3L16,7 M8,11L16,11 M8,15L14,15。路径按以下顺序执行：M：移动起点（绝对坐标） [5,5]；L：直线到（绝对坐标） [19,5]；L：直线到（绝对坐标） [19,21]；L：直线到（绝对坐标） [5,21]；Z：闭合到本子路径起点（绝对坐标）；M：移动起点（绝对坐标） [8,3]；L：直线到（绝对坐标） [8,7]；M：移动起点（绝对坐标） [16,3]；L：直线到（绝对坐标） [16,7]；M：移动起点（绝对坐标） [8,11]；L：直线到（绝对坐标） [16,11]；M：移动起点（绝对坐标） [8,15]；L：直线到（绝对坐标） [14,15]。M 后若有多对坐标，首对移动、其余按直线处理。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 vector 元素，结束它的嵌套作用域。
