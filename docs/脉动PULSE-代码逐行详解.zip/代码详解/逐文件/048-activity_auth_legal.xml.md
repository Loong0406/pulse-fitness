# app/src/main/res/layout/activity_auth_legal.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`b76b6932fe0cb021f8d60e4a7b61e8dbea7666969c12c7938025780ea61053d4`。行号仅对应此快照；修改源码后应重新核对。

共 9 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/auth_legal_root" android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:background="@color/auth_surface">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:id="@+id/auth_legal_root"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_legal_root。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:background="@color/auth_surface"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="56dp" android:gravity="center_vertical" android:paddingHorizontal="12dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="56dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:paddingHorizontal="12dp"：左右内边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 3 行

```xml
        <ImageButton android:id="@+id/auth_legal_back" android:layout_width="48dp" android:layout_height="48dp" android:src="@drawable/ic_auth_back" android:background="?android:attr/selectableItemBackground" android:contentDescription="@string/auth_back"/>
```

元素 ImageButton：使用图像作为内容的可点击按钮。
android:id="@+id/auth_legal_back"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_legal_back。
android:layout_width="48dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:src="@drawable/ic_auth_back"：ImageView 内容图像资源。引用资源 @drawable/ic_auth_back，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:background="?android:attr/selectableItemBackground"：控件背景，可是颜色、drawable 或主题属性。从当前主题解析属性 ?android:attr/selectableItemBackground。
android:contentDescription="@string/auth_back"：读屏使用的文字描述。引用资源 @string/auth_back，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
        <TextView android:id="@+id/auth_legal_title" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:layout_marginStart="8dp" android:textSize="19sp" android:textColor="@color/auth_on_surface" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_legal_title"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_legal_title。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="8dp"：语言起始边外边距，中文通常是左边。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textSize="19sp"：字号，sp 会随系统字体大小变化。字号 19sp，会响应用户系统字体缩放。
android:textColor="@color/auth_on_surface"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 6 行

```xml
    <ScrollView android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="0dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。

## 第 7 行

```xml
        <TextView android:id="@+id/auth_legal_text" android:layout_width="match_parent" android:layout_height="wrap_content" android:padding="24dp" android:textColor="@color/auth_on_surface" android:textSize="16sp" android:lineSpacingExtra="7dp" android:textIsSelectable="true"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_legal_text"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_legal_text。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textColor="@color/auth_on_surface"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="16sp"：字号，sp 会随系统字体大小变化。字号 16sp，会响应用户系统字体缩放。
android:lineSpacingExtra="7dp"：每行额外行距。尺寸 7dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textIsSelectable="true"：是否允许长按选择文字。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
    </ScrollView>
```

关闭 ScrollView 元素，结束它的嵌套作用域。

## 第 9 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
