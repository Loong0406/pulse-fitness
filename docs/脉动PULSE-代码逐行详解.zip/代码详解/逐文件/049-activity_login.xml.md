# app/src/main/res/layout/activity_login.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`614d48335d4594bd8dc5be2868c54bd5f459b09ff56d629f7565beedde8bc123`。行号仅对应此快照；修改源码后应重新核对。

共 42 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/auth_root" android:layout_width="match_parent" android:layout_height="match_parent" android:background="@color/auth_surface">
```

元素 FrameLayout：层叠容器，子视图可叠放。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:id="@+id/auth_root"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_root。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:background="@color/auth_surface"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。

## 第 2 行

```xml
    <ScrollView android:layout_width="match_parent" android:layout_height="match_parent" android:fillViewport="true" android:clipToPadding="false">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:fillViewport="true"：ScrollView 内容不足一屏时也撑满可视高度。
android:clipToPadding="false"：是否把绘制裁到内边距，false 可让滚动内容延伸到 padding 区。

## 第 3 行

```xml
        <LinearLayout android:id="@+id/auth_content" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_gravity="center_horizontal" android:orientation="vertical" android:background="@color/auth_hero" android:focusableInTouchMode="true">
```

元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/auth_content"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_content。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_gravity="center_horizontal"：当前控件相对父容器的对齐；区别于内部内容的 gravity。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:background="@color/auth_hero"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/auth_hero，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:focusableInTouchMode="true"：触摸模式下也允许获得焦点，可避免默认把焦点给输入框。

## 第 4 行

```xml
            <FrameLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="264dp">
```

元素 FrameLayout：层叠容器，子视图可叠放。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="264dp"：最小高度，防止内容或触控区域过小。尺寸 264dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 5 行

```xml
                <ImageView android:layout_width="180dp" android:layout_height="120dp" android:layout_gravity="end|bottom" android:layout_marginBottom="24dp" android:alpha="0.12" android:src="@drawable/auth_pulse" android:importantForAccessibility="no"/>
```

元素 ImageView：显示图像。
android:layout_width="180dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 180dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="120dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 120dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_gravity="end|bottom"：当前控件相对父容器的对齐；区别于内部内容的 gravity。
android:layout_marginBottom="24dp"：底部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:alpha="0.12"：透明度，0 全透明，1 不透明。
android:src="@drawable/auth_pulse"：ImageView 内容图像资源。引用资源 @drawable/auth_pulse，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:importantForAccessibility="no"：no 表示装饰图不进入无障碍朗读顺序。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
                <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:paddingHorizontal="28dp" android:paddingTop="22dp" android:paddingBottom="32dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:paddingHorizontal="28dp"：左右内边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingTop="22dp"：顶部内边距。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingBottom="32dp"：底部内边距。尺寸 32dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 7 行

```xml
                    <LinearLayout android:layout_width="match_parent" android:layout_height="48dp" android:gravity="center_vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。

## 第 8 行

```xml
                        <ImageView android:layout_width="28dp" android:layout_height="28dp" android:src="@drawable/ic_launcher" android:importantForAccessibility="no"/>
```

元素 ImageView：显示图像。
android:layout_width="28dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="28dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:src="@drawable/ic_launcher"：ImageView 内容图像资源。引用资源 @drawable/ic_launcher，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:importantForAccessibility="no"：no 表示装饰图不进入无障碍朗读顺序。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
                        <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginStart="10dp" android:text="@string/auth_brand" android:textColor="@color/auth_on_hero" android:textSize="17sp" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="10dp"：语言起始边外边距，中文通常是左边。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_brand"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_brand，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_on_hero"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_hero，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="17sp"：字号，sp 会随系统字体大小变化。字号 17sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
                    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 11 行

```xml
                    <TextView android:id="@+id/auth_headline" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="22dp" android:text="@string/auth_headline" android:textSize="36sp" android:fontFamily="sans-serif-medium" android:textColor="@color/auth_on_hero" android:lineSpacingExtra="2dp"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_headline"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_headline。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="22dp"：顶部外边距。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_headline"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_headline，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="36sp"：字号，sp 会随系统字体大小变化。字号 36sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
android:textColor="@color/auth_on_hero"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_hero，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:lineSpacingExtra="2dp"：每行额外行距。尺寸 2dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 12 行

```xml
                    <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:text="@string/auth_tagline" android:textColor="@color/auth_hero_secondary" android:textSize="14sp" android:lineSpacingExtra="4dp"/>
```

元素 TextView：显示文字。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_tagline"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_tagline，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_hero_secondary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_hero_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
android:lineSpacingExtra="4dp"：每行额外行距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 13 行

```xml
                </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 14 行

```xml
            </FrameLayout>
```

关闭 FrameLayout 元素，结束它的嵌套作用域。

## 第 15 行

```xml
            <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_weight="1" android:orientation="vertical" android:background="@drawable/bg_auth_sheet" android:padding="24dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:background="@drawable/bg_auth_sheet"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_auth_sheet，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 16 行

```xml
                <TextView android:id="@+id/auth_title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="4dp" android:text="@string/auth_title" android:textColor="@color/auth_on_surface" android:textSize="24sp" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_title"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_title。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="4dp"：顶部外边距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_title"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_on_surface"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="24sp"：字号，sp 会随系统字体大小变化。字号 24sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 17 行

```xml
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="@string/auth_subtitle" android:textColor="@color/auth_secondary" android:textSize="14sp"/>
```

元素 TextView：显示文字。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_subtitle"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_subtitle，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_secondary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 18 行

```xml
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:text="@string/auth_demo_notice" android:textColor="@color/auth_action" android:textSize="12sp" android:lineSpacingExtra="4dp"/>
```

元素 TextView：显示文字。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_demo_notice"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_demo_notice，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_action"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="12sp"：字号，sp 会随系统字体大小变化。字号 12sp，会响应用户系统字体缩放。
android:lineSpacingExtra="4dp"：每行额外行距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 19 行

```xml
                <TextView style="@style/AuthLabel" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="24dp" android:text="@string/auth_phone_label"/>
```

元素 TextView：显示文字。
style="@style/AuthLabel"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/AuthLabel，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="24dp"：顶部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_phone_label"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_phone_label，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 20 行

```xml
                <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="56dp" android:layout_marginTop="8dp" android:background="@drawable/bg_auth_field" android:gravity="center_vertical" android:baselineAligned="false">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="56dp"：最小高度，防止内容或触控区域过小。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_auth_field"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_auth_field，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:baselineAligned="false"：是否对齐子文字基线，false 可避免表单左右控件基线约束。

## 第 21 行

```xml
                    <TextView android:layout_width="60dp" android:layout_height="wrap_content" android:gravity="center" android:text="@string/auth_country_code" android:textColor="@color/auth_on_surface" android:textSize="16sp"/>
```

元素 TextView：显示文字。
android:layout_width="60dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 60dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="@string/auth_country_code"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_country_code，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_on_surface"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="16sp"：字号，sp 会随系统字体大小变化。字号 16sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 22 行

```xml
                    <View android:layout_width="1dp" android:layout_height="22dp" android:background="@color/auth_outline"/>
```

元素 View：通用视图，可用作分隔线。
android:layout_width="1dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 1dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="22dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@color/auth_outline"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/auth_outline，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 23 行

```xml
                    <EditText android:id="@+id/auth_phone" style="@style/AuthInput" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:hint="@string/auth_phone_hint" android:maxLength="11" android:inputType="phone" android:autofillHints="phoneNational" android:imeOptions="actionNext" android:nextFocusForward="@id/auth_code"/>
```

元素 EditText：接受用户输入。
android:id="@+id/auth_phone"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_phone。
style="@style/AuthInput"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/AuthInput，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:hint="@string/auth_phone_hint"：输入为空时的占位提示，不是实际输入值。引用资源 @string/auth_phone_hint，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:maxLength="11"：允许输入的最大字符数，不代表自动验证内容正确。
android:inputType="phone"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:autofillHints="phoneNational"：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
android:imeOptions="actionNext"：输入法动作按钮类型，例如 actionNext/Done。
android:nextFocusForward="@id/auth_code"：下一焦点的控件 ID，控制表单跳转顺序。引用控件 ID auth_code。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 24 行

```xml
                </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 25 行

```xml
                <TextView style="@style/AuthLabel" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="18dp" android:text="@string/auth_code_label"/>
```

元素 TextView：显示文字。
style="@style/AuthLabel"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/AuthLabel，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="18dp"：顶部外边距。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_code_label"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_code_label，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 26 行

```xml
                <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="56dp" android:layout_marginTop="8dp" android:background="@drawable/bg_auth_field" android:gravity="center_vertical" android:baselineAligned="false">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="56dp"：最小高度，防止内容或触控区域过小。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_auth_field"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_auth_field，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:baselineAligned="false"：是否对齐子文字基线，false 可避免表单左右控件基线约束。

## 第 27 行

```xml
                    <EditText android:id="@+id/auth_code" style="@style/AuthInput" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:hint="@string/auth_code_hint" android:maxLength="6" android:inputType="number" android:autofillHints="smsOTPCode" android:imeOptions="actionDone"/>
```

元素 EditText：接受用户输入。
android:id="@+id/auth_code"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_code。
style="@style/AuthInput"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/AuthInput，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:hint="@string/auth_code_hint"：输入为空时的占位提示，不是实际输入值。引用资源 @string/auth_code_hint，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:maxLength="6"：允许输入的最大字符数，不代表自动验证内容正确。
android:inputType="number"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:autofillHints="smsOTPCode"：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
android:imeOptions="actionDone"：输入法动作按钮类型，例如 actionNext/Done。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 28 行

```xml
                    <Button android:id="@+id/auth_get_code" android:layout_width="wrap_content" android:layout_height="wrap_content" android:minWidth="108dp" android:minHeight="48dp" android:layout_margin="4dp" android:paddingHorizontal="12dp" android:background="@drawable/bg_auth_code" android:text="@string/auth_get_code" android:textColor="@color/auth_code_text" android:textSize="13sp"/>
```

元素 Button：可点击按钮。
android:id="@+id/auth_get_code"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_get_code。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minWidth="108dp"：最小宽度。尺寸 108dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:minHeight="48dp"：最小高度，防止内容或触控区域过小。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_margin="4dp"：控件四周外边距，不属于控件内部可绘制区域。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingHorizontal="12dp"：左右内边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_auth_code"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_auth_code，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="@string/auth_get_code"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_get_code，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_code_text"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_code_text，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 29 行

```xml
                </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 30 行

```xml
                <TextView android:id="@+id/auth_error" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:textColor="@color/auth_error" android:textSize="13sp" android:lineSpacingExtra="4dp" android:visibility="gone" android:accessibilityLiveRegion="polite"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_error"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_error。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textColor="@color/auth_error"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_error，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
android:lineSpacingExtra="4dp"：每行额外行距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:visibility="gone"：visible 显示、invisible 隐藏但占位、gone 隐藏且不占位。
android:accessibilityLiveRegion="polite"：polite 表示内容更新时等读屏当前播报完成后提示。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 31 行

```xml
                <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:gravity="center_vertical" android:baselineAligned="false">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:baselineAligned="false"：是否对齐子文字基线，false 可避免表单左右控件基线约束。

## 第 32 行

```xml
                    <CheckBox android:id="@+id/auth_agree" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:minHeight="48dp" android:buttonTint="@color/auth_action" android:text="@string/auth_agreement" android:textSize="13sp" android:textColor="@color/auth_secondary"/>
```

元素 CheckBox：可勾选开关。
android:id="@+id/auth_agree"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_agree。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="48dp"：最小高度，防止内容或触控区域过小。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:buttonTint="@color/auth_action"：复选框按钮着色。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="@string/auth_agreement"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_agreement，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
android:textColor="@color/auth_secondary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 33 行

```xml
                    <TextView android:id="@+id/auth_terms" style="@style/AuthLink" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="@string/auth_terms"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_terms"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_terms。
style="@style/AuthLink"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/AuthLink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="@string/auth_terms"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_terms，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 34 行

```xml
                    <TextView android:id="@+id/auth_privacy" style="@style/AuthLink" android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginStart="4dp" android:text="@string/auth_privacy"/>
```

元素 TextView：显示文字。
android:id="@+id/auth_privacy"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_privacy。
style="@style/AuthLink"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/AuthLink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="4dp"：语言起始边外边距，中文通常是左边。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_privacy"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_privacy，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 35 行

```xml
                </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 36 行

```xml
                <Button android:id="@+id/auth_login" android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="56dp" android:layout_marginTop="12dp" android:paddingVertical="14dp" android:text="@string/auth_login" android:textColor="@color/auth_on_primary"/>
```

元素 Button：可点击按钮。
android:id="@+id/auth_login"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_login。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="56dp"：最小高度，防止内容或触控区域过小。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingVertical="14dp"：上下内边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="@string/auth_login"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_login，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_on_primary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_primary，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 37 行

```xml
                <Button android:id="@+id/auth_guest" android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="52dp" android:layout_marginTop="10dp" android:background="?android:attr/selectableItemBackground" android:text="@string/auth_guest" android:textColor="@color/auth_action" android:textSize="14sp"/>
```

元素 Button：可点击按钮。
android:id="@+id/auth_guest"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID auth_guest。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="52dp"：最小高度，防止内容或触控区域过小。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="?android:attr/selectableItemBackground"：控件背景，可是颜色、drawable 或主题属性。从当前主题解析属性 ?android:attr/selectableItemBackground。
android:text="@string/auth_guest"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_guest，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_action"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 38 行

```xml
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:gravity="center" android:text="@string/auth_local_data" android:textColor="@color/auth_secondary" android:textSize="12sp" android:lineSpacingExtra="4dp"/>
```

元素 TextView：显示文字。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="@string/auth_local_data"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_local_data，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_secondary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="12sp"：字号，sp 会随系统字体大小变化。字号 12sp，会响应用户系统字体缩放。
android:lineSpacingExtra="4dp"：每行额外行距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 39 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 40 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 41 行

```xml
    </ScrollView>
```

关闭 ScrollView 元素，结束它的嵌套作用域。

## 第 42 行

```xml
</FrameLayout>
```

关闭 FrameLayout 元素，结束它的嵌套作用域。
