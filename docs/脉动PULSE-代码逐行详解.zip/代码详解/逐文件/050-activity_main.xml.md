# app/src/main/res/layout/activity_main.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`f7ad7a491f903fd07016d7d100ba8942fd6b00bf0432d538b552fcf0b35895da`。行号仅对应此快照；修改源码后应重新核对。

共 11 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/root" android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:background="@color/canvas">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:id="@+id/root"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID root。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:background="@color/canvas"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/canvas，实际值见同名资源定义；night/v27 等目录可能覆盖。

## 第 2 行

```xml
    <FrameLayout android:id="@+id/page_container" android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" />
```

元素 FrameLayout：层叠容器，子视图可叠放。
android:id="@+id/page_container"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID page_container。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="0dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 3 行

```xml
    <View android:layout_width="match_parent" android:layout_height="1dp" android:background="@color/line" />
```

元素 View：通用视图，可用作分隔线。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="1dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 1dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@color/line"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/line，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" android:paddingVertical="5dp" android:background="@color/white">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="horizontal"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:paddingVertical="5dp"：上下内边距。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@color/white"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/white，实际值见同名资源定义；night/v27 等目录可能覆盖。

## 第 5 行

```xml
        <TextView android:id="@+id/nav_home" style="@style/Nav" android:text="今天" android:drawableTop="@drawable/ic_home"/>
```

元素 TextView：显示文字。
android:id="@+id/nav_home"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID nav_home。
style="@style/Nav"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Nav，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="今天"：显示文字；@string 引用文字资源，\n 表示换行。
android:drawableTop="@drawable/ic_home"：放在 TextView 文字上方的图标。引用资源 @drawable/ic_home，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
        <TextView android:id="@+id/nav_plan" style="@style/Nav" android:text="计划" android:drawableTop="@drawable/ic_plan"/>
```

元素 TextView：显示文字。
android:id="@+id/nav_plan"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID nav_plan。
style="@style/Nav"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Nav，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="计划"：显示文字；@string 引用文字资源，\n 表示换行。
android:drawableTop="@drawable/ic_plan"：放在 TextView 文字上方的图标。引用资源 @drawable/ic_plan，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 7 行

```xml
        <TextView android:id="@+id/nav_exercise" style="@style/Nav" android:text="动作" android:drawableTop="@drawable/ic_exercise"/>
```

元素 TextView：显示文字。
android:id="@+id/nav_exercise"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID nav_exercise。
style="@style/Nav"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Nav，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="动作"：显示文字；@string 引用文字资源，\n 表示换行。
android:drawableTop="@drawable/ic_exercise"：放在 TextView 文字上方的图标。引用资源 @drawable/ic_exercise，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
        <TextView android:id="@+id/nav_progress" style="@style/Nav" android:text="记录" android:drawableTop="@drawable/ic_progress"/>
```

元素 TextView：显示文字。
android:id="@+id/nav_progress"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID nav_progress。
style="@style/Nav"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Nav，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="记录"：显示文字；@string 引用文字资源，\n 表示换行。
android:drawableTop="@drawable/ic_progress"：放在 TextView 文字上方的图标。引用资源 @drawable/ic_progress，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
        <TextView android:id="@+id/nav_profile" style="@style/Nav" android:text="我的" android:drawableTop="@drawable/ic_person"/>
```

元素 TextView：显示文字。
android:id="@+id/nav_profile"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID nav_profile。
style="@style/Nav"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Nav，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="我的"：显示文字；@string 引用文字资源，\n 表示换行。
android:drawableTop="@drawable/ic_person"：放在 TextView 文字上方的图标。引用资源 @drawable/ic_person，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 11 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
