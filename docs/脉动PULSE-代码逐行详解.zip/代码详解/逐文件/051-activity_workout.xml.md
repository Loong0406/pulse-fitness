# app/src/main/res/layout/activity_workout.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`3fe035204cef0e48bba3a44a20e6fdcf9c65450fe5dafa4bdb09bed145540ae0`。行号仅对应此快照；修改源码后应重新核对。

共 18 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/workout_root" android:layout_width="match_parent" android:layout_height="match_parent" android:background="@color/canvas" android:orientation="vertical" android:padding="24dp">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:id="@+id/workout_root"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_root。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:background="@color/canvas"：控件背景，可是颜色、drawable 或主题属性。引用资源 @color/canvas，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="52dp" android:gravity="center_vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。

## 第 3 行

```xml
        <TextView android:id="@+id/workout_close" android:layout_width="48dp" android:layout_height="48dp" android:text="‹" android:textSize="34sp" android:textColor="@color/ink" android:gravity="center" android:contentDescription="返回并保存进度" android:background="?android:attr/selectableItemBackground" android:clickable="true" android:focusable="true"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_close"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_close。
android:layout_width="48dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="‹"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="34sp"：字号，sp 会随系统字体大小变化。字号 34sp，会响应用户系统字体缩放。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:contentDescription="返回并保存进度"：读屏使用的文字描述。
android:background="?android:attr/selectableItemBackground"：控件背景，可是颜色、drawable 或主题属性。从当前主题解析属性 ?android:attr/selectableItemBackground。
android:clickable="true"：是否可点击；实际业务动作仍由 Java 监听器绑定。
android:focusable="true"：是否可获键盘/无障碍焦点。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
        <TextView android:id="@+id/workout_heading" style="@style/Body" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:gravity="center" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_heading"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_heading。
style="@style/Body"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Body，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
        <TextView android:id="@+id/workout_elapsed" style="@style/Caption" android:layout_width="56dp" android:layout_height="wrap_content" android:gravity="end" android:text="00:00"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_elapsed"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_elapsed。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="56dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:gravity="end"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="00:00"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    <ProgressBar android:id="@+id/workout_progress" style="?android:attr/progressBarStyleHorizontal" android:layout_width="match_parent" android:layout_height="5dp" android:layout_marginTop="16dp" android:progressTint="@color/green" android:progressBackgroundTint="@color/line"/>
```

元素 ProgressBar：显示确定或不确定进度。
android:id="@+id/workout_progress"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_progress。
style="?android:attr/progressBarStyleHorizontal"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。从当前主题解析属性 ?android:attr/progressBarStyleHorizontal。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="5dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:progressTint="@color/green"：已完成进度颜色。引用资源 @color/green，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:progressBackgroundTint="@color/line"：未完成进度背景颜色。引用资源 @color/line，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
    <ScrollView android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" android:layout_marginTop="24dp"><LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="0dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_marginTop="24dp"：顶部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 9 行

```xml
        <TextView android:id="@+id/workout_phase" style="@style/Label" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="MOVE WITH INTENTION"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_phase"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_phase。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="MOVE WITH INTENTION"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
        <TextView android:id="@+id/workout_name" style="@style/Title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_name"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_name。
style="@style/Title"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 11 行

```xml
        <com.pulse.fitness.ui.widget.ExerciseArtView android:id="@+id/workout_art" android:layout_width="match_parent" android:layout_height="210dp" android:layout_marginTop="20dp" android:background="@drawable/bg_accent" android:contentDescription="训练动作装饰示意，操作请以文字要领为准"/>
```

元素 com.pulse.fitness.ui.widget.ExerciseArtView：自定义原生控件 ExerciseArtView，实际绘制由同名 Java 类实现。
android:id="@+id/workout_art"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_art。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="210dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 210dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="20dp"：顶部外边距。尺寸 20dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_accent"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_accent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:contentDescription="训练动作装饰示意，操作请以文字要领为准"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 12 行

```xml
        <TextView android:id="@+id/workout_target" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="22dp" android:gravity="center" android:textColor="@color/ink" android:textSize="42sp" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_target"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_target。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="22dp"：顶部外边距。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="42sp"：字号，sp 会随系统字体大小变化。字号 42sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 13 行

```xml
        <TextView android:id="@+id/workout_set" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:gravity="center"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_set"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_set。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 14 行

```xml
        <TextView android:id="@+id/workout_cue" style="@style/Body" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="22dp" android:padding="18dp" android:background="@drawable/bg_card"/>
```

元素 TextView：显示文字。
android:id="@+id/workout_cue"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_cue。
style="@style/Body"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Body，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="22dp"：顶部外边距。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:padding="18dp"：四边内边距，位于控件边界里面。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_card"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_card，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 15 行

```xml
    </LinearLayout></ScrollView>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
关闭 ScrollView 元素，结束它的嵌套作用域。

## 第 16 行

```xml
    <Button android:id="@+id/workout_primary" android:layout_width="match_parent" android:layout_height="54dp" android:layout_marginTop="16dp" android:text="完成本组"/>
```

元素 Button：可点击按钮。
android:id="@+id/workout_primary"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_primary。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="54dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 54dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="完成本组"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 17 行

```xml
    <Button android:id="@+id/workout_pause" android:layout_width="match_parent" android:layout_height="48dp" android:layout_marginTop="10dp" android:background="@drawable/bg_chip" android:text="暂停训练"/>
```

元素 Button：可点击按钮。
android:id="@+id/workout_pause"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID workout_pause。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="暂停训练"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 18 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
