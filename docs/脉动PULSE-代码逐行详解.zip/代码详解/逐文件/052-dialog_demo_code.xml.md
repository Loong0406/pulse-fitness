# app/src/main/res/layout/dialog_demo_code.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`5c0eedaedfd7ce48e27c50e70de8462ef318ea05078ee7848290113b05a5d699`。行号仅对应此快照；修改源码后应重新核对。

共 4 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:paddingHorizontal="24dp" android:paddingVertical="16dp">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:paddingHorizontal="24dp"：左右内边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingVertical="16dp"：上下内边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 2 行

```xml
    <TextView android:id="@+id/demo_code_value" android:layout_width="match_parent" android:layout_height="wrap_content" android:textColor="@color/auth_on_surface" android:textSize="32sp" android:fontFamily="monospace" android:gravity="center" android:paddingVertical="12dp" android:letterSpacing="0.12" android:textIsSelectable="true"/>
```

元素 TextView：显示文字。
android:id="@+id/demo_code_value"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID demo_code_value。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:textColor="@color/auth_on_surface"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="32sp"：字号，sp 会随系统字体大小变化。字号 32sp，会响应用户系统字体缩放。
android:fontFamily="monospace"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:paddingVertical="12dp"：上下内边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:letterSpacing="0.12"：字母间距，数值以 em 为相对单位。
android:textIsSelectable="true"：是否允许长按选择文字。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 3 行

```xml
    <TextView android:id="@+id/demo_code_description" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:textColor="@color/auth_secondary" android:textSize="14sp" android:lineSpacingExtra="5dp"/>
```

元素 TextView：显示文字。
android:id="@+id/demo_code_description"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID demo_code_description。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textColor="@color/auth_secondary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
android:lineSpacingExtra="5dp"：每行额外行距。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
