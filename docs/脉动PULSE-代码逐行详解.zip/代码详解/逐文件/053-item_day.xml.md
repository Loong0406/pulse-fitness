# app/src/main/res/layout/item_day.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`be2634a0ecc89c7b0b7688d5e4aac856d5aa7085fc1e6242ec58381c931c9fd5`。行号仅对应此快照；修改源码后应重新核对。

共 11 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginBottom="12dp" android:background="@drawable/bg_card" android:padding="18dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginBottom="12dp"：底部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_card"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_card，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:padding="18dp"：四边内边距，位于控件边界里面。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:gravity="center_vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。

## 第 3 行

```xml
        <TextView android:id="@+id/day_number" android:layout_width="46dp" android:layout_height="46dp" android:background="@drawable/bg_chip" android:gravity="center" android:textColor="@color/ink" android:textSize="13sp"/>
```

元素 TextView：显示文字。
android:id="@+id/day_number"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID day_number。
android:layout_width="46dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 46dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="46dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 46dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
        <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:layout_marginStart="14dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="14dp"：语言起始边外边距，中文通常是左边。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 5 行

```xml
            <TextView android:id="@+id/day_title" style="@style/Body" android:fontFamily="sans-serif-medium" android:layout_width="match_parent" android:layout_height="wrap_content"/>
```

元素 TextView：显示文字。
android:id="@+id/day_title"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID day_title。
style="@style/Body"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Body，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
            <TextView android:id="@+id/day_meta" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="4dp"/>
```

元素 TextView：显示文字。
android:id="@+id/day_meta"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID day_meta。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="4dp"：顶部外边距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 7 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 8 行

```xml
        <TextView android:id="@+id/day_start" style="@style/Chip" android:layout_width="54dp" android:layout_height="48dp" android:text="开始" android:paddingHorizontal="6dp" android:contentDescription="开始此日训练"/>
```

元素 TextView：显示文字。
android:id="@+id/day_start"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID day_start。
style="@style/Chip"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="54dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 54dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="开始"：显示文字；@string 引用文字资源，\n 表示换行。
android:paddingHorizontal="6dp"：左右内边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="开始此日训练"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 10 行

```xml
    <LinearLayout android:id="@+id/day_exercises" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:layout_marginTop="12dp"/>
```

元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/day_exercises"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID day_exercises。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 11 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
