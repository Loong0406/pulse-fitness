# app/src/main/res/layout/item_exercise.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`d884349c75412f0ad0e99fda5d99f10b226d4e788c6b08378ce145559227a80f`。行号仅对应此快照；修改源码后应重新核对。

共 8 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginBottom="12dp" android:background="@drawable/bg_card" android:padding="16dp" android:gravity="center_vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginBottom="12dp"：底部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_card"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_card，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:padding="16dp"：四边内边距，位于控件边界里面。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。

## 第 2 行

```xml
    <TextView android:id="@+id/exercise_symbol" android:layout_width="52dp" android:layout_height="52dp" android:background="@drawable/bg_chip" android:gravity="center" android:text="↗" android:textSize="24sp" android:textColor="@color/green"/>
```

元素 TextView：显示文字。
android:id="@+id/exercise_symbol"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_symbol。
android:layout_width="52dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="↗"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="24sp"：字号，sp 会随系统字体大小变化。字号 24sp，会响应用户系统字体缩放。
android:textColor="@color/green"：文字颜色，可以引用状态颜色列表。引用资源 @color/green，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 3 行

```xml
    <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:layout_marginStart="14dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="14dp"：语言起始边外边距，中文通常是左边。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 4 行

```xml
        <TextView android:id="@+id/exercise_name" style="@style/Body" android:layout_width="match_parent" android:layout_height="wrap_content" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/exercise_name"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_name。
style="@style/Body"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Body，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
        <TextView android:id="@+id/exercise_meta" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="5dp"/>
```

元素 TextView：显示文字。
android:id="@+id/exercise_meta"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_meta。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="5dp"：顶部外边距。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    <TextView android:id="@+id/exercise_favorite" android:layout_width="48dp" android:layout_height="48dp" android:gravity="center" android:text="☆" android:textSize="25sp" android:textColor="@color/green" android:background="?android:attr/selectableItemBackground" android:contentDescription="收藏动作" android:clickable="true" android:focusable="true"/>
```

元素 TextView：显示文字。
android:id="@+id/exercise_favorite"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_favorite。
android:layout_width="48dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="☆"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="25sp"：字号，sp 会随系统字体大小变化。字号 25sp，会响应用户系统字体缩放。
android:textColor="@color/green"：文字颜色，可以引用状态颜色列表。引用资源 @color/green，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:background="?android:attr/selectableItemBackground"：控件背景，可是颜色、drawable 或主题属性。从当前主题解析属性 ?android:attr/selectableItemBackground。
android:contentDescription="收藏动作"：读屏使用的文字描述。
android:clickable="true"：是否可点击；实际业务动作仍由 Java 监听器绑定。
android:focusable="true"：是否可获键盘/无障碍焦点。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
