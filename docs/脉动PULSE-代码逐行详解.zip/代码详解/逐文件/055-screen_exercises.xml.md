# app/src/main/res/layout/screen_exercises.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`52df52df6c91ccf51aaaf9af6611be6c4262fa768e6f014fe37c286fed88086a`。行号仅对应此快照；修改源码后应重新核对。

共 11 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:paddingHorizontal="24dp" android:paddingTop="24dp">
```

元素 LinearLayout：按方向排列子视图的容器。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:paddingHorizontal="24dp"：左右内边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingTop="24dp"：顶部内边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 2 行

```xml
    <TextView style="@style/Label" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="KNOW YOUR MOVEMENT"/>
```

元素 TextView：显示文字。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="KNOW YOUR MOVEMENT"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 3 行

```xml
    <TextView style="@style/Title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:text="每个动作，都练对。"/>
```

元素 TextView：显示文字。
style="@style/Title"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="每个动作，都练对。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
    <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="动作要领 · 器械筛选 · 你的收藏"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="动作要领 · 器械筛选 · 你的收藏"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
    <EditText android:id="@+id/exercise_search" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="22dp" android:hint="搜索动作、部位或器械" android:inputType="text" android:imeOptions="actionSearch" android:maxLength="160" android:autofillHints=""/>
```

元素 EditText：接受用户输入。
android:id="@+id/exercise_search"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_search。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="22dp"：顶部外边距。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:hint="搜索动作、部位或器械"：输入为空时的占位提示，不是实际输入值。
android:inputType="text"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:imeOptions="actionSearch"：输入法动作按钮类型，例如 actionNext/Done。
android:maxLength="160"：允许输入的最大字符数，不代表自动验证内容正确。
android:autofillHints=""：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
    <HorizontalScrollView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:scrollbars="none">
```

元素 HorizontalScrollView：横向滚动容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:scrollbars="none"：滚动条显示方向/none。

## 第 7 行

```xml
        <LinearLayout android:id="@+id/exercise_filters" android:layout_width="wrap_content" android:layout_height="wrap_content" android:orientation="horizontal"/>
```

元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/exercise_filters"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_filters。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="horizontal"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
    </HorizontalScrollView>
```

关闭 HorizontalScrollView 元素，结束它的嵌套作用域。

## 第 9 行

```xml
    <TextView android:id="@+id/exercise_count" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:layout_marginBottom="12dp"/>
```

元素 TextView：显示文字。
android:id="@+id/exercise_count"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_count。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginBottom="12dp"：底部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
    <ScrollView android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1"><LinearLayout android:id="@+id/exercise_list" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:paddingBottom="24dp"/></ScrollView>
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="0dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/exercise_list"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID exercise_list。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:paddingBottom="24dp"：底部内边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 ScrollView 元素，结束它的嵌套作用域。

## 第 11 行

```xml
</LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。
