# app/src/main/res/layout/screen_home.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`afe1bd6bc0c9cb12b2385616375b8d205ef366238d6acdbbe20e03dfc71810d2`。行号仅对应此快照；修改源码后应重新核对。

共 38 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent" android:fillViewport="true" android:clipToPadding="false">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:fillViewport="true"：ScrollView 内容不足一屏时也撑满可视高度。
android:clipToPadding="false"：是否把绘制裁到内边距，false 可让滚动内容延伸到 padding 区。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:padding="24dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 3 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="48dp" android:gravity="center_vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。

## 第 4 行

```xml
            <ImageView android:layout_width="32dp" android:layout_height="32dp" android:src="@drawable/ic_launcher" android:contentDescription="脉动标志"/>
```

元素 ImageView：显示图像。
android:layout_width="32dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 32dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="32dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 32dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:src="@drawable/ic_launcher"：ImageView 内容图像资源。引用资源 @drawable/ic_launcher，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:contentDescription="脉动标志"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
            <TextView android:layout_width="0dp" android:layout_height="wrap_content" android:layout_weight="1" android:layout_marginStart="10dp" android:text="PULSE / 脉动" android:textSize="17sp" android:textColor="@color/ink" android:fontFamily="sans-serif-black" android:letterSpacing="0.04"/>
```

元素 TextView：显示文字。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_marginStart="10dp"：语言起始边外边距，中文通常是左边。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="PULSE / 脉动"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="17sp"：字号，sp 会随系统字体大小变化。字号 17sp，会响应用户系统字体缩放。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:fontFamily="sans-serif-black"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
android:letterSpacing="0.04"：字母间距，数值以 em 为相对单位。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
            <TextView android:id="@+id/home_avatar" android:layout_width="44dp" android:layout_height="44dp" android:background="@drawable/bg_chip" android:gravity="center" android:text="你" android:textColor="@color/ink" android:textSize="17sp" android:contentDescription="编辑个人档案" android:clickable="true" android:focusable="true"/>
```

元素 TextView：显示文字。
android:id="@+id/home_avatar"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_avatar。
android:layout_width="44dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 44dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="44dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 44dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="你"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="17sp"：字号，sp 会随系统字体大小变化。字号 17sp，会响应用户系统字体缩放。
android:contentDescription="编辑个人档案"：读屏使用的文字描述。
android:clickable="true"：是否可点击；实际业务动作仍由 Java 监听器绑定。
android:focusable="true"：是否可获键盘/无障碍焦点。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 7 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 8 行

```xml
        <TextView android:id="@+id/home_date" style="@style/Label" android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="26dp" android:text="YOUR EVERYDAY, BETTER"/>
```

元素 TextView：显示文字。
android:id="@+id/home_date"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_date。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="26dp"：顶部外边距。尺寸 26dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="YOUR EVERYDAY, BETTER"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
        <TextView android:id="@+id/home_greeting" style="@style/Title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="10dp" android:text="今天，为自己开练。"/>
```

元素 TextView：显示文字。
android:id="@+id/home_greeting"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_greeting。
style="@style/Title"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="今天，为自己开练。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
        <TextView android:id="@+id/home_subtitle" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:text="一点进步，也值得认真对待。"/>
```

元素 TextView：显示文字。
android:id="@+id/home_subtitle"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_subtitle。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="一点进步，也值得认真对待。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 11 行

```xml
        <FrameLayout android:layout_width="match_parent" android:layout_height="262dp" android:layout_marginTop="24dp" android:background="@drawable/bg_dark">
```

元素 FrameLayout：层叠容器，子视图可叠放。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="262dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 262dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="24dp"：顶部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_dark"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_dark，实际值见同名资源定义；night/v27 等目录可能覆盖。

## 第 12 行

```xml
            <ImageView android:layout_width="190dp" android:layout_height="230dp" android:layout_gravity="end|bottom" android:src="@drawable/hero_art" android:importantForAccessibility="no"/>
```

元素 ImageView：显示图像。
android:layout_width="190dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 190dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="230dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 230dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_gravity="end|bottom"：当前控件相对父容器的对齐；区别于内部内容的 gravity。
android:src="@drawable/hero_art"：ImageView 内容图像资源。引用资源 @drawable/hero_art，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:importantForAccessibility="no"：no 表示装饰图不进入无障碍朗读顺序。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 13 行

```xml
            <LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:padding="24dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 14 行

```xml
                <TextView android:id="@+id/home_source" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="PERSONAL TRAINING" android:textSize="10sp" android:letterSpacing="0.12" android:textColor="@color/lime"/>
```

元素 TextView：显示文字。
android:id="@+id/home_source"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_source。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="PERSONAL TRAINING"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="10sp"：字号，sp 会随系统字体大小变化。字号 10sp，会响应用户系统字体缩放。
android:letterSpacing="0.12"：字母间距，数值以 em 为相对单位。
android:textColor="@color/lime"：文字颜色，可以引用状态颜色列表。引用资源 @color/lime，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 15 行

```xml
                <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:text="让训练\n更懂你。" android:textColor="@color/white" android:textSize="32sp" android:fontFamily="sans-serif-medium" android:lineSpacingExtra="2dp"/>
```

元素 TextView：显示文字。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="让训练\n更懂你。"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="@color/white"：文字颜色，可以引用状态颜色列表。引用资源 @color/white，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="32sp"：字号，sp 会随系统字体大小变化。字号 32sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
android:lineSpacingExtra="2dp"：每行额外行距。尺寸 2dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 16 行

```xml
                <TextView android:id="@+id/home_plan_hint" android:layout_width="170dp" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="从一份专属计划开始" android:textSize="12sp" android:textColor="#B6C4B6"/>
```

元素 TextView：显示文字。
android:id="@+id/home_plan_hint"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_plan_hint。
android:layout_width="170dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 170dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="从一份专属计划开始"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="12sp"：字号，sp 会随系统字体大小变化。字号 12sp，会响应用户系统字体缩放。
android:textColor="#B6C4B6"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 17 行

```xml
                <Button android:id="@+id/home_start" android:layout_width="wrap_content" android:layout_height="48dp" android:layout_marginTop="20dp" android:text="开启训练  ↗" android:textSize="13sp" android:paddingHorizontal="18dp"/>
```

元素 Button：可点击按钮。
android:id="@+id/home_start"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_start。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="20dp"：顶部外边距。尺寸 20dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="开启训练  ↗"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
android:paddingHorizontal="18dp"：左右内边距。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 18 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 19 行

```xml
        </FrameLayout>
```

关闭 FrameLayout 元素，结束它的嵌套作用域。

## 第 20 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:orientation="horizontal">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="horizontal"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 21 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_height="112dp" android:layout_weight="1" android:background="@drawable/bg_accent" android:orientation="vertical" android:padding="18dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="112dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 112dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:background="@drawable/bg_accent"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_accent，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:padding="18dp"：四边内边距，位于控件边界里面。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 22 行

```xml
                <TextView android:id="@+id/home_sessions" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="0 次" android:textColor="@color/ink" android:textSize="28sp" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/home_sessions"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_sessions。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="0 次"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="28sp"：字号，sp 会随系统字体大小变化。字号 28sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 23 行

```xml
                <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="本周完成训练" android:textColor="#4D623F"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="本周完成训练"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="#4D623F"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 24 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 25 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_height="112dp" android:layout_weight="1" android:layout_marginStart="12dp" android:background="@drawable/bg_card" android:orientation="vertical" android:padding="18dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_height="112dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 112dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_marginStart="12dp"：语言起始边外边距，中文通常是左边。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_card"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_card，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:padding="18dp"：四边内边距，位于控件边界里面。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 26 行

```xml
                <TextView android:id="@+id/home_minutes" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="0 分钟" android:textColor="@color/ink" android:textSize="28sp" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/home_minutes"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_minutes。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="0 分钟"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="@color/ink"：文字颜色，可以引用状态颜色列表。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="28sp"：字号，sp 会随系统字体大小变化。字号 28sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 27 行

```xml
                <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="累计投入的时间"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="累计投入的时间"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 28 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 29 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 30 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:gravity="center_vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。

## 第 31 行

```xml
            <TextView style="@style/Section" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:text="你的训练节奏"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="你的训练节奏"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 32 行

```xml
            <TextView android:id="@+id/home_all_plan" style="@style/Chip" android:layout_width="wrap_content" android:layout_height="48dp" android:text="查看计划 ↗"/>
```

元素 TextView：显示文字。
android:id="@+id/home_all_plan"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_all_plan。
style="@style/Chip"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="48dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="查看计划 ↗"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 33 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 34 行

```xml
        <LinearLayout android:id="@+id/home_week" android:layout_width="match_parent" android:layout_height="84dp" android:layout_marginTop="14dp" android:orientation="horizontal"/>
```

元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/home_week"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_week。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="84dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 84dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="horizontal"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 35 行

```xml
        <TextView android:id="@+id/home_tip" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:text="先完善档案，再选择适合自己的节奏。"/>
```

元素 TextView：显示文字。
android:id="@+id/home_tip"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID home_tip。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="先完善档案，再选择适合自己的节奏。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 36 行

```xml
        <TextView style="@style/Label" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:layout_marginBottom="12dp" android:gravity="center" android:text="MOVE AT YOUR OWN PACE"/>
```

元素 TextView：显示文字。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginBottom="12dp"：底部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="MOVE AT YOUR OWN PACE"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 37 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 38 行

```xml
</ScrollView>
```

关闭 ScrollView 元素，结束它的嵌套作用域。
