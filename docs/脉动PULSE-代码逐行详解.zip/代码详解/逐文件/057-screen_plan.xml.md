# app/src/main/res/layout/screen_plan.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`52af0e3e98d249d0484c20d44c5ab38309fe4452069302ae37eff3523b554478`。行号仅对应此快照；修改源码后应重新核对。

共 21 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:padding="24dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 3 行

```xml
        <TextView style="@style/Label" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="BUILT AROUND YOU"/>
```

元素 TextView：显示文字。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="BUILT AROUND YOU"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
        <TextView style="@style/Title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:text="一周，有计划。"/>
```

元素 TextView：显示文字。
style="@style/Title"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="一周，有计划。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
        <TextView android:id="@+id/plan_summary" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp"/>
```

元素 TextView：显示文字。
android:id="@+id/plan_summary"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_summary。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="22dp" android:padding="20dp" android:background="@drawable/bg_dark" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="22dp"：顶部外边距。尺寸 22dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:padding="20dp"：四边内边距，位于控件边界里面。尺寸 20dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_dark"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_dark，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 7 行

```xml
            <TextView android:id="@+id/plan_source" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="为你定制训练节奏" android:textColor="@color/lime" android:textSize="17sp"/>
```

元素 TextView：显示文字。
android:id="@+id/plan_source"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_source。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="为你定制训练节奏"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="@color/lime"：文字颜色，可以引用状态颜色列表。引用资源 @color/lime，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="17sp"：字号，sp 会随系统字体大小变化。字号 17sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
            <TextView android:id="@+id/plan_note" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:textColor="#CDDACB" android:textSize="13sp" android:lineSpacingExtra="5dp"/>
```

元素 TextView：显示文字。
android:id="@+id/plan_note"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_note。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textColor="#CDDACB"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
android:lineSpacingExtra="5dp"：每行额外行距。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
            <ProgressBar android:id="@+id/plan_loading" style="?android:attr/progressBarStyleHorizontal" android:layout_width="match_parent" android:layout_height="4dp" android:layout_marginTop="16dp" android:indeterminate="true" android:indeterminateTint="@color/lime" android:visibility="gone"/>
```

元素 ProgressBar：显示确定或不确定进度。
android:id="@+id/plan_loading"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_loading。
style="?android:attr/progressBarStyleHorizontal"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。从当前主题解析属性 ?android:attr/progressBarStyleHorizontal。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="4dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:indeterminate="true"：进度条是否未知总进度；true 时显示持续加载动画。
android:indeterminateTint="@color/lime"：不确定进度动画颜色。引用资源 @color/lime，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:visibility="gone"：visible 显示、invisible 隐藏但占位、gone 隐藏且不占位。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
            <Button android:id="@+id/plan_ai" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="18dp" android:text="✦ 生成 AI 专属计划"/>
```

元素 Button：可点击按钮。
android:id="@+id/plan_ai"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_ai。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="18dp"：顶部外边距。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="✦ 生成 AI 专属计划"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 11 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 12 行

```xml
        <TextView android:id="@+id/plan_message" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:accessibilityLiveRegion="polite"/>
```

元素 TextView：显示文字。
android:id="@+id/plan_message"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_message。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:accessibilityLiveRegion="polite"：polite 表示内容更新时等读屏当前播报完成后提示。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 13 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:orientation="horizontal">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="horizontal"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 14 行

```xml
            <Button android:id="@+id/plan_local" android:layout_width="0dp" android:layout_weight="1" android:layout_height="52dp" android:background="@drawable/bg_chip" android:text="使用本地计划" android:textSize="13sp"/>
```

元素 Button：可点击按钮。
android:id="@+id/plan_local"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_local。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="使用本地计划"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 15 行

```xml
            <Button android:id="@+id/plan_copy" android:layout_width="0dp" android:layout_weight="1" android:layout_height="52dp" android:layout_marginStart="12dp" android:background="@drawable/bg_chip" android:text="复制到新周期" android:textSize="13sp"/>
```

元素 Button：可点击按钮。
android:id="@+id/plan_copy"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_copy。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginStart="12dp"：语言起始边外边距，中文通常是左边。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="复制到新周期"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 16 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 17 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:text="本周安排"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="本周安排"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 18 行

```xml
        <LinearLayout android:id="@+id/plan_days" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:layout_marginTop="14dp"/>
```

元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/plan_days"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_days。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 19 行

```xml
        <Button android:id="@+id/plan_export" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="18dp" android:background="@drawable/bg_chip" android:text="导出训练计划 ↗"/>
```

元素 Button：可点击按钮。
android:id="@+id/plan_export"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID plan_export。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="18dp"：顶部外边距。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="导出训练计划 ↗"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 20 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 21 行

```xml
</ScrollView>
```

关闭 ScrollView 元素，结束它的嵌套作用域。
