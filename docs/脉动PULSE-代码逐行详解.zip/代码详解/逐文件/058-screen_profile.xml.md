# app/src/main/res/layout/screen_profile.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`096f0da16632cd8efed987f76bc8cfc9139a56d1417f74870db55714b7fbc425`。行号仅对应此快照；修改源码后应重新核对。

共 65 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/profile_scroll" android:layout_width="match_parent" android:layout_height="match_parent" android:fillViewport="true">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:id="@+id/profile_scroll"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_scroll。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。
android:fillViewport="true"：ScrollView 内容不足一屏时也撑满可视高度。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:padding="24dp" android:orientation="vertical" android:descendantFocusability="beforeDescendants" android:focusableInTouchMode="true">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:descendantFocusability="beforeDescendants"：父容器与子控件之间的焦点分配顺序。
android:focusableInTouchMode="true"：触摸模式下也允许获得焦点，可避免默认把焦点给输入框。

## 第 3 行

```xml
        <TextView style="@style/Label" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="YOUR BODY, YOUR PACE"/>
```

元素 TextView：显示文字。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="YOUR BODY, YOUR PACE"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
        <TextView style="@style/Title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:text="从了解你开始。"/>
```

元素 TextView：显示文字。
style="@style/Title"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="从了解你开始。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="档案保存在本机。生成 AI 计划时会发送训练所需资料，昵称和性别不会发往模型。"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="档案保存在本机。生成 AI 计划时会发送训练所需资料，昵称和性别不会发往模型。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="24dp" android:padding="18dp" android:background="@drawable/bg_auth_field" android:gravity="center_vertical" android:baselineAligned="false">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="24dp"：顶部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:padding="18dp"：四边内边距，位于控件边界里面。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_auth_field"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_auth_field，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:gravity="center_vertical"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:baselineAligned="false"：是否对齐子文字基线，false 可避免表单左右控件基线约束。

## 第 7 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 8 行

```xml
                <TextView android:id="@+id/profile_account_title" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="@string/auth_account_guest" android:textColor="@color/auth_on_surface" android:textSize="17sp" android:fontFamily="sans-serif-medium"/>
```

元素 TextView：显示文字。
android:id="@+id/profile_account_title"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_account_title。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="@string/auth_account_guest"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_account_guest，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_on_surface"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="17sp"：字号，sp 会随系统字体大小变化。字号 17sp，会响应用户系统字体缩放。
android:fontFamily="sans-serif-medium"：字体族；sans-serif-medium 使用系统中等字重无衬线字体。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
                <TextView android:id="@+id/profile_account_note" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:textColor="@color/auth_secondary" android:textSize="12sp" android:lineSpacingExtra="4dp"/>
```

元素 TextView：显示文字。
android:id="@+id/profile_account_note"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_account_note。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textColor="@color/auth_secondary"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="12sp"：字号，sp 会随系统字体大小变化。字号 12sp，会响应用户系统字体缩放。
android:lineSpacingExtra="4dp"：每行额外行距。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 11 行

```xml
            <Button android:id="@+id/profile_account_action" android:layout_width="wrap_content" android:layout_height="wrap_content" android:minHeight="48dp" android:layout_marginStart="12dp" android:paddingHorizontal="14dp" android:background="@drawable/bg_auth_code" android:textColor="@color/auth_action" android:text="@string/auth_account_sign_in" android:textSize="13sp"/>
```

元素 Button：可点击按钮。
android:id="@+id/profile_account_action"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_account_action。
android:layout_width="wrap_content"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。以内容测量所需尺寸。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="48dp"：最小高度，防止内容或触控区域过小。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginStart="12dp"：语言起始边外边距，中文通常是左边。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:paddingHorizontal="14dp"：左右内边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_auth_code"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_auth_code，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textColor="@color/auth_action"：文字颜色，可以引用状态颜色列表。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="@string/auth_account_sign_in"：显示文字；@string 引用文字资源，\n 表示换行。引用资源 @string/auth_account_sign_in，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 12 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 13 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:text="01  基本信息"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="01  基本信息"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 14 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:labelFor="@id/profile_name" android:text="怎么称呼你"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:labelFor="@id/profile_name"：声明这段文字是哪个输入控件的标签，帮助读屏理解。引用控件 ID profile_name。
android:text="怎么称呼你"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 15 行

```xml
        <EditText android:id="@+id/profile_name" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:hint="你的昵称" android:maxLength="24" android:inputType="textPersonName" android:autofillHints="nickname"/>
```

元素 EditText：接受用户输入。
android:id="@+id/profile_name"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_name。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:hint="你的昵称"：输入为空时的占位提示，不是实际输入值。
android:maxLength="24"：允许输入的最大字符数，不代表自动验证内容正确。
android:inputType="textPersonName"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:autofillHints="nickname"：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 16 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 17 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 18 行

```xml
                <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:labelFor="@id/profile_age" android:text="年龄 / 岁"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:labelFor="@id/profile_age"：声明这段文字是哪个输入控件的标签，帮助读屏理解。引用控件 ID profile_age。
android:text="年龄 / 岁"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 19 行

```xml
                <EditText android:id="@+id/profile_age" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:inputType="number" android:maxLength="2" android:autofillHints=""/>
```

元素 EditText：接受用户输入。
android:id="@+id/profile_age"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_age。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:inputType="number"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:maxLength="2"：允许输入的最大字符数，不代表自动验证内容正确。
android:autofillHints=""：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 20 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 21 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:layout_marginStart="12dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="12dp"：语言起始边外边距，中文通常是左边。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 22 行

```xml
                <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="性别 / 可不透露"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="性别 / 可不透露"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 23 行

```xml
                <Spinner android:id="@+id/profile_sex" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:background="@drawable/bg_input" android:paddingHorizontal="10dp" android:contentDescription="性别"/>
```

元素 Spinner：下拉单选控件。
android:id="@+id/profile_sex"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_sex。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_input"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:paddingHorizontal="10dp"：左右内边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="性别"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 24 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 25 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 26 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 27 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 28 行

```xml
                <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:labelFor="@id/profile_height" android:text="身高 / cm"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:labelFor="@id/profile_height"：声明这段文字是哪个输入控件的标签，帮助读屏理解。引用控件 ID profile_height。
android:text="身高 / cm"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 29 行

```xml
                <EditText android:id="@+id/profile_height" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:inputType="numberDecimal" android:maxLength="5" android:autofillHints=""/>
```

元素 EditText：接受用户输入。
android:id="@+id/profile_height"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_height。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:inputType="numberDecimal"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:maxLength="5"：允许输入的最大字符数，不代表自动验证内容正确。
android:autofillHints=""：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 30 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 31 行

```xml
            <LinearLayout android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:layout_marginStart="12dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="0dp"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_weight="1"：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginStart="12dp"：语言起始边外边距，中文通常是左边。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 32 行

```xml
                <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:labelFor="@id/profile_weight" android:text="体重 / kg"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:labelFor="@id/profile_weight"：声明这段文字是哪个输入控件的标签，帮助读屏理解。引用控件 ID profile_weight。
android:text="体重 / kg"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 33 行

```xml
                <EditText android:id="@+id/profile_weight" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:inputType="numberDecimal" android:maxLength="5" android:autofillHints=""/>
```

元素 EditText：接受用户输入。
android:id="@+id/profile_weight"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_weight。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:inputType="numberDecimal"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:maxLength="5"：允许输入的最大字符数，不代表自动验证内容正确。
android:autofillHints=""：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 34 行

```xml
            </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 35 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 36 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:text="02  训练偏好"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="02  训练偏好"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 37 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:text="当前目标"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="当前目标"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 38 行

```xml
        <Spinner android:id="@+id/profile_goal" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:background="@drawable/bg_input" android:paddingHorizontal="10dp" android:contentDescription="训练目标"/>
```

元素 Spinner：下拉单选控件。
android:id="@+id/profile_goal"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_goal。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_input"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:paddingHorizontal="10dp"：左右内边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="训练目标"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 39 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:text="训练经验"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="训练经验"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 40 行

```xml
        <Spinner android:id="@+id/profile_experience" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:background="@drawable/bg_input" android:paddingHorizontal="10dp" android:contentDescription="训练经验"/>
```

元素 Spinner：下拉单选控件。
android:id="@+id/profile_experience"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_experience。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_input"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:paddingHorizontal="10dp"：左右内边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="训练经验"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 41 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:text="可用器械"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="可用器械"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 42 行

```xml
        <Spinner android:id="@+id/profile_equipment" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:background="@drawable/bg_input" android:paddingHorizontal="10dp" android:contentDescription="可用器械"/>
```

元素 Spinner：下拉单选控件。
android:id="@+id/profile_equipment"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_equipment。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_input"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:paddingHorizontal="10dp"：左右内边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="可用器械"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 43 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:text="每周训练 / 天"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="每周训练 / 天"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 44 行

```xml
        <Spinner android:id="@+id/profile_days" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:background="@drawable/bg_input" android:paddingHorizontal="10dp" android:contentDescription="每周训练天数"/>
```

元素 Spinner：下拉单选控件。
android:id="@+id/profile_days"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_days。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_input"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:paddingHorizontal="10dp"：左右内边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="每周训练天数"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 45 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:text="每次训练 / 分钟（含热身放松）"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="每次训练 / 分钟（含热身放松）"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 46 行

```xml
        <Spinner android:id="@+id/profile_minutes" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="6dp" android:background="@drawable/bg_input" android:paddingHorizontal="10dp" android:contentDescription="每次训练分钟数"/>
```

元素 Spinner：下拉单选控件。
android:id="@+id/profile_minutes"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_minutes。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="6dp"：顶部外边距。尺寸 6dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_input"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:paddingHorizontal="10dp"：左右内边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:contentDescription="每次训练分钟数"：读屏使用的文字描述。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 47 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:text="03  动作限制"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="03  动作限制"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 48 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="10dp" android:text="以下选项用于避开动作，不用于诊断或康复。如果已有伤病，请先咨询专业人员。"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="以下选项用于避开动作，不用于诊断或康复。如果已有伤病，请先咨询专业人员。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 49 行

```xml
        <CheckBox android:id="@+id/profile_knees" android:layout_width="match_parent" android:layout_height="52dp" android:text="避开膝部负荷较大的动作" android:textSize="14sp"/>
```

元素 CheckBox：可勾选开关。
android:id="@+id/profile_knees"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_knees。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="避开膝部负荷较大的动作"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 50 行

```xml
        <CheckBox android:id="@+id/profile_back" android:layout_width="match_parent" android:layout_height="52dp" android:text="避开腰背负荷较大的动作" android:textSize="14sp"/>
```

元素 CheckBox：可勾选开关。
android:id="@+id/profile_back"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_back。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="避开腰背负荷较大的动作"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 51 行

```xml
        <CheckBox android:id="@+id/profile_low_impact" android:layout_width="match_parent" android:layout_height="52dp" android:text="不安排跳跃，偏好低冲击训练" android:textSize="14sp"/>
```

元素 CheckBox：可勾选开关。
android:id="@+id/profile_low_impact"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_low_impact。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="不安排跳跃，偏好低冲击训练"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 52 行

```xml
        <CheckBox android:id="@+id/profile_professional" android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="56dp" android:text="处于孕产期，或因疾病 / 伤病被建议限制运动" android:textSize="14sp"/>
```

元素 CheckBox：可勾选开关。
android:id="@+id/profile_professional"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_professional。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:minHeight="56dp"：最小高度，防止内容或触控区域过小。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="处于孕产期，或因疾病 / 伤病被建议限制运动"：显示文字；@string 引用文字资源，\n 表示换行。
android:textSize="14sp"：字号，sp 会随系统字体大小变化。字号 14sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 53 行

```xml
        <TextView android:id="@+id/profile_error" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:textColor="#A34830" android:accessibilityLiveRegion="polite"/>
```

元素 TextView：显示文字。
android:id="@+id/profile_error"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_error。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:textColor="#A34830"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:accessibilityLiveRegion="polite"：polite 表示内容更新时等读屏当前播报完成后提示。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 54 行

```xml
        <Button android:id="@+id/profile_save" android:layout_width="match_parent" android:layout_height="54dp" android:layout_marginTop="16dp" android:text="保存档案，开始改变 ↗"/>
```

元素 Button：可点击按钮。
android:id="@+id/profile_save"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_save。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="54dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 54dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="保存档案，开始改变 ↗"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 55 行

```xml
        <Button android:id="@+id/profile_undo" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="10dp" android:background="@drawable/bg_chip" android:text="撤销上次档案修改"/>
```

元素 Button：可点击按钮。
android:id="@+id/profile_undo"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_undo。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="撤销上次档案修改"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 56 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="32dp" android:text="AI 教练服务"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="32dp"：顶部外边距。尺寸 32dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="AI 教练服务"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 57 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="10dp" android:labelFor="@id/profile_endpoint" android:text="服务地址（模拟器默认已填好，真机改为电脑局域网地址）"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:labelFor="@id/profile_endpoint"：声明这段文字是哪个输入控件的标签，帮助读屏理解。引用控件 ID profile_endpoint。
android:text="服务地址（模拟器默认已填好，真机改为电脑局域网地址）"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 58 行

```xml
        <EditText android:id="@+id/profile_endpoint" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="8dp" android:hint="http://10.0.2.2:8080" android:inputType="textUri" android:autofillHints=""/>
```

元素 EditText：接受用户输入。
android:id="@+id/profile_endpoint"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_endpoint。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:hint="http://10.0.2.2:8080"：输入为空时的占位提示，不是实际输入值。
android:inputType="textUri"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:autofillHints=""：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 59 行

```xml
        <EditText android:id="@+id/profile_token" style="@style/Input" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="10dp" android:hint="服务访问令牌（非模型 API Key）" android:inputType="textPassword" android:autofillHints=""/>
```

元素 EditText：接受用户输入。
android:id="@+id/profile_token"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_token。
style="@style/Input"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Input，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:hint="服务访问令牌（非模型 API Key）"：输入为空时的占位提示，不是实际输入值。
android:inputType="textPassword"：输入语义及键盘类型，例如 phone、number、numberDecimal、textPassword；不替代业务校验。
android:autofillHints=""：向系统声明自动填充语义；smsOTPCode 不代表本应用发送或读取了真实短信。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 60 行

```xml
        <Button android:id="@+id/profile_connect" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="12dp" android:background="@drawable/bg_chip" android:text="保存连接并检测服务"/>
```

元素 Button：可点击按钮。
android:id="@+id/profile_connect"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_connect。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="保存连接并检测服务"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 61 行

```xml
        <TextView android:id="@+id/profile_connection_status" style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="10dp" android:accessibilityLiveRegion="polite"/>
```

元素 TextView：显示文字。
android:id="@+id/profile_connection_status"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_connection_status。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:accessibilityLiveRegion="polite"：polite 表示内容更新时等读屏当前播报完成后提示。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 62 行

```xml
        <Button android:id="@+id/profile_delete" android:layout_width="match_parent" android:layout_height="52dp" android:layout_marginTop="24dp" android:background="@drawable/bg_chip" android:text="清除本机所有个人数据" android:textColor="#A34830"/>
```

元素 Button：可点击按钮。
android:id="@+id/profile_delete"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID profile_delete。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="52dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="24dp"：顶部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_chip"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:text="清除本机所有个人数据"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="#A34830"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 63 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="18dp" android:gravity="center" android:text="脉动 PULSE 1.1 · 适合自己的，才是好计划\n自动计划适用范围：18–69 岁、无医疗运动限制"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="18dp"：顶部外边距。尺寸 18dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:gravity="center"：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向。
android:text="脉动 PULSE 1.1 · 适合自己的，才是好计划\n自动计划适用范围：18–69 岁、无医疗运动限制"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 64 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 65 行

```xml
</ScrollView>
```

关闭 ScrollView 元素，结束它的嵌套作用域。
