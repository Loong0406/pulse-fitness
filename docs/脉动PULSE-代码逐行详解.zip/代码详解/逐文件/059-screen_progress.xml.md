# app/src/main/res/layout/screen_progress.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`ff98b3116263381ce5aedc73c446f6a53473ca20e578aac61bbbaddc1c2c87cd`。行号仅对应此快照；修改源码后应重新核对。

共 16 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent">
```

元素 ScrollView：纵向滚动容器，只能有一个直接子视图。
xmlns:android="http://schemas.android.com/apk/res/android"：声明 android 前缀的命名空间，不会联网下载该 URL。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="match_parent"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。填满父布局分配的可用空间。

## 第 2 行

```xml
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:padding="24dp" android:orientation="vertical">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。

## 第 3 行

```xml
        <TextView style="@style/Label" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="SMALL STEPS, REAL PROGRESS"/>
```

元素 TextView：显示文字。
style="@style/Label"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Label，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="SMALL STEPS, REAL PROGRESS"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 4 行

```xml
        <TextView style="@style/Title" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:text="每一次，都算数。"/>
```

元素 TextView：显示文字。
style="@style/Title"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Title，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="12dp"：顶部外边距。尺寸 12dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="每一次，都算数。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 5 行

```xml
        <TextView style="@style/Caption" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="记录真实完成的训练，见证自己的节奏。"/>
```

元素 TextView：显示文字。
style="@style/Caption"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Caption，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="8dp"：顶部外边距。尺寸 8dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="记录真实完成的训练，见证自己的节奏。"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 6 行

```xml
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="24dp" android:background="@drawable/bg_dark" android:orientation="vertical" android:padding="24dp">
```

元素 LinearLayout：按方向排列子视图的容器。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="24dp"：顶部外边距。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_dark"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_dark，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
android:padding="24dp"：四边内边距，位于控件边界里面。尺寸 24dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。

## 第 7 行

```xml
            <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:text="累计完成" android:textColor="#BACAB9" android:textSize="13sp"/>
```

元素 TextView：显示文字。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:text="累计完成"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="#BACAB9"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 8 行

```xml
            <TextView android:id="@+id/progress_total" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="10dp" android:text="0 次训练" android:textColor="@color/lime" android:textSize="36sp"/>
```

元素 TextView：显示文字。
android:id="@+id/progress_total"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID progress_total。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="0 次训练"：显示文字；@string 引用文字资源，\n 表示换行。
android:textColor="@color/lime"：文字颜色，可以引用状态颜色列表。引用资源 @color/lime，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:textSize="36sp"：字号，sp 会随系统字体大小变化。字号 36sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
            <TextView android:id="@+id/progress_meta" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="10dp" android:textColor="#BACAB9" android:textSize="13sp"/>
```

元素 TextView：显示文字。
android:id="@+id/progress_meta"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID progress_meta。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="10dp"：顶部外边距。尺寸 10dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:textColor="#BACAB9"：文字颜色，可以引用状态颜色列表。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
android:textSize="13sp"：字号，sp 会随系统字体大小变化。字号 13sp，会响应用户系统字体缩放。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 10 行

```xml
        </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 11 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:text="本周投入 / 分钟"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="本周投入 / 分钟"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 12 行

```xml
        <com.pulse.fitness.ui.widget.WeeklyChartView android:id="@+id/progress_chart" android:layout_width="match_parent" android:layout_height="190dp" android:layout_marginTop="16dp" android:background="@drawable/bg_card"/>
```

元素 com.pulse.fitness.ui.widget.WeeklyChartView：自定义原生控件 WeeklyChartView，实际绘制由同名 Java 类实现。
android:id="@+id/progress_chart"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID progress_chart。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="190dp"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。尺寸 190dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:layout_marginTop="16dp"：顶部外边距。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:background="@drawable/bg_card"：控件背景，可是颜色、drawable 或主题属性。引用资源 @drawable/bg_card，实际值见同名资源定义；night/v27 等目录可能覆盖。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 13 行

```xml
        <TextView style="@style/Section" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="28dp" android:text="训练足迹"/>
```

元素 TextView：显示文字。
style="@style/Section"：给控件应用一组命名样式，行内属性可覆盖同名样式属性。引用资源 @style/Section，实际值见同名资源定义；night/v27 等目录可能覆盖。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="28dp"：顶部外边距。尺寸 28dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:text="训练足迹"：显示文字；@string 引用文字资源，\n 表示换行。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 14 行

```xml
        <LinearLayout android:id="@+id/progress_history" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:orientation="vertical"/>
```

元素 LinearLayout：按方向排列子视图的容器。
android:id="@+id/progress_history"：控件标识；@+id 创建，@id 引用已有 ID；Java 的 R.id 使用同名项。创建 ID progress_history。
android:layout_width="match_parent"：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间。填满父布局分配的可用空间。
android:layout_height="wrap_content"：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸。以内容测量所需尺寸。
android:layout_marginTop="14dp"：顶部外边距。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
android:orientation="vertical"：LinearLayout 子元素排列方向：vertical 纵排、horizontal 横排。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 15 行

```xml
    </LinearLayout>
```

关闭 LinearLayout 元素，结束它的嵌套作用域。

## 第 16 行

```xml
</ScrollView>
```

关闭 ScrollView 元素，结束它的嵌套作用域。
