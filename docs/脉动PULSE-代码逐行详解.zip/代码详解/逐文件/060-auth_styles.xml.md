# app/src/main/res/values-night-v27/auth_styles.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。此限定目录仅在深色模式匹配时覆盖同名默认资源。v27 表示 API 27 及以上才参与资源匹配。

原文件 SHA-256：`3f98cea705f3e6284e74b6add78418583468dbbc276741b8dda98321eb429061`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<resources><style name="LoginTheme" parent="BaseLoginTheme"><item name="android:windowLightStatusBar">false</item><item name="android:windowLightNavigationBar">false</item></style></resources>
```

元素 resources：values 资源集合根节点。
元素 style：可复用的主题/控件属性集合。
name="LoginTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="BaseLoginTheme"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。
元素 item：样式属性或状态列表分支。
name="android:windowLightStatusBar"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowLightStatusBar：true 请求深色状态栏图标，false 请求浅色图标；Light 描述背景倾向；值为 false。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:windowLightNavigationBar"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowLightNavigationBar：true 请求深色导航栏图标，false 请求浅色图标；值为 false。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。
关闭 resources 元素，结束它的嵌套作用域。
