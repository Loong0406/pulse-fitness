# app/src/main/res/values-night/auth_colors.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。此限定目录仅在深色模式匹配时覆盖同名默认资源。

原文件 SHA-256：`98189eb705fcaf042c1eaf0b73520051de78d1c11708e15c2cd6f50dc75ae80c`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<resources>
```

元素 resources：values 资源集合根节点。

## 第 2 行

```xml
    <color name="auth_surface">#1B2A20</color>
```

元素 color：命名颜色资源。
name="auth_surface"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#1B2A20”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 3 行

```xml
    <color name="auth_field">#25382B</color>
```

元素 color：命名颜色资源。
name="auth_field"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#25382B”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 4 行

```xml
    <color name="auth_on_surface">#F0F4EB</color>
```

元素 color：命名颜色资源。
name="auth_on_surface"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#F0F4EB”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 5 行

```xml
    <color name="auth_secondary">#B6C5B5</color>
```

元素 color：命名颜色资源。
name="auth_secondary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#B6C5B5”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 6 行

```xml
    <color name="auth_outline">#4C6250</color>
```

元素 color：命名颜色资源。
name="auth_outline"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#4C6250”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    <color name="auth_action">#D8F875</color>
```

元素 color：命名颜色资源。
name="auth_action"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#D8F875”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 8 行

```xml
    <color name="auth_code_surface">#344932</color>
```

元素 color：命名颜色资源。
name="auth_code_surface"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#344932”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 9 行

```xml
    <color name="auth_error">#FFB4A9</color>
```

元素 color：命名颜色资源。
name="auth_error"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#FFB4A9”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 10 行

```xml
</resources>
```

关闭 resources 元素，结束它的嵌套作用域。
