# app/src/main/res/values-v27/styles.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。v27 表示 API 27 及以上才参与资源匹配。

原文件 SHA-256：`c2110338ede592a052573c7cec190ee2a1907ea056b298577bbe0c766e3791a8`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<resources><style name="AppTheme" parent="BaseAppTheme"><item name="android:windowLightNavigationBar">true</item></style></resources>
```

元素 resources：values 资源集合根节点。
元素 style：可复用的主题/控件属性集合。
name="AppTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="BaseAppTheme"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。
元素 item：样式属性或状态列表分支。
name="android:windowLightNavigationBar"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowLightNavigationBar：true 请求深色导航栏图标，false 请求浅色图标；值为 true。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。
关闭 resources 元素，结束它的嵌套作用域。
