# app/src/main/res/values/auth_colors.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`90f0e30ffbc28cdd7397b17d294d7d25202e1560c56039f0c6454442951f175d`。行号仅对应此快照；修改源码后应重新核对。

共 15 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<resources>
```

元素 resources：values 资源集合根节点。

## 第 2 行

```xml
    <color name="auth_hero">#192F21</color>
```

元素 color：命名颜色资源。
name="auth_hero"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#192F21”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 3 行

```xml
    <color name="auth_on_hero">#F7FAF1</color>
```

元素 color：命名颜色资源。
name="auth_on_hero"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#F7FAF1”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 4 行

```xml
    <color name="auth_hero_secondary">#CAD8C6</color>
```

元素 color：命名颜色资源。
name="auth_hero_secondary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#CAD8C6”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 5 行

```xml
    <color name="auth_surface">#F4F5F0</color>
```

元素 color：命名颜色资源。
name="auth_surface"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#F4F5F0”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 6 行

```xml
    <color name="auth_field">#FFFFFF</color>
```

元素 color：命名颜色资源。
name="auth_field"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#FFFFFF”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    <color name="auth_on_surface">#19271F</color>
```

元素 color：命名颜色资源。
name="auth_on_surface"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#19271F”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 8 行

```xml
    <color name="auth_secondary">#59665C</color>
```

元素 color：命名颜色资源。
name="auth_secondary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#59665C”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 9 行

```xml
    <color name="auth_outline">#D8DED2</color>
```

元素 color：命名颜色资源。
name="auth_outline"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#D8DED2”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 10 行

```xml
    <color name="auth_action">#365D3B</color>
```

元素 color：命名颜色资源。
name="auth_action"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#365D3B”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 11 行

```xml
    <color name="auth_code_surface">#EBF1DF</color>
```

元素 color：命名颜色资源。
name="auth_code_surface"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#EBF1DF”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 12 行

```xml
    <color name="auth_error">#A53629</color>
```

元素 color：命名颜色资源。
name="auth_error"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#A53629”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 13 行

```xml
    <color name="auth_primary">#D8F875</color>
```

元素 color：命名颜色资源。
name="auth_primary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#D8F875”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 14 行

```xml
    <color name="auth_on_primary">#19271F</color>
```

元素 color：命名颜色资源。
name="auth_on_primary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#19271F”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 15 行

```xml
</resources>
```

关闭 resources 元素，结束它的嵌套作用域。
