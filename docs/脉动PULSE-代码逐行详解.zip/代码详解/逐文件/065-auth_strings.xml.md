# app/src/main/res/values/auth_strings.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`9736b48d01f64979ebeff9ae7aa5cc42724bee9451050116821823be38806259`。行号仅对应此快照；修改源码后应重新核对。

共 38 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<resources>
```

元素 resources：values 资源集合根节点。

## 第 2 行

```xml
    <string name="auth_brand">PULSE / 脉动</string>
```

元素 string：可翻译文字资源。
name="auth_brand"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“PULSE / 脉动”。
关闭 string 元素，结束它的嵌套作用域。

## 第 3 行

```xml
    <string name="auth_headline">为自己，\n认真开练。</string>
```

元素 string：可翻译文字资源。
name="auth_headline"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“为自己，\n认真开练。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 4 行

```xml
    <string name="auth_tagline">每一次开始，都值得认真对待。</string>
```

元素 string：可翻译文字资源。
name="auth_tagline"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“每一次开始，都值得认真对待。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 5 行

```xml
    <string name="auth_title">手机号登录</string>
```

元素 string：可翻译文字资源。
name="auth_title"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“手机号登录”。
关闭 string 元素，结束它的嵌套作用域。

## 第 6 行

```xml
    <string name="auth_subtitle">把每一次认真，都记下来。</string>
```

元素 string：可翻译文字资源。
name="auth_subtitle"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“把每一次认真，都记下来。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    <string name="auth_demo_notice">本机演示 · 验证码将在本机展示，不发送短信</string>
```

元素 string：可翻译文字资源。
name="auth_demo_notice"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“本机演示 · 验证码将在本机展示，不发送短信”。
关闭 string 元素，结束它的嵌套作用域。

## 第 8 行

```xml
    <string name="auth_phone_label">手机号码</string>
```

元素 string：可翻译文字资源。
name="auth_phone_label"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“手机号码”。
关闭 string 元素，结束它的嵌套作用域。

## 第 9 行

```xml
    <string name="auth_phone_hint">请输入手机号</string>
```

元素 string：可翻译文字资源。
name="auth_phone_hint"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“请输入手机号”。
关闭 string 元素，结束它的嵌套作用域。

## 第 10 行

```xml
    <string name="auth_country_code">+86</string>
```

元素 string：可翻译文字资源。
name="auth_country_code"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“+86”。
关闭 string 元素，结束它的嵌套作用域。

## 第 11 行

```xml
    <string name="auth_code_label">验证码</string>
```

元素 string：可翻译文字资源。
name="auth_code_label"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“验证码”。
关闭 string 元素，结束它的嵌套作用域。

## 第 12 行

```xml
    <string name="auth_code_hint">请输入 6 位验证码</string>
```

元素 string：可翻译文字资源。
name="auth_code_hint"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“请输入 6 位验证码”。
关闭 string 元素，结束它的嵌套作用域。

## 第 13 行

```xml
    <string name="auth_get_code">获取验证码</string>
```

元素 string：可翻译文字资源。
name="auth_get_code"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“获取验证码”。
关闭 string 元素，结束它的嵌套作用域。

## 第 14 行

```xml
    <string name="auth_resend_countdown">%1$d 秒后重发</string>
```

元素 string：可翻译文字资源。
name="auth_resend_countdown"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“%1$d 秒后重发”。
格式占位符 %1$d 由 Java getString(id,参数) 在运行时替换；s 是文本，d 是整数。
关闭 string 元素，结束它的嵌套作用域。

## 第 15 行

```xml
    <string name="auth_agreement">我已阅读并同意</string>
```

元素 string：可翻译文字资源。
name="auth_agreement"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“我已阅读并同意”。
关闭 string 元素，结束它的嵌套作用域。

## 第 16 行

```xml
    <string name="auth_terms">用户协议</string>
```

元素 string：可翻译文字资源。
name="auth_terms"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“用户协议”。
关闭 string 元素，结束它的嵌套作用域。

## 第 17 行

```xml
    <string name="auth_privacy">隐私政策</string>
```

元素 string：可翻译文字资源。
name="auth_privacy"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“隐私政策”。
关闭 string 元素，结束它的嵌套作用域。

## 第 18 行

```xml
    <string name="auth_login">登录 / 注册</string>
```

元素 string：可翻译文字资源。
name="auth_login"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“登录 / 注册”。
关闭 string 元素，结束它的嵌套作用域。

## 第 19 行

```xml
    <string name="auth_guest">游客体验，先去开练</string>
```

元素 string：可翻译文字资源。
name="auth_guest"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“游客体验，先去开练”。
关闭 string 元素，结束它的嵌套作用域。

## 第 20 行

```xml
    <string name="auth_local_data">当前为本机体验，训练记录仅保存在此设备。</string>
```

元素 string：可翻译文字资源。
name="auth_local_data"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“当前为本机体验，训练记录仅保存在此设备。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 21 行

```xml
    <string name="auth_demo_title">本机演示验证码</string>
```

元素 string：可翻译文字资源。
name="auth_demo_title"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“本机演示验证码”。
关闭 string 元素，结束它的嵌套作用域。

## 第 22 行

```xml
    <string name="auth_demo_code_explanation">用于 %1$s 的本机体验，5 分钟内有效。不会发送短信，也不会创建云端账号。</string>
```

元素 string：可翻译文字资源。
name="auth_demo_code_explanation"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“用于 %1$s 的本机体验，5 分钟内有效。不会发送短信，也不会创建云端账号。”。
格式占位符 %1$s 由 Java getString(id,参数) 在运行时替换；s 是文本，d 是整数。
关闭 string 元素，结束它的嵌套作用域。

## 第 23 行

```xml
    <string name="auth_fill_code">填入验证码</string>
```

元素 string：可翻译文字资源。
name="auth_fill_code"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“填入验证码”。
关闭 string 元素，结束它的嵌套作用域。

## 第 24 行

```xml
    <string name="auth_manual_code">手动输入</string>
```

元素 string：可翻译文字资源。
name="auth_manual_code"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“手动输入”。
关闭 string 元素，结束它的嵌套作用域。

## 第 25 行

```xml
    <string name="auth_back">返回</string>
```

元素 string：可翻译文字资源。
name="auth_back"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“返回”。
关闭 string 元素，结束它的嵌套作用域。

## 第 26 行

```xml
    <string name="auth_terms_title">用户协议 · 体验版</string>
```

元素 string：可翻译文字资源。
name="auth_terms_title"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“用户协议 · 体验版”。
关闭 string 元素，结束它的嵌套作用域。

## 第 27 行

```xml
    <string name="auth_privacy_title">隐私政策 · 体验版</string>
```

元素 string：可翻译文字资源。
name="auth_privacy_title"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“隐私政策 · 体验版”。
关闭 string 元素，结束它的嵌套作用域。

## 第 28 行

```xml
    <string name="auth_read_error">暂时无法打开说明，请返回后重试。</string>
```

元素 string：可翻译文字资源。
name="auth_read_error"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“暂时无法打开说明，请返回后重试。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 29 行

```xml
    <string name="auth_account_guest">游客体验</string>
```

元素 string：可翻译文字资源。
name="auth_account_guest"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“游客体验”。
关闭 string 元素，结束它的嵌套作用域。

## 第 30 行

```xml
    <string name="auth_account_demo">本机演示账号</string>
```

元素 string：可翻译文字资源。
name="auth_account_demo"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“本机演示账号”。
关闭 string 元素，结束它的嵌套作用域。

## 第 31 行

```xml
    <string name="auth_account_guest_note">先练起来，随时可以登录。</string>
```

元素 string：可翻译文字资源。
name="auth_account_guest_note"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“先练起来，随时可以登录。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 32 行

```xml
    <string name="auth_account_phone_note">%1$s · 数据保存在此设备</string>
```

元素 string：可翻译文字资源。
name="auth_account_phone_note"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“%1$s · 数据保存在此设备”。
格式占位符 %1$s 由 Java getString(id,参数) 在运行时替换；s 是文本，d 是整数。
关闭 string 元素，结束它的嵌套作用域。

## 第 33 行

```xml
    <string name="auth_account_sign_in">手机号登录</string>
```

元素 string：可翻译文字资源。
name="auth_account_sign_in"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“手机号登录”。
关闭 string 元素，结束它的嵌套作用域。

## 第 34 行

```xml
    <string name="auth_account_sign_out">退出登录</string>
```

元素 string：可翻译文字资源。
name="auth_account_sign_out"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“退出登录”。
关闭 string 元素，结束它的嵌套作用域。

## 第 35 行

```xml
    <string name="auth_sign_out_title">退出当前体验账号？</string>
```

元素 string：可翻译文字资源。
name="auth_sign_out_title"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“退出当前体验账号？”。
关闭 string 元素，结束它的嵌套作用域。

## 第 36 行

```xml
    <string name="auth_sign_out_message">个人档案、训练计划和记录会保留在本机。</string>
```

元素 string：可翻译文字资源。
name="auth_sign_out_message"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“个人档案、训练计划和记录会保留在本机。”。
关闭 string 元素，结束它的嵌套作用域。

## 第 37 行

```xml
    <string name="auth_cancel">取消</string>
```

元素 string：可翻译文字资源。
name="auth_cancel"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“取消”。
关闭 string 元素，结束它的嵌套作用域。

## 第 38 行

```xml
</resources>
```

关闭 resources 元素，结束它的嵌套作用域。
