# app/src/main/res/values/auth_styles.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`e752679d26b27201063a734258582e0bcd9bad39a5ef40998ddaed12c36949f1`。行号仅对应此快照；修改源码后应重新核对。

共 19 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<resources>
```

元素 resources：values 资源集合根节点。

## 第 2 行

```xml
    <style name="BaseLoginTheme" parent="AppTheme">
```

元素 style：可复用的主题/控件属性集合。
name="BaseLoginTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="AppTheme"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。

## 第 3 行

```xml
        <item name="android:windowBackground">@color/auth_surface</item>
```

元素 item：样式属性或状态列表分支。
name="android:windowBackground"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowBackground：窗口底色；值为 @color/auth_surface。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 4 行

```xml
        <item name="android:statusBarColor">@color/auth_surface</item>
```

元素 item：样式属性或状态列表分支。
name="android:statusBarColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 statusBarColor：状态栏底色；值为 @color/auth_surface。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 5 行

```xml
        <item name="android:navigationBarColor">@color/auth_surface</item>
```

元素 item：样式属性或状态列表分支。
name="android:navigationBarColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 navigationBarColor：系统导航栏底色；值为 @color/auth_surface。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 6 行

```xml
        <item name="android:colorAccent">@color/auth_action</item>
```

元素 item：样式属性或状态列表分支。
name="android:colorAccent"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 colorAccent：平台组件强调色；值为 @color/auth_action。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    </style>
```

关闭 style 元素，结束它的嵌套作用域。

## 第 8 行

```xml
    <style name="LoginTheme" parent="BaseLoginTheme" />
```

元素 style：可复用的主题/控件属性集合。
name="LoginTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="BaseLoginTheme"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 9 行

```xml
    <style name="AuthDialogTheme" parent="android:style/Theme.Material.Light.Dialog.Alert">
```

元素 style：可复用的主题/控件属性集合。
name="AuthDialogTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="android:style/Theme.Material.Light.Dialog.Alert"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。

## 第 10 行

```xml
        <item name="android:colorAccent">@color/auth_action</item>
```

元素 item：样式属性或状态列表分支。
name="android:colorAccent"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 colorAccent：平台组件强调色；值为 @color/auth_action。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 11 行

```xml
        <item name="android:colorBackground">@color/auth_surface</item>
```

元素 item：样式属性或状态列表分支。
name="android:colorBackground"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 colorBackground：平台主题背景色；值为 @color/auth_surface。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 12 行

```xml
        <item name="android:colorBackgroundFloating">@color/auth_surface</item>
```

元素 item：样式属性或状态列表分支。
name="android:colorBackgroundFloating"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 colorBackgroundFloating：浮动窗口背景色；值为 @color/auth_surface。引用资源 @color/auth_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 13 行

```xml
        <item name="android:textColorPrimary">@color/auth_on_surface</item>
```

元素 item：样式属性或状态列表分支。
name="android:textColorPrimary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColorPrimary：主题主要文字颜色；值为 @color/auth_on_surface。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 14 行

```xml
        <item name="android:textColorSecondary">@color/auth_secondary</item>
```

元素 item：样式属性或状态列表分支。
name="android:textColorSecondary"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColorSecondary：主题次要文字颜色；值为 @color/auth_secondary。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 15 行

```xml
    </style>
```

关闭 style 元素，结束它的嵌套作用域。

## 第 16 行

```xml
    <style name="AuthLabel" parent="Body"><item name="android:textColor">@color/auth_on_surface</item><item name="android:fontFamily">sans-serif-medium</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="AuthLabel"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="Body"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/auth_on_surface。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:fontFamily"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 fontFamily：字体族；sans-serif-medium 使用系统中等字重无衬线字体；值为 sans-serif-medium。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 17 行

```xml
    <style name="AuthInput"><item name="android:textSize">16sp</item><item name="android:textColor">@color/auth_on_surface</item><item name="android:textColorHint">@color/auth_secondary</item><item name="android:background">@null</item><item name="android:paddingHorizontal">16dp</item><item name="android:singleLine">true</item><item name="android:minHeight">56dp</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="AuthInput"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 16sp。字号 16sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/auth_on_surface。引用资源 @color/auth_on_surface，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColorHint"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColorHint：输入提示文字颜色；值为 @color/auth_secondary。引用资源 @color/auth_secondary，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:background"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 background：控件背景，可是颜色、drawable 或主题属性；值为 @null。显式置空，关闭或去除该项默认值。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:paddingHorizontal"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 paddingHorizontal：左右内边距；值为 16dp。尺寸 16dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:singleLine"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 singleLine：输入/文字保持单行；值为 true。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:minHeight"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 minHeight：最小高度，防止内容或触控区域过小；值为 56dp。尺寸 56dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 18 行

```xml
    <style name="AuthLink"><item name="android:textSize">13sp</item><item name="android:textColor">@color/auth_action</item><item name="android:minHeight">48dp</item><item name="android:minWidth">48dp</item><item name="android:gravity">center</item><item name="android:paddingHorizontal">4dp</item><item name="android:background">?android:attr/selectableItemBackground</item><item name="android:clickable">true</item><item name="android:focusable">true</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="AuthLink"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 13sp。字号 13sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/auth_action。引用资源 @color/auth_action，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:minHeight"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 minHeight：最小高度，防止内容或触控区域过小；值为 48dp。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:minWidth"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 minWidth：最小宽度；值为 48dp。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:gravity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 gravity：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向；值为 center。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:paddingHorizontal"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 paddingHorizontal：左右内边距；值为 4dp。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:background"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 background：控件背景，可是颜色、drawable 或主题属性；值为 ?android:attr/selectableItemBackground。从当前主题解析属性 ?android:attr/selectableItemBackground。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:clickable"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 clickable：是否可点击；实际业务动作仍由 Java 监听器绑定；值为 true。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:focusable"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 focusable：是否可获键盘/无障碍焦点；值为 true。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 19 行

```xml
</resources>
```

关闭 resources 元素，结束它的嵌套作用域。
