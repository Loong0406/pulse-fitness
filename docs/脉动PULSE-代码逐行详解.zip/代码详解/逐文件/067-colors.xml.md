# app/src/main/res/values/colors.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`2bac94b03697538bc4a3aac1b1dafb7ec9143b76f28c6772b996611acdafd21a`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<?xml version="1.0" encoding="utf-8"?>
```

声明 XML 版本及 UTF-8 文本编码。

## 第 2 行

```xml
<resources>
```

元素 resources：values 资源集合根节点。

## 第 3 行

```xml
    <color name="canvas">#F4F5F0</color>
```

元素 color：命名颜色资源。
name="canvas"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#F4F5F0”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 4 行

```xml
    <color name="ink">#19271F</color>
```

元素 color：命名颜色资源。
name="ink"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#19271F”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 5 行

```xml
    <color name="muted">#748076</color>
```

元素 color：命名颜色资源。
name="muted"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#748076”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 6 行

```xml
    <color name="lime">#D8F875</color>
```

元素 color：命名颜色资源。
name="lime"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#D8F875”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 7 行

```xml
    <color name="line">#E3E7DC</color>
```

元素 color：命名颜色资源。
name="line"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#E3E7DC”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 8 行

```xml
    <color name="white">#FFFFFF</color>
```

元素 color：命名颜色资源。
name="white"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#FFFFFF”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 9 行

```xml
    <color name="green">#48734D</color>
```

元素 color：命名颜色资源。
name="green"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
资源内容为“#48734D”。十六进制颜色；#RRGGBB 为红绿蓝，#AARRGGBB 首两位为透明度。
关闭 color 元素，结束它的嵌套作用域。

## 第 10 行

```xml
</resources>
```

关闭 resources 元素，结束它的嵌套作用域。
