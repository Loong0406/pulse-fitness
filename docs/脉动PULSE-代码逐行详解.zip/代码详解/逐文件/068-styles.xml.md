# app/src/main/res/values/styles.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`3c85f633f6ac5d1f1ded044f808c898760e704d3ee99a01e05ffc1a12098ec15`。行号仅对应此快照；修改源码后应重新核对。

共 24 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<?xml version="1.0" encoding="utf-8"?>
```

声明 XML 版本及 UTF-8 文本编码。

## 第 2 行

```xml
<resources>
```

元素 resources：values 资源集合根节点。

## 第 3 行

```xml
    <style name="BaseAppTheme" parent="android:style/Theme.Material.Light.NoActionBar">
```

元素 style：可复用的主题/控件属性集合。
name="BaseAppTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="android:style/Theme.Material.Light.NoActionBar"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。

## 第 4 行

```xml
        <item name="android:fontFamily">sans</item><item name="android:colorAccent">@color/green</item>
```

元素 item：样式属性或状态列表分支。
name="android:fontFamily"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 fontFamily：字体族；sans-serif-medium 使用系统中等字重无衬线字体；值为 sans。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:colorAccent"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 colorAccent：平台组件强调色；值为 @color/green。引用资源 @color/green，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 5 行

```xml
        <item name="android:windowLightStatusBar">true</item>
```

元素 item：样式属性或状态列表分支。
name="android:windowLightStatusBar"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowLightStatusBar：true 请求深色状态栏图标，false 请求浅色图标；Light 描述背景倾向；值为 true。
关闭 item 元素，结束它的嵌套作用域。

## 第 6 行

```xml
        <item name="android:windowBackground">@color/canvas</item><item name="android:statusBarColor">@color/canvas</item>
```

元素 item：样式属性或状态列表分支。
name="android:windowBackground"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowBackground：窗口底色；值为 @color/canvas。引用资源 @color/canvas，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:statusBarColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 statusBarColor：状态栏底色；值为 @color/canvas。引用资源 @color/canvas，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 7 行

```xml
        <item name="android:navigationBarColor">@color/white</item><item name="android:buttonStyle">@style/PulseButton</item>
```

元素 item：样式属性或状态列表分支。
name="android:navigationBarColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 navigationBarColor：系统导航栏底色；值为 @color/white。引用资源 @color/white，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:buttonStyle"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 buttonStyle：应用默认按钮样式；值为 @style/PulseButton。引用资源 @style/PulseButton，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 8 行

```xml
        <item name="android:windowActionModeOverlay">true</item>
```

元素 item：样式属性或状态列表分支。
name="android:windowActionModeOverlay"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 windowActionModeOverlay：上下文操作栏覆盖窗口内容；值为 true。
关闭 item 元素，结束它的嵌套作用域。

## 第 9 行

```xml
    </style>
```

关闭 style 元素，结束它的嵌套作用域。

## 第 10 行

```xml
    <style name="AppTheme" parent="BaseAppTheme" />
```

元素 style：可复用的主题/控件属性集合。
name="AppTheme"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="BaseAppTheme"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。
该元素以 /> 自闭合，没有嵌套子节点。

## 第 11 行

```xml
    <style name="PulseButton" parent="android:style/Widget.Material.Button">
```

元素 style：可复用的主题/控件属性集合。
name="PulseButton"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
parent="android:style/Widget.Material.Button"：样式继承的父样式，未在当前样式覆盖的属性沿用父样式。

## 第 12 行

```xml
        <item name="android:background">@drawable/bg_button</item><item name="android:textColor">@color/ink</item>
```

元素 item：样式属性或状态列表分支。
name="android:background"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 background：控件背景，可是颜色、drawable 或主题属性；值为 @drawable/bg_button。引用资源 @drawable/bg_button，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/ink。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。

## 第 13 行

```xml
        <item name="android:textAllCaps">false</item><item name="android:textSize">15sp</item><item name="android:fontFamily">sans-serif-medium</item>
```

元素 item：样式属性或状态列表分支。
name="android:textAllCaps"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textAllCaps：是否把可转换文字自动变大写；值为 false。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 15sp。字号 15sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:fontFamily"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 fontFamily：字体族；sans-serif-medium 使用系统中等字重无衬线字体；值为 sans-serif-medium。
关闭 item 元素，结束它的嵌套作用域。

## 第 14 行

```xml
        <item name="android:minHeight">52dp</item><item name="android:paddingHorizontal">20dp</item><item name="android:stateListAnimator">@null</item>
```

元素 item：样式属性或状态列表分支。
name="android:minHeight"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 minHeight：最小高度，防止内容或触控区域过小；值为 52dp。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:paddingHorizontal"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 paddingHorizontal：左右内边距；值为 20dp。尺寸 20dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:stateListAnimator"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 stateListAnimator：视图状态动画，@null 关闭默认状态动画；值为 @null。显式置空，关闭或去除该项默认值。
关闭 item 元素，结束它的嵌套作用域。

## 第 15 行

```xml
    </style>
```

关闭 style 元素，结束它的嵌套作用域。

## 第 16 行

```xml
    <style name="Title"><item name="android:textSize">28sp</item><item name="android:textColor">@color/ink</item><item name="android:fontFamily">sans-serif-medium</item><item name="android:lineSpacingExtra">4dp</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Title"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 28sp。字号 28sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/ink。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:fontFamily"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 fontFamily：字体族；sans-serif-medium 使用系统中等字重无衬线字体；值为 sans-serif-medium。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:lineSpacingExtra"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 lineSpacingExtra：每行额外行距；值为 4dp。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 17 行

```xml
    <style name="Section"><item name="android:textSize">19sp</item><item name="android:textColor">@color/ink</item><item name="android:fontFamily">sans-serif-medium</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Section"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 19sp。字号 19sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/ink。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:fontFamily"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 fontFamily：字体族；sans-serif-medium 使用系统中等字重无衬线字体；值为 sans-serif-medium。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 18 行

```xml
    <style name="Body"><item name="android:textSize">14sp</item><item name="android:textColor">@color/ink</item><item name="android:lineSpacingExtra">5dp</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Body"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 14sp。字号 14sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/ink。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:lineSpacingExtra"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 lineSpacingExtra：每行额外行距；值为 5dp。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 19 行

```xml
    <style name="Caption"><item name="android:textSize">12sp</item><item name="android:textColor">@color/muted</item><item name="android:lineSpacingExtra">4dp</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Caption"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 12sp。字号 12sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/muted。引用资源 @color/muted，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:lineSpacingExtra"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 lineSpacingExtra：每行额外行距；值为 4dp。尺寸 4dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 20 行

```xml
    <style name="Label"><item name="android:textSize">11sp</item><item name="android:textColor">@color/green</item><item name="android:letterSpacing">0.14</item><item name="android:fontFamily">sans-serif-medium</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Label"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 11sp。字号 11sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/green。引用资源 @color/green，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:letterSpacing"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 letterSpacing：字母间距，数值以 em 为相对单位；值为 0.14。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:fontFamily"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 fontFamily：字体族；sans-serif-medium 使用系统中等字重无衬线字体；值为 sans-serif-medium。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 21 行

```xml
    <style name="Input"><item name="android:background">@drawable/bg_input</item><item name="android:padding">14dp</item><item name="android:minHeight">52dp</item><item name="android:textColor">@color/ink</item><item name="android:textSize">15sp</item><item name="android:singleLine">true</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Input"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:background"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 background：控件背景，可是颜色、drawable 或主题属性；值为 @drawable/bg_input。引用资源 @drawable/bg_input，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:padding"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 padding：四边内边距，位于控件边界里面；值为 14dp。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:minHeight"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 minHeight：最小高度，防止内容或触控区域过小；值为 52dp。尺寸 52dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/ink。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 15sp。字号 15sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:singleLine"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 singleLine：输入/文字保持单行；值为 true。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 22 行

```xml
    <style name="Nav"><item name="android:layout_width">0dp</item><item name="android:layout_height">64dp</item><item name="android:layout_weight">1</item><item name="android:gravity">center</item><item name="android:textSize">11sp</item><item name="android:textColor">@color/muted</item><item name="android:drawablePadding">5dp</item><item name="android:background">?android:attr/selectableItemBackground</item><item name="android:clickable">true</item><item name="android:focusable">true</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Nav"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:layout_width"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 layout_width：布局宽度；match_parent 填父容器可用宽，wrap_content 随内容，0dp 通常配合权重分剩余空间；值为 0dp。尺寸 0dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:layout_height"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 layout_height：布局高度；match_parent 填可用高，wrap_content 随内容，dp 为逻辑尺寸；值为 64dp。尺寸 64dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:layout_weight"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 layout_weight：在 LinearLayout 中分配剩余空间的比例；常与主轴 0dp 配合；值为 1。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:gravity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 gravity：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向；值为 center。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 11sp。字号 11sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/muted。引用资源 @color/muted，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:drawablePadding"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 drawablePadding：复合图标与文字之间的间隔；值为 5dp。尺寸 5dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:background"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 background：控件背景，可是颜色、drawable 或主题属性；值为 ?android:attr/selectableItemBackground。从当前主题解析属性 ?android:attr/selectableItemBackground。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:clickable"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 clickable：是否可点击；实际业务动作仍由 Java 监听器绑定；值为 true。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:focusable"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 focusable：是否可获键盘/无障碍焦点；值为 true。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 23 行

```xml
    <style name="Chip"><item name="android:background">@drawable/bg_chip</item><item name="android:paddingHorizontal">14dp</item><item name="android:paddingVertical">9dp</item><item name="android:textSize">12sp</item><item name="android:textColor">@color/ink</item><item name="android:gravity">center</item><item name="android:minHeight">48dp</item><item name="android:clickable">true</item><item name="android:focusable">true</item></style>
```

元素 style：可复用的主题/控件属性集合。
name="Chip"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
元素 item：样式属性或状态列表分支。
name="android:background"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 background：控件背景，可是颜色、drawable 或主题属性；值为 @drawable/bg_chip。引用资源 @drawable/bg_chip，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:paddingHorizontal"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 paddingHorizontal：左右内边距；值为 14dp。尺寸 14dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:paddingVertical"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 paddingVertical：上下内边距；值为 9dp。尺寸 9dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textSize"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textSize：字号，sp 会随系统字体大小变化；值为 12sp。字号 12sp，会响应用户系统字体缩放。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:textColor"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 textColor：文字颜色，可以引用状态颜色列表；值为 @color/ink。引用资源 @color/ink，实际值见同名资源定义；night/v27 等目录可能覆盖。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:gravity"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 gravity：当前容器内容/文字的对齐方式；center 居中，start 从语言起始边对齐，| 合并方向；值为 center。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:minHeight"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 minHeight：最小高度，防止内容或触控区域过小；值为 48dp。尺寸 48dp，按屏幕密度转换像素；0dp 在权重布局中常表示由权重分配。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:clickable"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 clickable：是否可点击；实际业务动作仍由 Java 监听器绑定；值为 true。
关闭 item 元素，结束它的嵌套作用域。
元素 item：样式属性或状态列表分支。
name="android:focusable"：在 Manifest 中是组件/权限/动作全名，在 values 中是可被 R 引用的资源名。
该样式项 focusable：是否可获键盘/无障碍焦点；值为 true。
关闭 item 元素，结束它的嵌套作用域。
关闭 style 元素，结束它的嵌套作用域。

## 第 24 行

```xml
</resources>
```

关闭 resources 元素，结束它的嵌套作用域。
