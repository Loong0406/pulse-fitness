# app/src/main/res/xml/data_extraction_rules.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`f50148eab9e607a1d41b41ab1a6832353af0cb98c5fb4e2ca6364942cfea5969`。行号仅对应此快照；修改源码后应重新核对。

共 4 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<data-extraction-rules>
```

元素 data-extraction-rules：系统数据提取规则。

## 第 2 行

```xml
    <cloud-backup><exclude domain="root" path="."/><exclude domain="file" path="."/><exclude domain="database" path="."/><exclude domain="sharedpref" path="."/><exclude domain="external" path="."/></cloud-backup>
```

元素 cloud-backup：云备份范围。
元素 exclude：从指定域排除指定路径。
domain="root"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="file"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="database"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="sharedpref"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="external"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 cloud-backup 元素，结束它的嵌套作用域。

## 第 3 行

```xml
    <device-transfer><exclude domain="root" path="."/><exclude domain="file" path="."/><exclude domain="database" path="."/><exclude domain="sharedpref" path="."/><exclude domain="external" path="."/></device-transfer>
```

元素 device-transfer：换设备迁移范围。
元素 exclude：从指定域排除指定路径。
domain="root"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="file"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="database"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="sharedpref"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
元素 exclude：从指定域排除指定路径。
domain="external"：备份数据域，如 sharedpref 为偏好设置，database 为数据库。
path="."：备份排除路径，. 表示该域所有路径。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 device-transfer 元素，结束它的嵌套作用域。

## 第 4 行

```xml
</data-extraction-rules>
```

关闭 data-extraction-rules 元素，结束它的嵌套作用域。
