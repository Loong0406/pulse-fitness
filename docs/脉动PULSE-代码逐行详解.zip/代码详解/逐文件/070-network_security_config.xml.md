# app/src/main/res/xml/network_security_config.xml

Android 界面/主题/图形资源；按每行元素及属性展开解释。

原文件 SHA-256：`c18bc32d74fa29482a66e1c58c7d25a897c6e7ccabafafe5715e6cff959921e4`。行号仅对应此快照；修改源码后应重新核对。

共 2 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```xml
<?xml version="1.0" encoding="utf-8"?>
```

声明 XML 版本及 UTF-8 文本编码。

## 第 2 行

```xml
<network-security-config><base-config cleartextTrafficPermitted="false" /></network-security-config>
```

元素 network-security-config：应用网络安全配置。
元素 base-config：网络安全基础规则。
cleartextTrafficPermitted="false"：是否允许明文 HTTP；main=false，debug 同名覆盖=true。
该元素以 /> 自闭合，没有嵌套子节点。
关闭 network-security-config 元素，结束它的嵌套作用域。
