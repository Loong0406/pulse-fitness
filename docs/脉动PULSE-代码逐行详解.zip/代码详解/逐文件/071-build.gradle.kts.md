# build.gradle.kts

根工程只用 base 插件提供基础生命周期，不把整个工程误当一个 Android 应用。

原文件 SHA-256：`ae1b90d4ca79eab87e53b809c85bbf171bb415244da3ac769240367ef36c0d44`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
plugins { base }
```

应用 Gradle base 插件；Android application 插件在 app/build.gradle.kts 中配置。
