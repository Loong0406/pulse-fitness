# core/build.gradle.kts

纯 Java 核心库，独立于 Android，可快速运行领域单元测试。

原文件 SHA-256：`4c812ae2ef096c8a951825d08193349209dc3ca1384bd16058625695d1ff1646`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
plugins { `java-library` }
```

使用 java-library 插件，提供可被其他模块依赖的库。

## 第 2 行

```text
java {
```

开始 Java 配置。

## 第 3 行

```text
    sourceCompatibility = JavaVersion.VERSION_17
```

Java 源语法级别 17。

## 第 4 行

```text
    targetCompatibility = JavaVersion.VERSION_17
```

目标字节码级别 17。

## 第 5 行

```text
}
```

结束 Java 配置。

## 第 6 行

```text
tasks.withType<JavaCompile>().configureEach { options.encoding = "UTF-8" }
```

对每个 Java 编译任务使用 UTF-8。

## 第 7 行

```text
dependencies {
```

开始依赖声明。

## 第 8 行

```text
    api("com.google.code.gson:gson:2.11.0")
```

api 暴露 Gson 2.11.0，使依赖 core 的模块也能使用它。

## 第 9 行

```text
    testImplementation("junit:junit:4.13.2")
```

JUnit 4.13.2 只用于测试，不打入生产运行依赖。

## 第 10 行

```text
}
```

结束依赖块。
