# core/src/main/java/com/pulse/core/auth/DemoPhoneAuth.java

手机号演示登录的纯 Java 规则。输入号码和验证码，输出校验结果；不会发送短信，也不能证明号码属于操作者。

原文件 SHA-256：`4ded4b3107d995fe61dac0f2e9d5537ae4be3c495bfa64e5c8da8c91fe66fbc0`。行号仅对应此快照；修改源码后应重新核对。

共 52 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.auth;
```

声明本文件所属包 com.pulse.core.auth；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import java.security.SecureRandom;
```

导入类型命名空间 java.security.SecureRandom，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.Locale;
```

导入类型命名空间 java.util.Locale，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.util.function.IntSupplier;
```

导入类型命名空间 java.util.function.IntSupplier，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.util.function.LongSupplier;
```

导入类型命名空间 java.util.function.LongSupplier，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
/** Local UI demonstration only. No SMS is sent and phone ownership is not established. */
```

源码注释，不参与执行。手机号演示登录的纯 Java 规则。输入号码和验证码，输出校验结果；不会发送短信，也不能证明号码属于操作者。

## 第 9 行

```java
public final class DemoPhoneAuth {
```

定义 public final class DemoPhoneAuth。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    public static final int RESEND_SECONDS=60, VALID_SECONDS=300, MAX_ATTEMPTS=5;
```

三个规则常量：重发间隔 60 秒、有效期 300 秒、最多输错 5 次。static 属于类，final 禁止重新赋值。

## 第 11 行

```java
    public static final class CodeDelivery {
```

定义返回值 CodeDelivery，把一次请求的号码和演示码装在一起；static 内部类不暗中引用外部对象。

## 第 12 行

```java
        public final String phone,code;
```

两个只读字符串分别保存规范化号码和六位验证码。

## 第 13 行

```java
        private CodeDelivery(String phone,String code){this.phone=phone;this.code=code;}
```

私有构造器仅供外层类创建；this.phone 表示对象字段，右侧 phone 表示传入参数。

## 第 14 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 15 行

```java
    private final LongSupplier clock;
```

保存“提供当前毫秒数”的函数，测试可以换成可控假时钟。

## 第 16 行

```java
    private final IntSupplier numbers;
```

保存“提供随机整数”的函数，测试可固定返回 42。

## 第 17 行

```java
    private String phone,code;
```

暂存本次号码和验证码；不是数据库字段，进程退出后消失。

## 第 18 行

```java
    private long issuedAt,nextRequestAt=-1;
```

issuedAt 为发码时刻；nextRequestAt 为下一次允许请求的时刻，-1 表示尚未请求。

## 第 19 行

```java
    private int attempts;
```

保存本次验证码累计输错次数，未初始化的 int 默认是 0。

## 第 20 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 21 行

```java
    public DemoPhoneAuth(){this(()->System.nanoTime()/1_000_000L,new SecureRandom()::nextInt);}
```

无参构造器转调另一个构造器：纳秒除以一百万变毫秒；方法引用提供安全随机数。它测时间间隔，不是日历时间。

## 第 22 行

```java
    public DemoPhoneAuth(LongSupplier clock,IntSupplier numbers){this.clock=clock;this.numbers=numbers;}
```

注入时间函数和随机数函数，业务逻辑无需知道 Android 时钟或测试时钟。

## 第 23 行

```java
    public static String normalizePhone(String raw){
```

声明号码规范化方法，输入原始字符串，返回规范化号码。

## 第 24 行

```java
        String value=raw==null?"":raw.replace(" ","").replace("-","").trim();
```

null 变空串，再去掉普通空格、短横线及首尾空白；三元表达式 condition?A:B 根据条件取值。

## 第 25 行

```java
        if(!value.matches("1[3-9][0-9]{9}"))throw new IllegalArgumentException("请输入正确的 11 位中国大陆手机号");
```

正则要求 11 位数字，第一位 1、第二位 3–9、后九位任意数字；不符合就抛异常，后续代码不执行。

## 第 26 行

```java
        return value;
```

返回已清理且通过格式检查的号码。格式检查不验证号码是否真实存在。

## 第 27 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 28 行

```java
    public CodeDelivery requestCode(String raw){
```

声明请求演示码方法，返回 CodeDelivery。

## 第 29 行

```java
        String value=normalizePhone(raw);
```

先规范化号码；错误会直接向调用者传播。

## 第 30 行

```java
        if(resendSeconds()>0)throw new IllegalArgumentException("请等待倒计时结束后重新获取验证码");
```

尚在重发冷却期就拒绝请求；更换号码也绕不过同一个实例的冷却期。

## 第 31 行

```java
        phone=value;code=String.format(Locale.ROOT,"%06d",Math.floorMod(numbers.getAsInt(),1_000_000));
```

记住号码；floorMod 把随机整数映射到 0–999999，%06d 补足前导零；Locale.ROOT 避免本地化数字。

## 第 32 行

```java
        issuedAt=clock.getAsLong();nextRequestAt=issuedAt+RESEND_SECONDS*1000L;attempts=0;
```

记发码时刻，计算下次允许请求时刻，并清零错误次数；1000L 的 L 表示 long。

## 第 33 行

```java
        return new CodeDelivery(phone,code);
```

将号码和验证码交给界面展示。真实短信系统不能把验证码作为这种客户端返回值。

## 第 34 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 35 行

```java
    public void verify(String rawPhone,String rawCode){
```

声明校验方法；成功无返回值，失败抛 IllegalArgumentException。

## 第 36 行

```java
        String value=normalizePhone(rawPhone);
```

先对用户提交的号码执行同样的规范化规则。

## 第 37 行

```java
        if(code==null)throw new IllegalArgumentException("请先获取本机演示验证码");
```

内存里没有待验证的码则拒绝；成功用过、过期或错误过多都会导致它变为 null。

## 第 38 行

```java
        if(!phone.equals(value))throw new IllegalArgumentException("手机号已更改，请为当前手机号重新获取验证码");
```

必须与发码号码一致，防止把一个号码的演示码用在另一个号码上。

## 第 39 行

```java
        long elapsed=clock.getAsLong()-issuedAt;
```

当前单调时间减发码时间，得到已经过去的毫秒数。

## 第 40 行

```java
        if(elapsed<0||elapsed>=VALID_SECONDS*1000L){code=null;throw new IllegalArgumentException("验证码已过期，请重新获取");}
```

时钟倒退或已满 300 秒时，使验证码失效并抛出过期提示；边界使用 >=。

## 第 41 行

```java
        String entered=rawCode==null?"":rawCode.trim();
```

输入码为 null 时变空串，否则仅清除首尾空白。

## 第 42 行

```java
        if(!entered.matches("[0-9]{6}"))throw new IllegalArgumentException("请输入 6 位验证码");
```

输入必须是恰好六位 ASCII 数字。格式错误在本行返回，不计入下面的错误码次数。

## 第 43 行

```java
        if(!code.equals(entered)){
```

若六位码与保存的码不同，进入错误分支。

## 第 44 行

```java
            attempts++;
```

累加输错次数；++ 表示在原值基础上加 1。

## 第 45 行

```java
            if(attempts>=MAX_ATTEMPTS){code=null;throw new IllegalArgumentException("验证码连续错误，请重新获取");}
```

达到五次时先清空码再抛异常，旧的正确码也不能继续使用。

## 第 46 行

```java
            throw new IllegalArgumentException("验证码不正确，请检查本机演示验证码");
```

未达五次则提示验证码不正确，保留码供下一次尝试。

## 第 47 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 48 行

```java
        code=null;phone=null;attempts=0;
```

验证成功后清空号码、码和错误次数，一次性消费；重发时限仍然保留。

## 第 49 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 50 行

```java
    public int resendSeconds(){return nextRequestAt<0?0:(int)Math.max(0,(nextRequestAt-clock.getAsLong()+999)/1000);}
```

计算剩余秒数：未发过为 0，否则差值加 999 后整除 1000，相当于向上取整；Math.max 防止负数。

## 第 51 行

```java
    public void clear(){phone=null;code=null;attempts=0;nextRequestAt=-1;}
```

清除所有临时登录规则状态；退出登录或清除数据时使用，不删除训练资料。

## 第 52 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
