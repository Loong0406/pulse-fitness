# core/src/main/java/com/pulse/core/data/MemoryRepositoryFactory.java

测试用仓库产品族，所有数据仅在对象内存里，不写磁盘。

原文件 SHA-256：`e4920113ae83b13529d2c2ed28b461dac9919160adb2aabe8a3f646472020e40`。行号仅对应此快照；修改源码后应重新核对。

共 18 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.data;
```

声明本文件所属包 com.pulse.core.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 6 行

```java
/** In-memory product family for isolated tests and embedded integrations. */
```

源码注释，不参与执行。测试用仓库产品族，所有数据仅在对象内存里，不写磁盘。

## 第 7 行

```java
public final class MemoryRepositoryFactory implements Repositories.Factory {
```

定义 public final class MemoryRepositoryFactory implements Repositories.Factory。实现 Repositories.Factory 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 8 行

```java
    private UserProfile profile;
```

内存中的档案引用，最初为 null。

## 第 9 行

```java
    private WeekPlan plan;
```

内存中的当前计划引用，最初为 null。

## 第 10 行

```java
    private final List<TrainingRecord> records=new ArrayList<>();
```

历史记录列表，字段不能改指向，但列表内容可以添加或清空。

## 第 11 行

```java
    public Repositories.Profiles profiles(){return new Repositories.Profiles(){public UserProfile get(){return profile;}public void save(UserProfile p){profile=p;}};}
```

返回匿名 Profiles 实现；get 读外层 profile，save 替换它。多个产品访问同一工厂字段。

## 第 12 行

```java
    public Repositories.Plans plans(){return new Repositories.Plans(){public WeekPlan get(){return plan;}public void save(WeekPlan p){plan=p;}public void clear(){plan=null;}};}
```

返回匿名 Plans 实现；保存替换 plan，清除置 null。

## 第 13 行

```java
    public Repositories.History history(){return new Repositories.History(){
```

开始创建匿名 History 实现，后续各方法读写工厂中的 records。

## 第 14 行

```java
        public List<TrainingRecord> all(){return Collections.unmodifiableList(new ArrayList<>(records));}
```

先复制记录列表，再返回只读包装；外部不能修改工厂原列表。

## 第 15 行

```java
        public void add(TrainingRecord r){for(TrainingRecord old:records)if(old.id.equals(r.id))return;records.add(0,r);}
```

用 ID 扫描去重，已存在直接返回；新记录插到索引 0，最新优先。

## 第 16 行

```java
        public void clear(){records.clear();}
```

清空所有记录。

## 第 17 行

```java
    };}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 18 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
