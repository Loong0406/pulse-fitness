# core/src/main/java/com/pulse/core/data/ProfileCommand.java

将一次档案保存封装为命令，记录旧档案以支持一次撤销。

原文件 SHA-256：`2e0d6f5cf72e3d478824882cadcda8ca77d8e9184ccec3ed239656bd829aae10`。行号仅对应此快照；修改源码后应重新核对。

共 15 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.data;
```

声明本文件所属包 com.pulse.core.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.UserProfile;
```

导入类型命名空间 com.pulse.core.model.UserProfile，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import com.pulse.core.validation.ProfileValidator;
```

导入类型命名空间 com.pulse.core.validation.ProfileValidator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Command: saving and undoing a profile are independent of buttons and storage details. */
```

源码注释，不参与执行。将一次档案保存封装为命令，记录旧档案以支持一次撤销。

## 第 6 行

```java
public final class ProfileCommand {
```

定义 public final class ProfileCommand。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    private final Repositories.Profiles profiles;
```

依赖档案仓库接口，而不是 Android 存储。

## 第 8 行

```java
    private final UserProfile replacement;
```

本命令准备保存的新档案。

## 第 9 行

```java
    private UserProfile previous;
```

执行前的旧档案快照；UserProfile 不可变，保存引用即可。

## 第 10 行

```java
    private boolean executed;
```

标记命令是否执行过。

## 第 11 行

```java
    public ProfileCommand(Repositories.Profiles profiles,UserProfile replacement){this.profiles=profiles;this.replacement=replacement;}
```

通过构造器接收仓库和待保存档案。

## 第 12 行

```java
    public void execute(){ProfileValidator.validateForStorage(replacement);previous=profiles.get();profiles.save(replacement);executed=true;}
```

先校验，读取旧值，保存新值，最后标记执行成功；校验失败时不会覆盖原值。

## 第 13 行

```java
    public boolean canUndo(){return executed&&previous!=null;}
```

只有命令执行过且原来存在档案时可撤销，首次创建不支持撤销成“无档案”。

## 第 14 行

```java
    public void undo(){if(!canUndo())throw new IllegalStateException("没有可撤销的档案");profiles.save(previous);executed=false;}
```

不可撤销就抛状态异常；否则恢复旧档案并标记本命令已撤销，不提供多级撤销或重做。

## 第 15 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
