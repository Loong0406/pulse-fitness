# core/src/main/java/com/pulse/core/data/Repositories.java

仓库接口集合，定义“需要什么存储能力”，不规定 SharedPreferences 或内存如何实现。

原文件 SHA-256：`f86e2e9c6b9d68ad82362a8e5da047232af99e266fea95be1f50e07b65e9f1d3`。行号仅对应此快照；修改源码后应重新核对。

共 13 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.data;
```

声明本文件所属包 com.pulse.core.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.List;
```

导入类型命名空间 java.util.List，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 6 行

```java
public final class Repositories {
```

定义 public final class Repositories。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    public interface Profiles {UserProfile get();void save(UserProfile p);}
```

档案仓库契约：get 读一份档案，save 保存一份档案。

## 第 8 行

```java
    public interface Plans {WeekPlan get();void save(WeekPlan p);void clear();}
```

计划仓库契约：读取、保存、清除当前计划。

## 第 9 行

```java
    public interface History {List<TrainingRecord> all();void add(TrainingRecord r);void clear();}
```

历史仓库契约：读取全部、增加记录、清空历史。

## 第 10 行

```java
    /** Abstract Factory: creates a consistent family for one storage backend. */
```

源码注释，不参与执行。抽象工厂：同一后端创建一致的仓库产品族。

## 第 11 行

```java
    public interface Factory {Profiles profiles();Plans plans();History history();}
```

抽象工厂一次提供同一存储体系的三种仓库，避免业务层拼接不一致的后端。

## 第 12 行

```java
    private Repositories(){}
```

私有空构造器，阻止外部创建这个仅充当命名空间的工具类。

## 第 13 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
