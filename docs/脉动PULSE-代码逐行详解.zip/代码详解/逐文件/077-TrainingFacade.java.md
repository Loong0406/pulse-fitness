# core/src/main/java/com/pulse/core/data/TrainingFacade.java

统一协调计划生成、提交和失效，页面不需要直接操作计划仓库。

原文件 SHA-256：`e0852394fc5cb17e6d3b7b4970915f794faadb22a1820903dc53bd535f5bd780`。行号仅对应此快照；修改源码后应重新核对。

共 20 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.data;
```

声明本文件所属包 com.pulse.core.data；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Facade coordinates generation and persistence without exposing storage to screens. */
```

源码注释，不参与执行。统一协调计划生成、提交和失效，页面不需要直接操作计划仓库。

## 第 6 行

```java
public final class TrainingFacade {
```

定义 public final class TrainingFacade。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    private final Repositories.Profiles profiles;
```

档案仓库接口字段。

## 第 8 行

```java
    private final Repositories.Plans plans;
```

计划仓库接口字段。

## 第 9 行

```java
    public TrainingFacade(Repositories.Factory factory){profiles=factory.profiles();plans=factory.plans();}
```

从注入的抽象工厂取两个配套仓库。

## 第 10 行

```java
    public WeekPlan generate(PlanGenerator generator)throws Exception{
```

开始生成；参数是任意符合 PlanGenerator 的生成器，可能抛出网络等异常。

## 第 11 行

```java
        UserProfile p=profiles.get();if(p==null)throw new IllegalArgumentException("请先保存个人档案");
```

读取最新存档；没有档案就拒绝生成。

## 第 12 行

```java
        return generator.generate(p);
```

用档案生成并返回候选，注意这里尚未保存，给异步版本检查留出机会。

## 第 13 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 14 行

```java
    public void commit(WeekPlan result){
```

提交候选到存储，与耗时生成分开。

## 第 15 行

```java
        UserProfile p=profiles.get();if(p==null)throw new IllegalArgumentException("请先保存个人档案");
```

再读一次当前档案，避免生成期间档案被删除。

## 第 16 行

```java
        PlanSafety.validate(result,p);plans.save(result);
```

对照当前档案校验候选，只有通过才保存。

## 第 17 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 18 行

```java
    public WeekPlan current(){return plans.get();}
```

读取当前已保存计划。

## 第 19 行

```java
    public void invalidate(){plans.clear();}
```

清除计划，使旧档案对应的计划失效。

## 第 20 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
