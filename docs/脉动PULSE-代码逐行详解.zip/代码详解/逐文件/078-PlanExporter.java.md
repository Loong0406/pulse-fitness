# core/src/main/java/com/pulse/core/export/PlanExporter.java

桥接导出：JSON/文本格式与写到内存/Android 文档的目标可以独立替换。

原文件 SHA-256：`74f24e7a62b615867d0d60af78f9b98ceb559ab853212657672e83ad548fd71a`。行号仅对应此快照；修改源码后应重新核对。

共 27 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.export;
```

声明本文件所属包 com.pulse.core.export；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.io.IOException;
```

导入类型命名空间 java.io.IOException，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 7 行

```java
/** Bridge: export format and output destination vary independently. */
```

源码注释，不参与执行。桥接导出：JSON/文本格式与写到内存/Android 文档的目标可以独立替换。

## 第 8 行

```java
public abstract class PlanExporter {
```

定义 public abstract class PlanExporter。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 9 行

```java
    public interface Sink {void write(String text)throws IOException;}
```

Sink 只承诺接收字符串并写出，失败可抛 IOException。

## 第 10 行

```java
    protected final Sink sink;
```

保存写入目标，具体导出器不用知道它是文件还是内存。

## 第 11 行

```java
    protected PlanExporter(Sink sink){this.sink=sink;}
```

父类构造器注入输出目标。

## 第 12 行

```java
    public abstract void export(WeekPlan plan)throws IOException;
```

子类负责把计划转换成文本并交给 sink。

## 第 13 行

```java
    public static final class Json extends PlanExporter {
```

JSON 格式的具体导出器。

## 第 14 行

```java
        public Json(Sink sink){super(sink);}
```

把传入目标交给父类保存。

## 第 15 行

```java
        public void export(WeekPlan p)throws IOException{sink.write(JsonCodec.plan(p));}
```

计划转 JSON 后统一调用 sink.write。

## 第 16 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 17 行

```java
    public static final class Text extends PlanExporter {
```

易读文本格式的具体导出器。

## 第 18 行

```java
        public Text(Sink sink){super(sink);}
```

同样注入任意 Sink。

## 第 19 行

```java
        public void export(WeekPlan p)throws IOException{
```

开始把周计划整理成可读文本。

## 第 20 行

```java
            StringBuilder b=new StringBuilder("脉动 PULSE · 一周训练计划\n来源：").append(p.source==WeekPlan.Source.AI?"大模型":"本地规则").append("\n").append(p.note).append("\n");
```

StringBuilder 连续追加标题、真实来源和说明；\n 是换行符。

## 第 21 行

```java
            for(DayPlan d:p){b.append("\n周").append("一二三四五六日".charAt(d.dayIndex)).append(" · ").append(d.title).append("\n");
```

通过迭代器遍历日程，按 dayIndex 从中文星期字符串取一天，再附标题。

## 第 22 行

```java
                for(Prescription rx:d.exercises){Exercise e=ExerciseCatalog.get(rx.exerciseId);b.append(e.name).append(" ").append(rx.sets).append("组 × ").append(rx.amount).append(e.timed?"秒":"次").append("，休息").append(rx.restSeconds).append("秒\n");}}
```

遍历当日处方，从目录查名称和计时类型，输出组数×次数/秒数及休息；本行末尾关闭两层循环。

## 第 23 行

```java
            sink.write(b.toString());
```

一次性把完整文本交给目标写出。

## 第 24 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 25 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
    public static final class MemorySink implements Sink {public String value;public void write(String text){value=text;}}
```

内存目标直接把文本放在 value 字段，供测试验证，不写磁盘。

## 第 27 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
