# core/src/main/java/com/pulse/core/model/DayPlan.java

某一天的计划：含日索引、标题、动作处方；空动作列表表示恢复日。

原文件 SHA-256：`439183b7902c1e351da433f5ac5c8dba64e868c9f7b4d5797b534c7fc6aa00a4`。行号仅对应此快照；修改源码后应重新核对。

共 21 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import java.util.ArrayList;
```

导入类型命名空间 java.util.ArrayList，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.Collections;
```

导入类型命名空间 java.util.Collections，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.util.List;
```

导入类型命名空间 java.util.List，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.plan.PlanVisitor;
```

导入类型命名空间 com.pulse.core.plan.PlanVisitor，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
public final class DayPlan implements PlanNode {
```

定义 public final class DayPlan implements PlanNode。实现 PlanNode 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 9 行

```java
    public final int dayIndex;
```

周内索引 0–6，对应周一到周日。

## 第 10 行

```java
    public final String title;
```

单日标题，例如基础力量或主动恢复。

## 第 11 行

```java
    public final List<Prescription> exercises;
```

保存只读动作处方列表。

## 第 12 行

```java
    public DayPlan(int day,String title,List<Prescription> exercises) {
```

构造器接收日索引、标题及动作列表。

## 第 13 行

```java
        dayIndex=day;this.title=title;this.exercises=Collections.unmodifiableList(new ArrayList<>(exercises));
```

设置日索引和标题；复制列表再加只读包装，调用方后续更改原列表不会影响计划。

## 第 14 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 15 行

```java
    public boolean isRest() {return exercises.isEmpty();}
```

列表为空即为恢复日，不额外维护容易不同步的布尔字段。

## 第 16 行

```java
    public DayPlan copy() {
```

开始深复制这个日计划。

## 第 17 行

```java
        List<Prescription> list=new ArrayList<>();for(Prescription p:exercises)list.add(p.copy());
```

创建新列表，逐个调用处方 copy，避免新旧日程共享处方对象。

## 第 18 行

```java
        return new DayPlan(dayIndex,title,list);
```

用相同索引和标题、新处方列表构造新日程。

## 第 19 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
    @Override public void accept(PlanVisitor visitor) {visitor.visitDay(this);for(Prescription p:exercises)p.accept(visitor);}
```

先让访问者处理这一天，再依次处理每个处方；组合树的遍历由节点自己负责。

## 第 21 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
