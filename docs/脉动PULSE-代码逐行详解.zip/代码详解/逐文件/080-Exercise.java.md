# core/src/main/java/com/pulse/core/model/Exercise.java

共享动作定义（享元）：固定名称、器械、限制、要领；不存某人的组数和次数。

原文件 SHA-256：`1d233b4cd6bbce237e31efc9e0d4f2f9c4828dce7caa388e9dbfa0c7ecaa8347`。行号仅对应此快照；修改源码后应重新核对。

共 20 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
/** Flyweight: catalog information is immutable; sets and reps live in prescriptions. */
```

源码注释，不参与执行。共享动作定义（享元）：固定名称、器械、限制、要领；不存某人的组数和次数。

## 第 4 行

```java
public final class Exercise {
```

定义 public final class Exercise。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 5 行

```java
    public final String id,name,group,equipmentLabel,cue;
```

保存动作 ID、名称、部位、器械显示名、简短要领；ID 是计划引用动作的稳定键。

## 第 6 行

```java
    public final java.util.List<String> steps;
```

保存有顺序的动作步骤列表。

## 第 7 行

```java
    public final UserProfile.Equipment equipment;
```

该动作需要的器械枚举。

## 第 8 行

```java
    public final boolean timed,kneeLoad,backLoad,impact;
```

timed 表示按秒计量；其余三个布尔值标记膝负荷、背负荷和冲击。

## 第 9 行

```java
    public Exercise(String id,String name,String group,UserProfile.Equipment equipment,boolean timed,
```

构造器参数前半部分：标识、名字、部位、器械、是否计时。

## 第 10 行

```java
                    boolean kneeLoad,boolean backLoad,boolean impact,String cue,String... steps) {
```

后半部分为风险标签、要领及可变数量 steps；String... 在方法内表现为数组。

## 第 11 行

```java
        this.id=id;this.name=name;this.group=group;this.equipment=equipment;this.timed=timed;
```

把输入的标识、名称、部位、器械与计时类型赋给对象。

## 第 12 行

```java
        this.kneeLoad=kneeLoad;this.backLoad=backLoad;this.impact=impact;this.cue=cue;this.steps=java.util.Collections.unmodifiableList(java.util.Arrays.asList(steps.clone()));
```

复制限制和要领；先克隆步骤数组，再包装不可修改列表，避免外部更改原数组影响对象。

## 第 13 行

```java
        equipmentLabel=equipment==UserProfile.Equipment.BODYWEIGHT?"徒手":equipment==UserProfile.Equipment.DUMBBELL?"哑铃":"健身房";
```

三元表达式按器械生成中文名：徒手、哑铃或健身房。

## 第 14 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 15 行

```java
    public boolean isAllowed(UserProfile p) {
```

判断某动作能否出现在给定档案的计划中。

## 第 16 行

```java
        return (equipment==UserProfile.Equipment.BODYWEIGHT || equipment==p.equipment || p.equipment==UserProfile.Equipment.GYM)
```

器械条件：徒手动作通用，或器械恰好匹配，或用户具有健身房器械条件。

## 第 17 行

```java
                && !(p.protectKnees&&kneeLoad) && !(p.protectBack&&backLoad)
```

&& 要求同时满足：保护膝时排除膝负荷动作，保护背时排除背负荷动作；! 表示取反。

## 第 18 行

```java
                && !((p.lowImpact||p.age>=60||p.experience==UserProfile.Experience.BEGINNER)&&impact);
```

低冲击需求、年龄至少 60 岁或新手，任一成立都排除冲击动作；这些是本项目编码规则，不是临床结论。

## 第 19 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
