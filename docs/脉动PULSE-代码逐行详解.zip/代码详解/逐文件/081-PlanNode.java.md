# core/src/main/java/com/pulse/core/model/PlanNode.java

组合模式的公共节点契约，周、天、处方都实现 accept。

原文件 SHA-256：`be4c85ad28a4e36347671b33faab0003bee6bb6698089ad676eb58ef8b8725c8`。行号仅对应此快照；修改源码后应重新核对。

共 6 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.plan.PlanVisitor;
```

导入类型命名空间 com.pulse.core.plan.PlanVisitor，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Composite contract used uniformly by week, day and exercise nodes. */
```

源码注释，不参与执行。组合模式的公共节点契约，周、天、处方都实现 accept。

## 第 6 行

```java
public interface PlanNode { void accept(PlanVisitor visitor); }
```

定义接口而非实现；每种节点接收 PlanVisitor，并自行决定如何访问自身和子节点。
