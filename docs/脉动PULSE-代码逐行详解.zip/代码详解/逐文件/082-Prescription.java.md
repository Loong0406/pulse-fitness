# core/src/main/java/com/pulse/core/model/Prescription.java

动作处方叶子节点：引用共享动作 ID，单独存本次训练负荷。

原文件 SHA-256：`edddc05f713372868417b5e2a6bbe275255c24a47b819b7b74f384c3c29fb850`。行号仅对应此快照；修改源码后应重新核对。

共 13 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.plan.PlanVisitor;
```

导入类型命名空间 com.pulse.core.plan.PlanVisitor，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
public final class Prescription implements PlanNode {
```

定义 public final class Prescription implements PlanNode。实现 PlanNode 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 6 行

```java
    public final String exerciseId;
```

动作 ID，具体名字与步骤通过 ExerciseCatalog 查询，避免重复储存。

## 第 7 行

```java
    public final int sets,amount,restSeconds;
```

组数、每组数量及组间休息秒数；amount 的单位由动作 timed 决定。

## 第 8 行

```java
    public Prescription(String id,int sets,int amount,int restSeconds) {
```

构造器接收动作及三个负荷值。

## 第 9 行

```java
        this.exerciseId=id;this.sets=sets;this.amount=amount;this.restSeconds=restSeconds;
```

直接赋值；合法范围由 PlanSafety 统一检查。

## 第 10 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 11 行

```java
    public Prescription copy() {return new Prescription(exerciseId,sets,amount,restSeconds);}
```

复制为内容相同但引用不同的新处方，供原型复制使用。

## 第 12 行

```java
    @Override public void accept(PlanVisitor visitor) {visitor.visitExercise(this);}
```

接受访问者，调用针对动作处方的 visitExercise；this 是当前处方。

## 第 13 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
