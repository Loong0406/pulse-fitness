# core/src/main/java/com/pulse/core/model/TrainingRecord.java

训练完成后保存的结果数据，id 来自会话并用于去重。

原文件 SHA-256：`7cca1ca8f8cdefd6d5eec7bc516b90a4e73aa70eb496decd0aa0e253fda21706`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
public final class TrainingRecord {
```

定义 public final class TrainingRecord。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 4 行

```java
    public final String id,title;
```

唯一会话 ID 和训练标题。

## 第 5 行

```java
    public final long completedAt;
```

完成时刻的 Unix 毫秒时间，和累计训练时长不是同一概念。

## 第 6 行

```java
    public final int activeSeconds,completedSets;
```

活跃累计秒数和已确认完成组数；当前秒数包含未暂停的热身、训练、休息及放松。

## 第 7 行

```java
    public TrainingRecord(String id,String title,long time,int seconds,int sets) {
```

构造器接收 ID、标题、完成时刻、时长、完成组数。

## 第 8 行

```java
        this.id=id;this.title=title;completedAt=time;activeSeconds=seconds;completedSets=sets;
```

将参数存入不可重新赋值字段；time 对应完成时刻，不是秒数。

## 第 9 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 10 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
