# core/src/main/java/com/pulse/core/model/UserProfile.java

不可变的个人档案：由 Builder 逐步设置，由生成器、校验器和存储共同读取。

原文件 SHA-256：`1e93664113ba348247e7f1201822102b6248dc91b56533feb839c4557cf55742`。行号仅对应此快照；修改源码后应重新核对。

共 55 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import java.util.Locale;
```

导入类型命名空间 java.util.Locale，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Immutable profile. Builder is the only construction API. */
```

源码注释，不参与执行。不可变的个人档案：由 Builder 逐步设置，由生成器、校验器和存储共同读取。

## 第 6 行

```java
public final class UserProfile {
```

定义 public final class UserProfile。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    public enum Goal { FAT_LOSS, STRENGTH, WELLBEING }
```

目标枚举：减脂、力量、改善体能；枚举比随意拼字符串更不容易写错。

## 第 8 行

```java
    public enum Experience { BEGINNER, REGULAR, ADVANCED }
```

经验枚举：新手、规律训练者、进阶者；声明顺序也被界面下拉框使用。

## 第 9 行

```java
    public enum Equipment { BODYWEIGHT, DUMBBELL, GYM }
```

器械枚举：徒手、哑铃、健身房；改变顺序时要同步检查下拉框映射。

## 第 10 行

```java
    public final String name;
```

用户昵称；仅用于本机展示，不发送给上游模型。

## 第 11 行

```java
    public final int age;
```

年龄，单位岁。

## 第 12 行

```java
    public final String sex;
```

性别文本；允许不透露，上游模型请求会删除它。

## 第 13 行

```java
    public final double heightCm, weightKg;
```

身高厘米和体重千克，double 可表示小数。

## 第 14 行

```java
    public final Goal goal;
```

保存训练目标枚举。

## 第 15 行

```java
    public final Experience experience;
```

保存训练经验枚举。

## 第 16 行

```java
    public final Equipment equipment;
```

保存可用器械枚举。

## 第 17 行

```java
    public final int daysPerWeek, minutesPerSession;
```

每周训练天数、每次可用分钟数。

## 第 18 行

```java
    public final boolean protectKnees, protectBack, lowImpact, needsProfessional;
```

四个限制开关：保护膝、保护腰背、低冲击、需要专业评估。

## 第 19 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 20 行

```java
    private UserProfile(Builder b) {
```

构造器私有，外部必须通过 Builder 创建，避免十几个位置参数混淆。

## 第 21 行

```java
        name=b.name; age=b.age; sex=b.sex; heightCm=b.heightCm; weightKg=b.weightKg;
```

把建造者中的昵称、年龄、性别、身高和体重复制进只读字段。

## 第 22 行

```java
        goal=b.goal; experience=b.experience; equipment=b.equipment;
```

复制目标、经验和器械。

## 第 23 行

```java
        daysPerWeek=b.days; minutesPerSession=b.minutes;
```

将 Builder 的 days/minutes 对应到领域字段 daysPerWeek/minutesPerSession。

## 第 24 行

```java
        protectKnees=b.knees; protectBack=b.back; lowImpact=b.lowImpact; needsProfessional=b.professional;
```

复制四项限制；赋值不会自动校验，校验发生在存档或生成边界。

## 第 25 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
    public String signature() {
```

生成训练相关字段的版本标识，用于判断计划是否仍匹配当前档案。

## 第 27 行

```java
        return String.format(Locale.ROOT,"%d|%s|%.1f|%.1f|%s|%s|%s|%d|%d|%b|%b|%b|%b",age,sex,heightCm,weightKg,
```

使用固定区域格式拼接字段；%d 整数、%s 文本、%.1f 一位小数、%b 布尔。这里是普通摘要字符串，不是密码哈希。

## 第 28 行

```java
                goal,experience,equipment,daysPerWeek,minutesPerSession,protectKnees,protectBack,lowImpact,needsProfessional);
```

按上行占位顺序继续传入目标、经验、器械、时间及限制；昵称不参与签名。

## 第 29 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 30 行

```java
    public Builder toBuilder() {
```

从已有档案创建可修改的建造者，原档案保持不变。

## 第 31 行

```java
        return new Builder().name(name).age(age).sex(sex).body(heightCm,weightKg).goal(goal)
```

新建 Builder，并链式设置昵称、年龄、性别、身体数据与目标。

## 第 32 行

```java
                .experience(experience).equipment(equipment).schedule(daysPerWeek,minutesPerSession)
```

继续设置经验、器械、每周频率和单次时间。

## 第 33 行

```java
                .limitations(protectKnees,protectBack,lowImpact,needsProfessional);
```

复制限制后返回 Builder；调用方可接着改属性再 build。

## 第 34 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 35 行

```java
    public static UserProfile defaults() { return new Builder().build(); }
```

返回一份使用所有默认值的档案，不意味着已经存档。

## 第 36 行

```java
    public static final class Builder {
```

定义静态内部建造者类，持有可修改的构建中状态。

## 第 37 行

```java
        private String name="训练者", sex="不透露";
```

默认昵称为训练者，默认性别为不透露。

## 第 38 行

```java
        private int age=25, days=3, minutes=30;
```

默认 25 岁、每周 3 天、每次 30 分钟。

## 第 39 行

```java
        private double heightCm=170, weightKg=65;
```

默认身高 170 cm、体重 65 kg。

## 第 40 行

```java
        private Goal goal=Goal.WELLBEING;
```

默认目标是改善体能。

## 第 41 行

```java
        private Experience experience=Experience.BEGINNER;
```

默认经验为新手。

## 第 42 行

```java
        private Equipment equipment=Equipment.BODYWEIGHT;
```

默认器械为徒手。

## 第 43 行

```java
        private boolean knees,back,lowImpact,professional;
```

四个 boolean 未显式赋值，初始均为 false。

## 第 44 行

```java
        public Builder name(String v) {name=v==null?"":v.trim();return this;}
```

设置昵称：null 转空串，否则去首尾空白；返回 this 允许继续 .age(...)。

## 第 45 行

```java
        public Builder age(int v) {age=v;return this;}
```

设置年龄并返回同一个 Builder。

## 第 46 行

```java
        public Builder sex(String v) {sex=v;return this;}
```

设置性别文本并返回 Builder。

## 第 47 行

```java
        public Builder body(double h,double w) {heightCm=h;weightKg=w;return this;}
```

同时设置身高和体重，参数 h/w 分别代表厘米/千克。

## 第 48 行

```java
        public Builder goal(Goal v) {goal=v;return this;}
```

设置目标。

## 第 49 行

```java
        public Builder experience(Experience v) {experience=v;return this;}
```

设置经验。

## 第 50 行

```java
        public Builder equipment(Equipment v) {equipment=v;return this;}
```

设置器械。

## 第 51 行

```java
        public Builder schedule(int d,int m) {days=d;minutes=m;return this;}
```

同时设置每周天数和每次分钟数。

## 第 52 行

```java
        public Builder limitations(boolean k,boolean b,boolean l,boolean p) {knees=k;back=b;lowImpact=l;professional=p;return this;}
```

k/b/l/p 对应膝、背、低冲击、需专业评估；顺序必须与调用方一致。

## 第 53 行

```java
        public UserProfile build() {return new UserProfile(this);}
```

创建新的 UserProfile，构造器会从当前 Builder 复制字段。

## 第 54 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 55 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
