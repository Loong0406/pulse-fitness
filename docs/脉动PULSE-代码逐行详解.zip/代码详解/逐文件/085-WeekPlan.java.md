# core/src/main/java/com/pulse/core/model/WeekPlan.java

周计划根节点：可只读遍历、可深复制新周期、可接受统计访问者。

原文件 SHA-256：`37b7dad5479eed5105d75899992e3d942a3490adbee0622e85a9e467b1d58fa9`。行号仅对应此快照；修改源码后应重新核对。

共 28 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.model;
```

声明本文件所属包 com.pulse.core.model；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.plan.PlanVisitor;
```

导入类型命名空间 com.pulse.core.plan.PlanVisitor，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.ArrayList;
```

导入类型命名空间 java.util.ArrayList，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.util.Collections;
```

导入类型命名空间 java.util.Collections，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.util.Iterator;
```

导入类型命名空间 java.util.Iterator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.util.List;
```

导入类型命名空间 java.util.List，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import java.util.UUID;
```

导入类型命名空间 java.util.UUID，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 10 行

```java
public final class WeekPlan implements PlanNode, Iterable<DayPlan> {
```

定义 public final class WeekPlan implements PlanNode, Iterable<DayPlan>。实现 PlanNode, Iterable<DayPlan> 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 11 行

```java
    public enum Source { LOCAL, AI }
```

区分本地规则与模型来源，界面不能把回退结果标成 AI。

## 第 12 行

```java
    public final String id,profileSignature,note;
```

唯一计划 ID、生成时档案签名、说明文本。

## 第 13 行

```java
    public final long createdAt;
```

创建时的 Unix 毫秒时间，用于记录时刻。

## 第 14 行

```java
    public final Source source;
```

保存来源枚举。

## 第 15 行

```java
    public final List<DayPlan> days;
```

七天的只读日程列表；必须七天的条件由边界校验。

## 第 16 行

```java
    public WeekPlan(String id,long time,String signature,Source source,String note,List<DayPlan> days) {
```

构造器参数包含身份、时间、档案版本、来源、说明和日程。

## 第 17 行

```java
        this.id=id;createdAt=time;profileSignature=signature;this.source=source;this.note=note;
```

复制标量字段，this 用于区分同名参数。

## 第 18 行

```java
        this.days=Collections.unmodifiableList(new ArrayList<>(days));
```

先复制外部列表再包为只读；这里不逐项复制，深复制由 copyForNextWeek 明确完成。

## 第 19 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
    /** Prototype: deep copies every mutable aggregate boundary and assigns a fresh identity. */
```

源码注释，不参与执行。原型复制：复制日程与处方聚合边界，并赋予新计划身份，不复用原计划 ID。

## 第 21 行

```java
    public WeekPlan copyForNextWeek() {
```

声明复制下一周期的方法。这个周期是模板复制，不是日历预约。

## 第 22 行

```java
        List<DayPlan> copies=new ArrayList<>();for(DayPlan day:days)copies.add(day.copy());
```

新建列表，并为每一天及内部处方创建独立副本。

## 第 23 行

```java
        String copiedNote=note.startsWith("沿用上一周期")?note:"沿用上一周期 · "+note;
```

说明没有复制前缀才添加，防止每复制一次重复累积前缀。

## 第 24 行

```java
        return new WeekPlan(UUID.randomUUID().toString(),System.currentTimeMillis(),profileSignature,source,copiedNote.substring(0,Math.min(1200,copiedNote.length())),copies);
```

生成新 UUID、新创建时间；保留档案签名和来源；说明截到最多 1200 字符后创建新周计划。

## 第 25 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
    @Override public Iterator<DayPlan> iterator() {return days.iterator();}
```

返回内部只读列表的迭代器，使 for(DayPlan d:plan) 可用；不能用此迭代器删除元素。

## 第 27 行

```java
    @Override public void accept(PlanVisitor visitor) {visitor.visitWeek(this);for(DayPlan day:this)day.accept(visitor);}
```

先访问周根，再通过迭代器访问每一天，天节点再访问处方。

## 第 28 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
