# core/src/main/java/com/pulse/core/plan/ExerciseCatalog.java

不可变动作白名单。计划只保存 ID，并共享目录中的动作定义。每条目录数据按 Exercise 构造器参数顺序解释。

原文件 SHA-256：`9598ec5c97592d24a543e9eff60822271697cc6388d8a85060b2ce8b7dc1e09f`。行号仅对应此快照；修改源码后应重新核对。

共 42 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.Exercise;
```

导入类型命名空间 com.pulse.core.model.Exercise，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.model.UserProfile;
```

导入类型命名空间 com.pulse.core.model.UserProfile，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import static com.pulse.core.model.UserProfile.Equipment.*;
```

静态导入 com.pulse.core.model.UserProfile.Equipment.*，后面可直接写枚举项或断言方法名。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
/** Shared immutable exercise definitions (Flyweight). IDs are also the model's action whitelist. */
```

源码注释，不参与执行。不可变动作白名单。计划只保存 ID，并共享目录中的动作定义。每条目录数据按 Exercise 构造器参数顺序解释。

## 第 9 行

```java
public final class ExerciseCatalog {
```

定义 public final class ExerciseCatalog。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    private static final Map<String,Exercise> ITEMS;
```

唯一静态动作映射：键是 ID，值是共享 Exercise 对象。

## 第 11 行

```java
    static {
```

静态初始化块在类初始化时执行一次。

## 第 12 行

```java
        Map<String,Exercise> m=new LinkedHashMap<>();
```

LinkedHashMap 保持插入顺序，使界面顺序和同优先级排序稳定。

## 第 13 行

```java
        add(m,new Exercise("wall_push","靠墙俯卧撑","上肢",BODYWEIGHT,false,false,false,false,"身体保持直线，缓慢靠近墙面。","双手撑墙，与肩同宽。","屈肘让胸口靠近墙面。","呼气推回，避免耸肩。"));
```

创建并注册一个共享动作；稳定ID=wall_push；中文名=靠墙俯卧撑；部位=上肢；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=false；冲击=false；要领=身体保持直线，缓慢靠近墙面。；步骤依次为 双手撑墙，与肩同宽。 → 屈肘让胸口靠近墙面。 → 呼气推回，避免耸肩。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 14 行

```java
        add(m,new Exercise("pushup","跪姿俯卧撑","上肢",BODYWEIGHT,false,false,true,false,"收紧腹部，肘部自然向后。","双膝垫软垫，双手撑地。","缓慢屈肘降低身体。","推起时躯干保持稳定。"));
```

创建并注册一个共享动作；稳定ID=pushup；中文名=跪姿俯卧撑；部位=上肢；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=收紧腹部，肘部自然向后。；步骤依次为 双膝垫软垫，双手撑地。 → 缓慢屈肘降低身体。 → 推起时躯干保持稳定。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 15 行

```java
        add(m,new Exercise("squat","自重深蹲","下肢",BODYWEIGHT,false,true,true,false,"在无痛范围内下蹲，不追求深度。","双脚与肩同宽。","髋部向后坐，膝盖沿脚尖方向。","脚掌稳定发力站起。"));
```

创建并注册一个共享动作；稳定ID=squat；中文名=自重深蹲；部位=下肢；器械=BODYWEIGHT；是否计时=false；膝负荷=true；背负荷=true；冲击=false；要领=在无痛范围内下蹲，不追求深度。；步骤依次为 双脚与肩同宽。 → 髋部向后坐，膝盖沿脚尖方向。 → 脚掌稳定发力站起。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 16 行

```java
        add(m,new Exercise("chair_squat","椅子坐站","下肢",BODYWEIGHT,false,true,false,false,"使用靠墙的稳固椅子。","坐在固定椅子前缘。","双脚踩稳，身体微向前。","缓慢站起再坐下。"));
```

创建并注册一个共享动作；稳定ID=chair_squat；中文名=椅子坐站；部位=下肢；器械=BODYWEIGHT；是否计时=false；膝负荷=true；背负荷=false；冲击=false；要领=使用靠墙的稳固椅子。；步骤依次为 坐在固定椅子前缘。 → 双脚踩稳，身体微向前。 → 缓慢站起再坐下。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 17 行

```java
        add(m,new Exercise("calf_raise","站姿提踵","下肢",BODYWEIGHT,false,false,false,false,"扶稳墙面，脚跟缓慢升降。","双脚平行站立。","扶墙保持平衡，抬起脚跟。","缓慢落回，不弹震。"));
```

创建并注册一个共享动作；稳定ID=calf_raise；中文名=站姿提踵；部位=下肢；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=false；冲击=false；要领=扶稳墙面，脚跟缓慢升降。；步骤依次为 双脚平行站立。 → 扶墙保持平衡，抬起脚跟。 → 缓慢落回，不弹震。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 18 行

```java
        add(m,new Exercise("side_leg","站姿侧抬腿","下肢",BODYWEIGHT,false,false,false,false,"扶稳支撑物，左右交替完成总次数。","侧身扶墙站稳。","一侧腿缓慢向外抬。","保持骨盆稳定，交替两侧。"));
```

创建并注册一个共享动作；稳定ID=side_leg；中文名=站姿侧抬腿；部位=下肢；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=false；冲击=false；要领=扶稳支撑物，左右交替完成总次数。；步骤依次为 侧身扶墙站稳。 → 一侧腿缓慢向外抬。 → 保持骨盆稳定，交替两侧。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 19 行

```java
        add(m,new Exercise("bridge","臀桥","下肢",BODYWEIGHT,false,false,true,false,"抬起到躯干与大腿接近直线。","屈膝仰卧，双脚踩地。","收紧臀部，缓慢抬髋。","避免腰部过度后伸。"));
```

创建并注册一个共享动作；稳定ID=bridge；中文名=臀桥；部位=下肢；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=抬起到躯干与大腿接近直线。；步骤依次为 屈膝仰卧，双脚踩地。 → 收紧臀部，缓慢抬髋。 → 避免腰部过度后伸。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 20 行

```java
        add(m,new Exercise("dead_bug","死虫式","核心",BODYWEIGHT,false,false,true,false,"腰部自然稳定，左右交替完成总次数。","仰卧，抬起双臂双腿。","对侧手脚缓慢伸展。","回到起点，再换另一侧。"));
```

创建并注册一个共享动作；稳定ID=dead_bug；中文名=死虫式；部位=核心；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=腰部自然稳定，左右交替完成总次数。；步骤依次为 仰卧，抬起双臂双腿。 → 对侧手脚缓慢伸展。 → 回到起点，再换另一侧。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 21 行

```java
        add(m,new Exercise("bird_dog","鸟狗式","核心",BODYWEIGHT,false,true,true,false,"保持躯干稳定，左右交替。","四点支撑，膝盖下垫软垫。","伸展对侧手脚。","停顿后收回，换边。"));
```

创建并注册一个共享动作；稳定ID=bird_dog；中文名=鸟狗式；部位=核心；器械=BODYWEIGHT；是否计时=false；膝负荷=true；背负荷=true；冲击=false；要领=保持躯干稳定，左右交替。；步骤依次为 四点支撑，膝盖下垫软垫。 → 伸展对侧手脚。 → 停顿后收回，换边。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 22 行

```java
        add(m,new Exercise("standing_core","站姿交替抬膝","核心",BODYWEIGHT,false,false,false,false,"小幅度抬膝，保持自然呼吸。","扶墙站稳。","缓慢交替抬膝。","保持躯干竖直，不憋气。"));
```

创建并注册一个共享动作；稳定ID=standing_core；中文名=站姿交替抬膝；部位=核心；器械=BODYWEIGHT；是否计时=false；膝负荷=false；背负荷=false；冲击=false；要领=小幅度抬膝，保持自然呼吸。；步骤依次为 扶墙站稳。 → 缓慢交替抬膝。 → 保持躯干竖直，不憋气。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 23 行

```java
        add(m,new Exercise("march","原地轻踏步","有氧",BODYWEIGHT,true,false,false,false,"轻落地，以能正常说话的强度进行。","身体直立，双脚交替踏步。","双臂自然摆动。","保持舒适呼吸，必要时减速。"));
```

创建并注册一个共享动作；稳定ID=march；中文名=原地轻踏步；部位=有氧；器械=BODYWEIGHT；是否计时=true；膝负荷=false；背负荷=false；冲击=false；要领=轻落地，以能正常说话的强度进行。；步骤依次为 身体直立，双脚交替踏步。 → 双臂自然摆动。 → 保持舒适呼吸，必要时减速。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 24 行

```java
        add(m,new Exercise("step_touch","左右侧点步","有氧",BODYWEIGHT,true,false,false,false,"小步侧移，膝关节自然放松。","向一侧轻迈一步。","另一脚跟近轻点地面。","左右交替，保持低冲击。"));
```

创建并注册一个共享动作；稳定ID=step_touch；中文名=左右侧点步；部位=有氧；器械=BODYWEIGHT；是否计时=true；膝负荷=false；背负荷=false；冲击=false；要领=小步侧移，膝关节自然放松。；步骤依次为 向一侧轻迈一步。 → 另一脚跟近轻点地面。 → 左右交替，保持低冲击。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 25 行

```java
        add(m,new Exercise("jumping_jack","开合跳","有氧",BODYWEIGHT,true,true,true,true,"轻柔落地，膝盖不适时停止。","站立准备。","轻跳向外打开双脚并抬臂。","跳回起点，控制节奏。"));
```

创建并注册一个共享动作；稳定ID=jumping_jack；中文名=开合跳；部位=有氧；器械=BODYWEIGHT；是否计时=true；膝负荷=true；背负荷=true；冲击=true；要领=轻柔落地，膝盖不适时停止。；步骤依次为 站立准备。 → 轻跳向外打开双脚并抬臂。 → 跳回起点，控制节奏。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 26 行

```java
        add(m,new Exercise("arm_circle","站姿肩部绕环","活动度",BODYWEIGHT,true,false,false,false,"小幅度、慢速绕环，避免疼痛范围。","自然站立。","双臂向两侧打开到舒适位置。","缓慢绕小圈，再换方向。"));
```

创建并注册一个共享动作；稳定ID=arm_circle；中文名=站姿肩部绕环；部位=活动度；器械=BODYWEIGHT；是否计时=true；膝负荷=false；背负荷=false；冲击=false；要领=小幅度、慢速绕环，避免疼痛范围。；步骤依次为 自然站立。 → 双臂向两侧打开到舒适位置。 → 缓慢绕小圈，再换方向。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 27 行

```java
        add(m,new Exercise("chest_open","站姿开胸","活动度",BODYWEIGHT,true,false,false,false,"保持肩部放松，自然呼吸。","站直，双手放在身体两侧。","手臂轻向后打开。","在舒适幅度保持，不用力拉伸。"));
```

创建并注册一个共享动作；稳定ID=chest_open；中文名=站姿开胸；部位=活动度；器械=BODYWEIGHT；是否计时=true；膝负荷=false；背负荷=false；冲击=false；要领=保持肩部放松，自然呼吸。；步骤依次为 站直，双手放在身体两侧。 → 手臂轻向后打开。 → 在舒适幅度保持，不用力拉伸。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 28 行

```java
        add(m,new Exercise("ankle","坐姿踝泵","活动度",BODYWEIGHT,true,false,false,false,"坐稳后缓慢活动踝关节。","坐在稳固椅子上。","脚尖缓慢勾起，再向下点。","两侧交替，自然呼吸。"));
```

创建并注册一个共享动作；稳定ID=ankle；中文名=坐姿踝泵；部位=活动度；器械=BODYWEIGHT；是否计时=true；膝负荷=false；背负荷=false；冲击=false；要领=坐稳后缓慢活动踝关节。；步骤依次为 坐在稳固椅子上。 → 脚尖缓慢勾起，再向下点。 → 两侧交替，自然呼吸。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 29 行

```java
        add(m,new Exercise("db_row","支撑哑铃划船","上肢",DUMBBELL,false,false,true,false,"选用能轻松控制的重量，左右交替。","一手扶稳固支撑。","另一手持哑铃向髋部提拉。","缓慢还原，避免扭转腰部。"));
```

创建并注册一个共享动作；稳定ID=db_row；中文名=支撑哑铃划船；部位=上肢；器械=DUMBBELL；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=选用能轻松控制的重量，左右交替。；步骤依次为 一手扶稳固支撑。 → 另一手持哑铃向髋部提拉。 → 缓慢还原，避免扭转腰部。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 30 行

```java
        add(m,new Exercise("db_curl","站姿哑铃弯举","上肢",DUMBBELL,false,false,false,false,"肘部贴近身体，不借力甩动。","双手持轻哑铃自然站立。","屈肘向上提起。","缓慢放下，保持手腕中立。"));
```

创建并注册一个共享动作；稳定ID=db_curl；中文名=站姿哑铃弯举；部位=上肢；器械=DUMBBELL；是否计时=false；膝负荷=false；背负荷=false；冲击=false；要领=肘部贴近身体，不借力甩动。；步骤依次为 双手持轻哑铃自然站立。 → 屈肘向上提起。 → 缓慢放下，保持手腕中立。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 31 行

```java
        add(m,new Exercise("db_press","坐姿哑铃推举","上肢",DUMBBELL,false,false,true,false,"使用稳固有靠背的座椅和轻重量。","坐稳，哑铃置于肩部两侧。","在舒适范围向上推起。","缓慢回落，避免憋气。"));
```

创建并注册一个共享动作；稳定ID=db_press；中文名=坐姿哑铃推举；部位=上肢；器械=DUMBBELL；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=使用稳固有靠背的座椅和轻重量。；步骤依次为 坐稳，哑铃置于肩部两侧。 → 在舒适范围向上推起。 → 缓慢回落，避免憋气。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 32 行

```java
        add(m,new Exercise("lat_pull","高位下拉","上肢",GYM,false,false,true,false,"动作缓慢，避免向后猛仰。","调整座位，握住下拉杆。","向胸前方向平稳下拉。","控制还原，保持肩部放松。"));
```

创建并注册一个共享动作；稳定ID=lat_pull；中文名=高位下拉；部位=上肢；器械=GYM；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=动作缓慢，避免向后猛仰。；步骤依次为 调整座位，握住下拉杆。 → 向胸前方向平稳下拉。 → 控制还原，保持肩部放松。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 33 行

```java
        add(m,new Exercise("cable_row","坐姿器械划船","上肢",GYM,false,false,true,false,"保持自然脊柱位置。","调整器械并坐稳。","握把向腹部平稳拉回。","缓慢还原，不耸肩。"));
```

创建并注册一个共享动作；稳定ID=cable_row；中文名=坐姿器械划船；部位=上肢；器械=GYM；是否计时=false；膝负荷=false；背负荷=true；冲击=false；要领=保持自然脊柱位置。；步骤依次为 调整器械并坐稳。 → 握把向腹部平稳拉回。 → 缓慢还原，不耸肩。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 34 行

```java
        add(m,new Exercise("leg_curl","坐姿腿弯举","下肢",GYM,false,true,false,false,"按器械说明调整，使用轻重量。","调整座位与挡垫。","屈膝缓慢带动器械。","控制还原，不锁死关节。"));
```

创建并注册一个共享动作；稳定ID=leg_curl；中文名=坐姿腿弯举；部位=下肢；器械=GYM；是否计时=false；膝负荷=true；背负荷=false；冲击=false；要领=按器械说明调整，使用轻重量。；步骤依次为 调整座位与挡垫。 → 屈膝缓慢带动器械。 → 控制还原，不锁死关节。。布尔参数顺序与 Exercise 构造器对应；训练处方仅引用该 ID。

## 第 35 行

```java
        ITEMS=Collections.unmodifiableMap(m);
```

初始化完成后包装为只读映射，不再允许新增或删除动作。

## 第 36 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 37 行

```java
    private static void add(Map<String,Exercise> m,Exercise e){m.put(e.id,e);}
```

根据动作 ID 插入映射；重复 ID 会覆盖，所以维护目录时应保证唯一。

## 第 38 行

```java
    public static Exercise get(String id){Exercise e=ITEMS.get(id);if(e==null)throw new IllegalArgumentException("未知动作："+id);return e;}
```

按 ID 查询共享对象，未知 ID 抛异常，阻止模型编造动作。

## 第 39 行

```java
    public static List<Exercise> all(){return Collections.unmodifiableList(new ArrayList<>(ITEMS.values()));}
```

将所有动作复制到只读列表，外部不能改目录集合。

## 第 40 行

```java
    public static List<Exercise> allowed(UserProfile p){List<Exercise> r=new ArrayList<>();for(Exercise e:ITEMS.values())if(e.isAllowed(p))r.add(e);return r;}
```

遍历目录，保留 isAllowed(p) 为 true 的动作，生成新的筛选结果列表。

## 第 41 行

```java
    private ExerciseCatalog(){}
```

工具目录不允许实例化。

## 第 42 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
