# core/src/main/java/com/pulse/core/plan/ExerciseQuery.java

将简单搜索语言转换为表达式树；仅做文本匹配，不执行用户输入的 Java。

原文件 SHA-256：`681f75e3734dbe503118206aaf0d412254f2ca0a8f363b9e92b0ef2bcd8920f6`。行号仅对应此快照；修改源码后应重新核对。

共 37 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.Exercise;
```

导入类型命名空间 com.pulse.core.model.Exercise，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import java.util.Locale;
```

导入类型命名空间 java.util.Locale，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Interpreter grammar: or := and ('|' and)*; and := term ('&' term)*;
```

源码注释，不参与执行。定义文法：OR 是多个 AND 分支用 | 连接；每个 AND 是多个 term 用 & 连接，因此 AND 优先。

## 第 6 行

```java
 * term := free-text | group:value | equipment:value. No executable expressions. */
```

源码注释，不参与执行。term 支持自由文本、group:值、equipment:值。这不是可以执行任意程序的表达式。

## 第 7 行

```java
public final class ExerciseQuery {
```

定义 public final class ExerciseQuery。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 8 行

```java
    public interface Expression {boolean matches(Exercise e);}
```

表达式统一接口：输入一个动作，返回匹配与否。

## 第 9 行

```java
    private static final class Term implements Expression {
```

单个条件表达式，例如 group:上肢。

## 第 10 行

```java
        private final String key,value;
```

key 为条件种类，value 为待匹配文本。

## 第 11 行

```java
        Term(String text){String[] pair=text.trim().split(":",2);key=pair.length==2?pair[0].trim():"text";value=pair[pair.length-1].trim().toLowerCase(Locale.ROOT);}
```

按第一个冒号最多切两段；无冒号时 key=text；去空白并以固定区域转小写。

## 第 12 行

```java
        public boolean matches(Exercise e){switch(key){case "group":return e.group.contains(value);case "equipment":return e.equipmentLabel.contains(value);default:return (e.name+e.group+e.equipmentLabel).toLowerCase(Locale.ROOT).contains(value);}}
```

group 匹配部位，equipment 匹配器械中文名，其他键退到名称+部位+器械文本匹配；contains 是子串搜索。

## 第 13 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 14 行

```java
    private static final class And implements Expression {
```

定义“同时满足”节点。

## 第 15 行

```java
        private final Expression left,right;And(Expression l,Expression r){left=l;right=r;}
```

保存左、右子表达式，构造器接入两节点。

## 第 16 行

```java
        public boolean matches(Exercise e){return left.matches(e)&&right.matches(e);}
```

只有左右都匹配才为 true；&& 在左侧 false 时不计算右侧。

## 第 17 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 18 行

```java
    private static final class Or implements Expression {
```

定义“至少满足一个”节点。

## 第 19 行

```java
        private final Expression left,right;Or(Expression l,Expression r){left=l;right=r;}
```

保存 OR 左右子表达式。

## 第 20 行

```java
        public boolean matches(Exercise e){return left.matches(e)||right.matches(e);}
```

任一侧匹配即 true；|| 在左侧 true 时短路。

## 第 21 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 22 行

```java
    public static Expression parse(String text){
```

解析搜索文本，返回可重复用于不同动作的表达式。

## 第 23 行

```java
        if(text==null||text.trim().isEmpty())return e->true;
```

空输入返回恒 true 的 Lambda，因此显示所有符合其他筛选的动作。

## 第 24 行

```java
        if(text.length()>160)throw new IllegalArgumentException("搜索内容最多 160 字");
```

限制输入最多 160 字符。

## 第 25 行

```java
        Expression result=null;
```

初始化总表达式，null 表示尚无分支。

## 第 26 行

```java
        for(String clause:text.split("\\|",-1)){
```

先按竖线拆 OR 分支；\| 中反斜杠让竖线作为普通字符，-1 保留末尾空段以发现残缺语法。

## 第 27 行

```java
            Expression branch=null;
```

初始化当前 OR 分支里的 AND 表达式。

## 第 28 行

```java
            for(String token:clause.split("&",-1)){
```

在该分支内按 & 切分具体条件。

## 第 29 行

```java
                if(token.trim().isEmpty())throw new IllegalArgumentException("筛选条件不完整");
```

空条件被拒绝，例如“上肢 &”不会被当成有效查询。

## 第 30 行

```java
                Expression term=new Term(token);branch=branch==null?term:new And(branch,term);
```

首条件直接作为分支，后续逐一包装为 And 树。

## 第 31 行

```java
            }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 32 行

```java
            result=result==null?branch:new Or(result,branch);
```

将已解析 AND 分支逐一用 Or 接起来，因此 AND 优先于 OR。

## 第 33 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 34 行

```java
        return result;
```

返回最终表达式树；调用 matches 才真正拿动作做筛选。

## 第 35 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 36 行

```java
    private ExerciseQuery(){}
```

工具类禁止实例化。

## 第 37 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
