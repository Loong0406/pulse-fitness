# core/src/main/java/com/pulse/core/plan/GoalStrategy.java

目标策略接口，允许生成流程替换每组次数、动作优先级和训练标题。

原文件 SHA-256：`df91e64b768ceed1667df6d61d75cb812927314af1ad0dc057cc0efb781eda83`。行号仅对应此快照；修改源码后应重新核对。

共 7 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.Exercise;
```

导入类型命名空间 com.pulse.core.model.Exercise，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
public interface GoalStrategy {
```

定义 public interface GoalStrategy。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 4 行

```java
    int repetitions();
```

返回计次动作的建议每组次数。

## 第 5 行

```java
    int priority(Exercise exercise);
```

返回某动作的排序权重，数值越小优先级越高。

## 第 6 行

```java
    String title();
```

返回此目标的中文训练标题。

## 第 7 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
