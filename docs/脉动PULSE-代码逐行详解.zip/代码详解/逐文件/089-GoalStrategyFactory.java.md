# core/src/main/java/com/pulse/core/plan/GoalStrategyFactory.java

简单工厂在有限的三种目标之间选择策略；策略负责具体算法。

原文件 SHA-256：`acfd8d042a864fc78978991f0ede67c1818eedab2da364a054d2c402f9cd7893`。行号仅对应此快照；修改源码后应重新核对。

共 25 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 4 行

```java
/** Simple Factory selects the small, fixed set of supported goals. */
```

源码注释，不参与执行。简单工厂在有限的三种目标之间选择策略；策略负责具体算法。

## 第 5 行

```java
public final class GoalStrategyFactory {
```

定义 public final class GoalStrategyFactory。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 6 行

```java
    public static GoalStrategy create(UserProfile.Goal goal){
```

接收 Goal，返回 GoalStrategy 接口，调用方无需知道具体策略类名。

## 第 7 行

```java
        switch(goal){case FAT_LOSS:return new FatLoss();case STRENGTH:return new Strength();default:return new Wellbeing();}
```

减脂返回 FatLoss，力量返回 Strength，其余返回 Wellbeing；新增目标时应检查该分支。

## 第 8 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 9 行

```java
    public static final class FatLoss implements GoalStrategy {
```

减脂策略实现。

## 第 10 行

```java
        public int repetitions(){return 12;}
```

减脂计次动作每组 12 次，计时动作在生成器中另设秒数。

## 第 11 行

```java
        public int priority(Exercise e){return e.group.equals("有氧")?0:e.group.equals("活动度")?2:1;}
```

有氧权重 0，普通力量类权重 1，活动度权重 2，排序后有氧靠前。

## 第 12 行

```java
        public String title(){return "低冲击燃动";}
```

返回减脂训练标题。

## 第 13 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 14 行

```java
    public static final class Strength implements GoalStrategy {
```

力量策略实现。

## 第 15 行

```java
        public int repetitions(){return 10;}
```

力量每组 10 次。

## 第 16 行

```java
        public int priority(Exercise e){return e.group.equals("有氧")||e.group.equals("活动度")?2:0;}
```

有氧或活动度权重 2，其余权重 0，优先普通力量动作。

## 第 17 行

```java
        public String title(){return "基础力量";}
```

返回力量训练标题。

## 第 18 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 19 行

```java
    public static final class Wellbeing implements GoalStrategy {
```

体能策略实现。

## 第 20 行

```java
        public int repetitions(){return 10;}
```

体能计次动作每组 10 次。

## 第 21 行

```java
        public int priority(Exercise e){return e.group.equals("活动度")?0:1;}
```

活动度权重 0，其余为 1。

## 第 22 行

```java
        public String title(){return "全身唤醒";}
```

返回体能训练标题。

## 第 23 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 24 行

```java
    private GoalStrategyFactory(){}
```

私有构造器阻止把工具工厂当实例使用。

## 第 25 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
