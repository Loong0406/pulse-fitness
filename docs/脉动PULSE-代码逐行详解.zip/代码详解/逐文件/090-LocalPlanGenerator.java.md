# core/src/main/java/com/pulse/core/plan/LocalPlanGenerator.java

离线规则生成器。它能依据档案筛动作和控制负荷，不调用模型，不等同于医学个性化处方。

原文件 SHA-256：`a7e9468533eda35951904f55fb35949d13165b11a169dd8d8585b63b04144766`。行号仅对应此快照；修改源码后应重新核对。

共 33 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 6 行

```java
public final class LocalPlanGenerator extends PlanGenerationTemplate {
```

定义 public final class LocalPlanGenerator extends PlanGenerationTemplate。继承 PlanGenerationTemplate 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    @Override protected WeekPlan createCandidate(UserProfile p){
```

实现模板要求的“创建候选”步骤；完整 generate 流程在父类。

## 第 8 行

```java
        GoalStrategy strategy=GoalStrategyFactory.create(p.goal);
```

简单工厂根据目标创建可替换策略。

## 第 9 行

```java
        List<Exercise> allowed=ExerciseCatalog.allowed(p);
```

先按器械、膝背限制、冲击等筛出允许动作。

## 第 10 行

```java
        allowed.sort(Comparator.comparingInt(strategy::priority));
```

使用策略 priority 从小到大排序；方法引用相当于 e -> strategy.priority(e)。

## 第 11 行

```java
        Set<Integer> scheduled=new HashSet<>();for(int i=0;i<p.daysPerWeek;i++)scheduled.add(i*7/p.daysPerWeek);
```

用整数 i*7/天数把训练日分散到七天；每周 3 天得到索引 0、2、4。

## 第 12 行

```java
        List<DayPlan> days=new ArrayList<>();int trainingIndex=0;
```

准备七天结果列表；trainingIndex 只对训练日递增，用来改变动作起点。

## 第 13 行

```java
        for(int d=0;d<7;d++){
```

遍历周内 0–6 号日程。

## 第 14 行

```java
            List<Prescription> items=new ArrayList<>();
```

每天创建独立处方列表，恢复日保持空列表。

## 第 15 行

```java
            if(scheduled.contains(d)){
```

只有这一天在 scheduled 集合里才安排动作。

## 第 16 行

```java
                int targetCount=Math.min(5,2+(p.minutesPerSession-15)/8);
```

单次时间越多目标动作越多：15 分钟 2 个，30 分钟 3 个，最多 5 个；整数除法舍去小数。

## 第 17 行

```java
                int sets=p.experience==UserProfile.Experience.BEGINNER||p.age>=60||p.daysPerWeek>=4||p.minutesPerSession<20?2:3;
```

新手、至少 60 岁、高频或短时训练用 2 组，其余 3 组。|| 任一成立即可取 2。

## 第 18 行

```java
                for(int i=0;i<allowed.size()&&items.size()<targetCount;i++){
```

遍历允许动作，达到目标数量或已尝试所有动作就停止。

## 第 19 行

```java
                    Exercise e=allowed.get((i+trainingIndex*3)%allowed.size());
```

根据训练序号每次偏移 3 个位置，% 取余绕回列表开头；是动作轮换，不是严格的肌群恢复优化。

## 第 20 行

```java
                    // Separate consecutive-day emphasis and keep high-impact moves out of basic plans.
```

源码注释，不参与执行。注释表达轮换相邻训练重点并排除高冲击的意图；真实实现是按训练日偏移三动作，不是完整肌群恢复算法。

## 第 21 行

```java
                    if(e.impact)continue;
```

高冲击动作即使初筛允许，也不进入当前本地基础计划；continue 跳到下一次循环。

## 第 22 行

```java
                    Prescription rx=new Prescription(e.id,sets,e.timed?30:strategy.repetitions(),45);
```

新建处方：所选动作、组数、计时 30 秒或策略次数、休息 45 秒。

## 第 23 行

```java
                    items.add(rx);
```

暂时把处方放入今日列表。

## 第 24 行

```java
                    if(PlanStatisticsVisitor.minutes(new DayPlan(d,"",items))>p.minutesPerSession)items.remove(items.size()-1);
```

用访问者估时；超过用户时间预算就删刚加的一项。估时包含 480 秒热身放松。

## 第 25 行

```java
                }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
                trainingIndex++;
```

训练日计数加一，为下一训练日动作偏移和标题编号服务。

## 第 27 行

```java
            }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 28 行

```java
            days.add(new DayPlan(d,items.isEmpty()?"主动恢复":strategy.title()+" · "+(trainingIndex),items));
```

把今日加入七天表；无动作是主动恢复，否则用策略标题和训练序号。

## 第 29 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 30 行

```java
        String note="依据你的目标、器械、时间和动作限制匹配；每次含约 4 分钟热身与 4 分钟放松。保持能控制动作的强度，出现疼痛、胸闷或头晕时停止。";
```

固定说明文本，解释当前规则计划及热身放松安排。

## 第 31 行

```java
        return new WeekPlan(UUID.randomUUID().toString(),System.currentTimeMillis(),p.signature(),WeekPlan.Source.LOCAL,note,days);
```

新 UUID、当前日历毫秒、档案签名和 LOCAL 来源一起构成候选周计划，父类随后执行安全校验。

## 第 32 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
