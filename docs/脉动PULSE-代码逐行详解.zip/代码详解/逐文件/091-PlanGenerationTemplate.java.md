# core/src/main/java/com/pulse/core/plan/PlanGenerationTemplate.java

模板方法固定校验→候选→校验顺序，本地与远程实现只负责候选。

原文件 SHA-256：`56b2fc4f0a2f296e7c2dc9572467feea305c8cdba1030ed2faa648b0ba1f1f74`。行号仅对应此快照；修改源码后应重新核对。

共 14 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import com.pulse.core.validation.ProfileValidator;
```

导入类型命名空间 com.pulse.core.validation.ProfileValidator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Template Method keeps validation mandatory for local and remote implementations. */
```

源码注释，不参与执行。模板方法固定校验→候选→校验顺序，本地与远程实现只负责候选。

## 第 6 行

```java
public abstract class PlanGenerationTemplate implements PlanGenerator {
```

定义 public abstract class PlanGenerationTemplate implements PlanGenerator。实现 PlanGenerator 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    @Override public final WeekPlan generate(UserProfile profile) throws Exception {
```

final 禁止子类覆盖整个 generate，从而跳过两边校验；返回 WeekPlan，可抛异常。

## 第 8 行

```java
        ProfileValidator.validateForTraining(profile);
```

先检查档案能否用于自动训练。

## 第 9 行

```java
        WeekPlan candidate=createCandidate(profile);
```

调用子类 createCandidate，生成候选计划。

## 第 10 行

```java
        PlanSafety.validate(candidate,profile);
```

对候选执行结构、动作白名单、负荷、时间及档案匹配校验。

## 第 11 行

```java
        return candidate;
```

只有全部通过才返回候选。

## 第 12 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 13 行

```java
    protected abstract WeekPlan createCandidate(UserProfile profile) throws Exception;
```

抽象扩展点由子类实现，protected 让子类可访问而非面向页面公开。

## 第 14 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
