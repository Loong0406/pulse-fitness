# core/src/main/java/com/pulse/core/plan/PlanGenerator.java

所有计划来源共用接口。

原文件 SHA-256：`21ea9f99518dd4d942f94d14c107e2c131ea4bd85cfabdcd3c8e1874fde3e706`。行号仅对应此快照；修改源码后应重新核对。

共 3 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
public interface PlanGenerator { WeekPlan generate(UserProfile profile) throws Exception; }
```

任何生成器都接收 UserProfile 并返回 WeekPlan；throws Exception 允许网络生成器传播失败。
