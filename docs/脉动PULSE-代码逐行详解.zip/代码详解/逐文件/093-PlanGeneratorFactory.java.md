# core/src/main/java/com/pulse/core/plan/PlanGeneratorFactory.java

工厂方法创建生成器，公共安全入口附加装饰器。

原文件 SHA-256：`3518b795dd67ed7b01fcdf2fbd15313b1e8fd197c3024e90daf7abdbf4b44a17`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
/** Factory Method: adding a backend requires a new creator, not changing existing creators. */
```

源码注释，不参与执行。工厂方法创建生成器，公共安全入口附加装饰器。

## 第 4 行

```java
public abstract class PlanGeneratorFactory {
```

定义 public abstract class PlanGeneratorFactory。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 5 行

```java
    protected abstract PlanGenerator createGenerator();
```

由子类决定创建哪一种具体生成器。

## 第 6 行

```java
    public final PlanGenerator createSafeGenerator(){return new SafePlanGeneratorDecorator(createGenerator());}
```

先创建具体生成器，再包一层 SafePlanGeneratorDecorator；final 保证统一包装流程。

## 第 7 行

```java
    public static final class Local extends PlanGeneratorFactory {
```

本地生成器的具体工厂。

## 第 8 行

```java
        @Override protected PlanGenerator createGenerator(){return new LocalPlanGenerator();}
```

工厂方法返回 LocalPlanGenerator；远程工厂在 Android 模块中独立实现。

## 第 9 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 10 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
