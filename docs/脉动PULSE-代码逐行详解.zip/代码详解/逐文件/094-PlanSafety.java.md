# core/src/main/java/com/pulse/core/plan/PlanSafety.java

所有候选计划都必须经过的边界检查；不相信来自网络的任意动作或任意负荷。

原文件 SHA-256：`ac7652535c2dc6d8d546a7f8a834ce67778387c4952b43f2d9a85fe1eb0d58f8`。行号仅对应此快照；修改源码后应重新核对。

共 35 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 6 行

```java
/** Model output is untrusted. Only catalog exercises and bounded loads can reach the UI. */
```

源码注释，不参与执行。所有候选计划都必须经过的边界检查；不相信来自网络的任意动作或任意负荷。

## 第 7 行

```java
public final class PlanSafety {
```

定义 public final class PlanSafety。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 8 行

```java
    public static void validate(WeekPlan plan,UserProfile p){
```

校验 plan 是否适合档案 p，失败抛异常，成功无返回值。

## 第 9 行

```java
        if(plan==null||plan.days==null||plan.days.size()!=7||plan.source==null||plan.id==null||plan.id.length()>128)bad("计划格式无效");
```

要求计划、天表、来源、ID 存在，恰好 7 天，ID 最多 128 字符；短路避免空引用。

## 第 10 行

```java
        if(!p.signature().equals(plan.profileSignature))bad("计划与当前档案不匹配，请重新生成");
```

档案签名必须完全一致，防止把旧资料生成的计划用于新资料。

## 第 11 行

```java
        if(plan.note==null||plan.note.length()>1200)bad("计划说明过长");
```

说明不允许 null 且最多 1200 字符。

## 第 12 行

```java
        int trainingDays=0;
```

初始化训练日数量计数器。

## 第 13 行

```java
        for(int i=0;i<7;i++){
```

按七天的预定顺序检查。

## 第 14 行

```java
            DayPlan day=plan.days.get(i);
```

取出当前索引的日计划。

## 第 15 行

```java
            if(day==null||day.dayIndex!=i||day.title==null||day.title.length()>48||day.exercises==null)bad("日程格式无效");
```

检查天对象、索引、标题长度及动作列表是否有效；dayIndex 必须与位置一致。

## 第 16 行

```java
            if(day.isRest())continue;
```

恢复日不再检查动作负荷，直接检查下一天。

## 第 17 行

```java
            trainingDays++;
```

非恢复日计入训练天数。

## 第 18 行

```java
            if(day.exercises.size()<2||day.exercises.size()>6)bad("每次需安排 2–6 个动作");
```

每个训练日必须 2–6 个动作。

## 第 19 行

```java
            Set<String> ids=new HashSet<>();int totalSets=0;
```

使用集合检查重复动作 ID，用 totalSets 累加训练量。

## 第 20 行

```java
            for(Prescription rx:day.exercises){
```

逐个检查动作处方。

## 第 21 行

```java
                if(rx==null)bad("动作缺失");
```

空处方立即拒绝。

## 第 22 行

```java
                Exercise e=ExerciseCatalog.get(rx.exerciseId);
```

从目录取动作；未知 ID 会由目录直接抛异常。

## 第 23 行

```java
                if(!e.isAllowed(p)||!ids.add(e.id))bad("动作不符合档案限制或重复");
```

要求动作适合此档案，且本日没有重复；Set.add 返回 false 表示已经存在。

## 第 24 行

```java
                int maxSets=(p.experience==UserProfile.Experience.BEGINNER||p.age>=60||p.daysPerWeek>=4)?2:4;
```

新手、至少 60 岁或每周至少 4 天时每动作最多 2 组，其余最多 4 组。

## 第 25 行

```java
                if(rx.sets<1||rx.sets>maxSets||rx.restSeconds<30||rx.restSeconds>120)bad("组数或休息超出范围");
```

至少 1 组、不能超过上限；休息必须 30–120 秒。

## 第 26 行

```java
                if((e.timed&&(rx.amount<15||rx.amount>60))||(!e.timed&&(rx.amount<6||rx.amount>15)))bad("次数或时长超出范围");
```

计时动作 15–60 秒；计次动作 6–15 次，按 timed 选择对应边界。

## 第 27 行

```java
                totalSets+=rx.sets;
```

累加本日组数。

## 第 28 行

```java
            }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 29 行

```java
            if(totalSets>18||PlanStatisticsVisitor.minutes(day)>p.minutesPerSession)bad("训练量超出可用时间");
```

每日最多 18 组，且估计分钟不能超过档案的单次时间预算。

## 第 30 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 31 行

```java
        if(trainingDays!=p.daysPerWeek)bad("训练天数与档案不一致");
```

实际训练日数必须等于档案要求；不能悄悄减少或增加。

## 第 32 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
    private static void bad(String m){throw new IllegalArgumentException(m);}
```

集中把错误提示抛为参数异常。

## 第 34 行

```java
    private PlanSafety(){}
```

工具类无需实例化。

## 第 35 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
