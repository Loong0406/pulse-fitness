# core/src/main/java/com/pulse/core/plan/PlanStatisticsVisitor.java

用访问者统计训练日、动作数、组数与估计秒数；它是估算，不读取手表或摄像头。

原文件 SHA-256：`363725dfacc0e96e687b2dd7505a5bab061f7c11a398a1633b42efd209234eaa`。行号仅对应此快照；修改源码后应重新核对。

共 15 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Visitor: a new aggregate operation without changing week/day/prescription classes. */
```

源码注释，不参与执行。用访问者统计训练日、动作数、组数与估计秒数；它是估算，不读取手表或摄像头。

## 第 6 行

```java
public final class PlanStatisticsVisitor implements PlanVisitor {
```

定义 public final class PlanStatisticsVisitor implements PlanVisitor。实现 PlanVisitor 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    public int trainingDays,exerciseCount,totalSets,estimatedSeconds;
```

四个累加器默认 0；每次独立统计应新建访问者，重复访问会继续累加。

## 第 8 行

```java
    @Override public void visitWeek(WeekPlan week){}
```

周根本身没有额外时间，留空是因为具体统计由天和处方贡献。

## 第 9 行

```java
    @Override public void visitDay(DayPlan day){if(!day.isRest()){trainingDays++;estimatedSeconds+=480;}}
```

非恢复日增加 1 个训练日，并加 480 秒，也就是 4 分钟热身加 4 分钟放松。

## 第 10 行

```java
    @Override public void visitExercise(Prescription p){
```

开始处理一个动作处方。

## 第 11 行

```java
        Exercise e=ExerciseCatalog.get(p.exerciseId);exerciseCount++;totalSets+=p.sets;
```

查动作类型，动作数加一，累计处方组数。

## 第 12 行

```java
        estimatedSeconds+=p.sets*((e.timed?p.amount:p.amount*3)+p.restSeconds);
```

计时直接用 amount 秒，计次按每次 3 秒估计；每组再加休息，乘组数。这里连最后一组也估入休息，属于保守预算。

## 第 13 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 14 行

```java
    public static int minutes(DayPlan day){PlanStatisticsVisitor v=new PlanStatisticsVisitor();day.accept(v);return (v.estimatedSeconds+59)/60;}
```

新建统计器，访问单日，再将秒数向上取整为分钟；例如 901 秒得到 16 分钟。

## 第 15 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
