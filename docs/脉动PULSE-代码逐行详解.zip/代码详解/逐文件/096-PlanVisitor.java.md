# core/src/main/java/com/pulse/core/plan/PlanVisitor.java

访问者契约：对稳定的周→天→处方结构增加统计等操作。

原文件 SHA-256：`938cc4359d8e3bf45518b5ea7a498da22055b1274301313d50b2fef725093255`。行号仅对应此快照；修改源码后应重新核对。

共 9 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
public interface PlanVisitor {
```

定义 public interface PlanVisitor。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 6 行

```java
    void visitWeek(WeekPlan week);
```

声明处理周节点的操作。

## 第 7 行

```java
    void visitDay(DayPlan day);
```

声明处理天节点的操作。

## 第 8 行

```java
    void visitExercise(Prescription exercise);
```

声明处理动作处方叶子的操作。

## 第 9 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
