# core/src/main/java/com/pulse/core/plan/SafePlanGeneratorDecorator.java

给任意 PlanGenerator 增加统一校验；不要求被包装类继承模板。

原文件 SHA-256：`ee92c7f6dbf4232ec8491c05db4b774773ad14b48764aa011fcf8dcdd9e91934`。行号仅对应此快照；修改源码后应重新核对。

共 12 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.plan;
```

声明本文件所属包 com.pulse.core.plan；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import com.pulse.core.validation.ProfileValidator;
```

导入类型命名空间 com.pulse.core.validation.ProfileValidator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Decorator also protects third-party generators that do not extend the template. */
```

源码注释，不参与执行。给任意 PlanGenerator 增加统一校验；不要求被包装类继承模板。

## 第 6 行

```java
public final class SafePlanGeneratorDecorator implements PlanGenerator {
```

定义 public final class SafePlanGeneratorDecorator implements PlanGenerator。实现 PlanGenerator 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    private final PlanGenerator delegate;
```

保存被包装生成器引用。

## 第 8 行

```java
    public SafePlanGeneratorDecorator(PlanGenerator delegate){this.delegate=delegate;}
```

接收要包装的生成器，仍然对外实现相同接口。

## 第 9 行

```java
    @Override public WeekPlan generate(UserProfile p)throws Exception{
```

对外的生成方法，调用方无需知道里面是否包装。

## 第 10 行

```java
        ProfileValidator.validateForTraining(p);WeekPlan result=delegate.generate(p);PlanSafety.validate(result,p);return result;
```

依次检查档案、调用原生成器、检查结果、返回；即使第三方实现没用模板也会被检查。模板实现被包装时会重复校验，这是当前代码的实际行为。

## 第 11 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 12 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
