# core/src/main/java/com/pulse/core/session/WorkoutSession.java

纯 Java 训练状态机及快照，不认识 Android。界面告诉它过去几秒、用户点了什么，它负责决定状态变化。

原文件 SHA-256：`b9f592ced0e7093ec9e30a53db9ecf384109dbaab2443af490f3dd2702345878`。行号仅对应此快照；修改源码后应重新核对。

共 83 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.session;
```

声明本文件所属包 com.pulse.core.session；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.plan.ExerciseCatalog;
```

导入类型命名空间 com.pulse.core.plan.ExerciseCatalog，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.util.UUID;
```

导入类型命名空间 java.util.UUID，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 7 行

```java
/** State + Memento. UI owns the clock; this class has no Android or wall-clock dependency. */
```

源码注释，不参与执行。纯 Java 训练状态机及快照，不认识 Android。界面告诉它过去几秒、用户点了什么，它负责决定状态变化。

## 第 8 行

```java
public final class WorkoutSession {
```

定义 public final class WorkoutSession。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 9 行

```java
    public static final class Snapshot {
```

可序列化快照数据容器，字段可变以便 Gson 恢复；本身不包含行为。

## 第 10 行

```java
        public String id,title,phase,resumePhase;
```

会话 ID、标题、当前状态名、暂停前状态名。

## 第 11 行

```java
        public int exerciseIndex,setIndex,remainingSeconds,activeSeconds,completedSets;
```

动作位置、组位置、阶段剩余秒、活跃总秒、完成组数；索引从 0 开始。

## 第 12 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 13 行

```java
    private interface Phase {
```

私有状态接口，只有会话内部使用。

## 第 14 行

```java
        String name();String action();void primary();void tick(int seconds);
```

每个状态提供标识、按钮文字、主操作、时间推进四种能力。

## 第 15 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 16 行

```java
    private abstract class Base implements Phase {
```

抽象默认状态基类，内部类可直接访问外部会话字段。

## 第 17 行

```java
        public void tick(int seconds){}
```

默认 tick 什么也不做；Running 等状态继承它，总时长仍在会话外层 tick 累加。

## 第 18 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 19 行

```java
    private final class Warmup extends Base {
```

热身状态。

## 第 20 行

```java
        public String name(){return "WARMUP";}public String action(){return "热身完成，开始训练";}
```

返回 WARMUP 与热身完成按钮文案；标识用于快照恢复，文案用于 UI。

## 第 21 行

```java
        public void primary(){remainingSeconds=0;phase=new Running();}
```

用户确认热身完成，清剩余秒并进入 Running，不会自动等待四分钟结束。

## 第 22 行

```java
        public void tick(int s){remainingSeconds=Math.max(0,remainingSeconds-s);}
```

热身时间只倒计时到 0，不自动开始训练；Math.max 防止负值。

## 第 23 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 24 行

```java
    private final class Running extends Base {
```

正式训练状态。

## 第 25 行

```java
        public String name(){return "RUNNING";}public String action(){return "完成本组";}
```

状态标识 RUNNING，按钮为完成本组。

## 第 26 行

```java
        public void primary(){
```

用户确认完成当前组的处理入口。

## 第 27 行

```java
            Prescription previous=current();completedSets++;setIndex++;
```

先保存当前处方，再增加完成组数和当前组索引。

## 第 28 行

```java
            if(setIndex>=previous.sets){setIndex=0;exerciseIndex++;}
```

达到当前动作组数时归零组索引并进入下一个动作位置。

## 第 29 行

```java
            if(exerciseIndex>=day.exercises.size()){remainingSeconds=240;phase=new Cooldown();}
```

全部动作完成则设置 240 秒放松并进入 Cooldown。

## 第 30 行

```java
            else {remainingSeconds=previous.restSeconds;phase=new Rest();}
```

还有动作/组时，用刚结束处方的休息秒数进入 Rest。状态可能已经指向下一个动作，但休息取上组处方。

## 第 31 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 32 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
    private final class Rest extends Base {
```

组间休息状态。

## 第 34 行

```java
        public String name(){return "REST";}public String action(){return "跳过休息";}
```

状态标识 REST，主按钮可以跳过休息。

## 第 35 行

```java
        public void primary(){remainingSeconds=0;phase=new Running();}
```

点击跳过清剩余秒并进入 Running。

## 第 36 行

```java
        public void tick(int s){remainingSeconds=Math.max(0,remainingSeconds-s);if(remainingSeconds==0)phase=new Running();}
```

时间递减到 0 自动转 Running。多出的 tick 秒数不会继续推进下个状态。

## 第 37 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 38 行

```java
    private final class Cooldown extends Base {
```

放松状态。

## 第 39 行

```java
        public String name(){return "COOLDOWN";}public String action(){return "放松完成，保存记录";}
```

标识 COOLDOWN，按钮让用户确认放松并保存。

## 第 40 行

```java
        public void primary(){remainingSeconds=0;phase=new Complete();}
```

手动确认才进入 Complete；倒计时到零不会自动完成整场。

## 第 41 行

```java
        public void tick(int s){remainingSeconds=Math.max(0,remainingSeconds-s);}
```

放松倒计时降到零，保持本状态等待确认。

## 第 42 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 43 行

```java
    private final class Paused extends Base {
```

暂停状态。

## 第 44 行

```java
        public String name(){return "PAUSED";}public String action(){return "继续训练";}
```

标识 PAUSED，按钮是继续训练。

## 第 45 行

```java
        public void primary(){phase=restorePhase(resumePhase);}
```

根据 resumePhase 恢复暂停前状态对象，进度数字仍保存在外层字段。

## 第 46 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 47 行

```java
    private final class Complete extends Base {
```

完成状态。

## 第 48 行

```java
        public String name(){return "COMPLETE";}public String action(){return "训练已完成";}
```

标识 COMPLETE，按钮文案显示训练完成。

## 第 49 行

```java
        public void primary(){}
```

完成后 primary 无操作，界面也会禁用按钮。

## 第 50 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 51 行

```java
    private final DayPlan day;
```

本场训练绑定的某一天日程。

## 第 52 行

```java
    private final String id;
```

会话唯一 ID，历史去重使用它。

## 第 53 行

```java
    private Phase phase;
```

当前状态对象，变化状态就是替换这个引用。

## 第 54 行

```java
    private String resumePhase="RUNNING";
```

默认恢复目标为 RUNNING，真正暂停时会覆盖成暂停前状态。

## 第 55 行

```java
    private int exerciseIndex,setIndex,remainingSeconds=240,activeSeconds,completedSets;
```

初始索引/时长/组数为 0，初始热身剩余 240 秒。

## 第 56 行

```java
    public WorkoutSession(DayPlan day){if(day==null||day.isRest())throw new IllegalArgumentException("恢复日无需启动训练");this.day=day;id=UUID.randomUUID().toString();phase=new Warmup();}
```

新会话构造：拒绝空日或恢复日，保存日程、生成 ID、从热身开始。

## 第 57 行

```java
    public WorkoutSession(DayPlan day,Snapshot s){
```

用快照恢复的重载构造器。

## 第 58 行

```java
        if(day==null||day.isRest()||s==null||s.id==null||s.phase==null||s.exerciseIndex<0||s.exerciseIndex>day.exercises.size()
```

检查日程、快照、ID、状态名及动作位置上界，允许位置等于列表大小供放松/完成使用。

## 第 59 行

```java
                ||s.setIndex<0||s.remainingSeconds<0||s.remainingSeconds>240||s.activeSeconds<0||s.completedSets<0)throw new IllegalArgumentException("训练快照无效");
```

接着检查组位置、倒计时范围及累计值；异常直接拒绝坏快照。

## 第 60 行

```java
        this.day=day;id=s.id;exerciseIndex=s.exerciseIndex;setIndex=s.setIndex;remainingSeconds=s.remainingSeconds;
```

恢复绑定日程、会话 ID、动作和组位置、剩余秒。

## 第 61 行

```java
        activeSeconds=s.activeSeconds;completedSets=s.completedSets;resumePhase=s.resumePhase;
```

恢复累计时长、完成组数和暂停前状态。

## 第 62 行

```java
        if(exerciseIndex<day.exercises.size()&&setIndex>=day.exercises.get(exerciseIndex).sets)throw new IllegalArgumentException("训练组数无效");
```

尚有动作时，当前组索引必须小于处方组数，不能定位到不存在的一组。

## 第 63 行

```java
        phase=restorePhase(s.phase);
```

把状态字符串解析为具体状态对象。

## 第 64 行

```java
        if(exerciseIndex==day.exercises.size()&&!(phase instanceof Cooldown)&&!(phase instanceof Complete)&&!(phase instanceof Paused))throw new IllegalArgumentException("训练进度无效");
```

动作已经走完时，只允许放松、完成或暂停状态，避免 Running 访问越界。

## 第 65 行

```java
        if(phase instanceof Paused)restorePhase(resumePhase);
```

如果当前暂停，额外检查恢复目标名字可以解析；当前实现不排除恢复目标再次为 PAUSED。

## 第 66 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 67 行

```java
    private Phase restorePhase(String name){
```

状态名转状态对象的集中恢复函数。

## 第 68 行

```java
        if(name==null)throw new IllegalArgumentException("训练状态缺失");
```

缺状态名即拒绝，避免 switch 空值错误。

## 第 69 行

```java
        switch(name){case "WARMUP":return new Warmup();case "RUNNING":return new Running();case "REST":return new Rest();case "COOLDOWN":return new Cooldown();case "PAUSED":return new Paused();case "COMPLETE":return new Complete();default:throw new IllegalArgumentException("未知训练状态");}
```

switch 在六个合法标识中选具体状态；未知值抛异常。

## 第 70 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 71 行

```java
    public void primary(){phase.primary();}
```

主操作直接交给当前状态处理，同一按钮在不同状态行为不同。

## 第 72 行

```java
    public void pause(){if(!(phase instanceof Paused)&&!(phase instanceof Complete)){resumePhase=phase.name();phase=new Paused();}}
```

非暂停且非完成时，先记录当前状态名，再进入 Paused；重复暂停不会覆盖恢复目标。

## 第 73 行

```java
    public void tick(int seconds){if(seconds<0)throw new IllegalArgumentException("时钟不能倒退");if(!(phase instanceof Paused)&&!(phase instanceof Complete)){activeSeconds+=seconds;phase.tick(seconds);}}
```

负秒数拒绝；暂停和完成时不计时，其余先累计 activeSeconds，再让当前状态处理倒计时。

## 第 74 行

```java
    public Snapshot snapshot(){Snapshot s=new Snapshot();s.id=id;s.title=day.title;s.phase=phase.name();s.resumePhase=resumePhase;s.exerciseIndex=exerciseIndex;s.setIndex=setIndex;s.remainingSeconds=remainingSeconds;s.activeSeconds=activeSeconds;s.completedSets=completedSets;return s;}
```

新建快照并逐项复制字段后返回；返回的是数据副本，不暴露状态对象。

## 第 75 行

```java
    public String phase(){return phase.name();}public String action(){return phase.action();}
```

读取当前状态标识和按钮文字，两者由状态对象决定。

## 第 76 行

```java
    public boolean complete(){return phase instanceof Complete;}
```

使用 instanceof 判断是否 Complete。

## 第 77 行

```java
    public Prescription current(){return day.exercises.get(Math.min(exerciseIndex,day.exercises.size()-1));}
```

返回当前位置处方；已走完时钳制到最后一个，供放松/完成页渲染读取，构造器保证不是空日程。

## 第 78 行

```java
    public Exercise exercise(){return ExerciseCatalog.get(current().exerciseId);}
```

根据处方 ID 查共享动作定义。

## 第 79 行

```java
    public int exerciseIndex(){return exerciseIndex;}public int setIndex(){return setIndex;}
```

读取动作与组的零起点索引。

## 第 80 行

```java
    public int remaining(){return remainingSeconds;}public int seconds(){return activeSeconds;}
```

读取阶段剩余秒和累计活跃秒。

## 第 81 行

```java
    public DayPlan day(){return day;}
```

返回本场绑定日程。

## 第 82 行

```java
    public TrainingRecord record(long time){if(!complete())throw new IllegalStateException("训练尚未完成");return new TrainingRecord(id,day.title,time,activeSeconds,completedSets);}
```

只有完成状态才能生成训练记录；用同一会话 ID、标题、传入完成时刻和累计值构造结果。

## 第 83 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
