# core/src/main/java/com/pulse/core/util/JsonCodec.java

在 JSON 和领域对象间显式转换，保留不可变模型的构造约束。反序列化不是计划安全校验的替代。

原文件 SHA-256：`fdcbe57d59707b3f3f56761534aa399636000c8184d4ac0d43021d84fccf25de`。行号仅对应此快照；修改源码后应重新核对。

共 44 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.util;
```

声明本文件所属包 com.pulse.core.util；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.google.gson.*;
```

导入类型命名空间 com.google.gson.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.validation.ProfileValidator;
```

导入类型命名空间 com.pulse.core.validation.ProfileValidator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
/** Explicit boundary mapping: constructors preserve immutable collection invariants. */
```

源码注释，不参与执行。在 JSON 和领域对象间显式转换，保留不可变模型的构造约束。反序列化不是计划安全校验的替代。

## 第 9 行

```java
public final class JsonCodec {
```

定义 public final class JsonCodec。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    public static final Gson GSON=new GsonBuilder().disableHtmlEscaping().create();
```

创建共享 Gson；disableHtmlEscaping 不把 < 等字符转换成 HTML 转义，不意味着可以直接插进网页 HTML。

## 第 11 行

```java
    public static String profile(UserProfile p){return GSON.toJson(p);}
```

重载方法：输入档案对象，输出 JSON 字符串。

## 第 12 行

```java
    public static UserProfile profile(String json){
```

同名重载：输入 JSON，输出档案对象。

## 第 13 行

```java
        JsonObject o=JsonParser.parseString(json).getAsJsonObject();
```

解析为 JSON 对象，非法 JSON 或非对象类型会抛异常。

## 第 14 行

```java
        UserProfile p=new UserProfile.Builder().name(str(o,"name")).age(integer(o,"age")).sex(str(o,"sex"))
```

用 Builder 开始恢复昵称、整数年龄和性别；不是绕过构造器直接写字段。

## 第 15 行

```java
                .body(o.get("heightCm").getAsDouble(),o.get("weightKg").getAsDouble())
```

读取 double 身高和体重。

## 第 16 行

```java
                .goal(UserProfile.Goal.valueOf(str(o,"goal"))).experience(UserProfile.Experience.valueOf(str(o,"experience")))
```

将目标与经验字符串转换为枚举名；不认识的值会失败。

## 第 17 行

```java
                .equipment(UserProfile.Equipment.valueOf(str(o,"equipment"))).schedule(integer(o,"daysPerWeek"),integer(o,"minutesPerSession"))
```

恢复器械枚举及整数频率、分钟数。

## 第 18 行

```java
                .limitations(bool(o,"protectKnees"),bool(o,"protectBack"),bool(o,"lowImpact"),bool(o,"needsProfessional")).build();
```

恢复四个布尔限制并 build 成不可变档案。

## 第 19 行

```java
        ProfileValidator.validateForStorage(p);return p;
```

通过存档边界检查才返回。

## 第 20 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 21 行

```java
    public static String plan(WeekPlan p){return GSON.toJson(p);}
```

对象转计划 JSON。

## 第 22 行

```java
    public static WeekPlan plan(String json){
```

JSON 转计划对象的方法入口。

## 第 23 行

```java
        JsonObject o=JsonParser.parseString(json).getAsJsonObject();
```

解析周计划 JSON 对象。

## 第 24 行

```java
        return new WeekPlan(str(o,"id"),o.get("createdAt").getAsLong(),str(o,"profileSignature"),WeekPlan.Source.valueOf(str(o,"source")),str(o,"note"),days(o.getAsJsonArray("days")));
```

从字段重建 WeekPlan，days 方法重建七天；这里不自动检查计划是否匹配当前档案。

## 第 25 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
    public static List<DayPlan> days(JsonArray array){
```

从 JSON 数组构建日计划列表。

## 第 27 行

```java
        if(array==null||array.size()!=7)throw new IllegalArgumentException("计划必须包含七天");
```

天表必须存在且恰好七项。

## 第 28 行

```java
        List<DayPlan> days=new ArrayList<>();
```

创建结果列表。

## 第 29 行

```java
        for(JsonElement element:array){
```

遍历每一天的 JSON 元素。

## 第 30 行

```java
            JsonObject d=element.getAsJsonObject();List<Prescription> exercises=new ArrayList<>();
```

每天转对象，并新建此日处方列表。

## 第 31 行

```java
            JsonArray rx=d.getAsJsonArray("exercises");if(rx==null||rx.size()>6)throw new IllegalArgumentException("动作数量无效");
```

必须有处方数组，且不超过六项，控制对象创建数量。

## 第 32 行

```java
            for(JsonElement r:rx){JsonObject x=r.getAsJsonObject();exercises.add(new Prescription(str(x,"exerciseId"),integer(x,"sets"),integer(x,"amount"),integer(x,"restSeconds")));}
```

遍历处方，读取 ID 与三个整数，经构造器创建 Prescription。

## 第 33 行

```java
            days.add(new DayPlan(integer(d,"dayIndex"),str(d,"title"),exercises));
```

将 dayIndex、标题和处方列表构成 DayPlan 并追加。

## 第 34 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 35 行

```java
        return days;
```

返回构建好的七天列表。

## 第 36 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 37 行

```java
    public static String str(JsonObject o,String key){JsonElement v=o.get(key);if(v==null||!v.isJsonPrimitive()||!v.getAsJsonPrimitive().isString())throw new IllegalArgumentException("缺少文本字段："+key);return v.getAsString();}
```

严格字符串读取：字段必须存在、为基本类型且实际是字符串，不接受数值自动转文本。

## 第 38 行

```java
    public static int integer(JsonObject o,String key){
```

严格整数读取方法入口。

## 第 39 行

```java
        JsonElement e=o.get(key);if(e==null||!e.isJsonPrimitive()||!e.getAsJsonPrimitive().isNumber())throw new IllegalArgumentException("缺少数字字段："+key);
```

必须是 JSON 数字，缺失、字符串数字等都拒绝。

## 第 40 行

```java
        try{return e.getAsBigDecimal().intValueExact();}catch(ArithmeticException ex){throw new IllegalArgumentException("数字必须为整数："+key);}
```

用 BigDecimal.intValueExact 检查确为 int 范围内的整数；25.5 不会悄悄截为 25，失败转成可读参数异常。

## 第 41 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 42 行

```java
    private static boolean bool(JsonObject o,String key){JsonElement v=o.get(key);if(v==null||!v.isJsonPrimitive()||!v.getAsJsonPrimitive().isBoolean())throw new IllegalArgumentException("缺少开关字段："+key);return v.getAsBoolean();}
```

严格布尔读取，不把字符串“true”当成真正 boolean。

## 第 43 行

```java
    private JsonCodec(){}
```

工具类无须实例化。

## 第 44 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
