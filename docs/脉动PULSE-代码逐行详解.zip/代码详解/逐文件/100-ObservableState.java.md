# core/src/main/java/com/pulse/core/util/ObservableState.java

轻量观察者容器，不是 Android LiveData；回调在哪个线程调用 set 就在哪个线程执行。

原文件 SHA-256：`4250b57ddcf1ed72d61d0e609c77e3fee3417f70262576e54349fb324c393166`。行号仅对应此快照；修改源码后应重新核对。

共 14 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.util;
```

声明本文件所属包 com.pulse.core.util；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import java.util.concurrent.CopyOnWriteArrayList;
```

导入类型命名空间 java.util.concurrent.CopyOnWriteArrayList，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 4 行

```java
/** Observer. Owners explicitly unsubscribe at the lifecycle boundary. */
```

源码注释，不参与执行。轻量观察者容器，不是 Android LiveData；回调在哪个线程调用 set 就在哪个线程执行。

## 第 5 行

```java
public final class ObservableState<T> {
```

定义 public final class ObservableState<T>。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 6 行

```java
    public interface Listener<T>{void changed(T value);}
```

泛型监听器接口，changed 接收新的 T 类型状态。

## 第 7 行

```java
    private final CopyOnWriteArrayList<Listener<T>> listeners=new CopyOnWriteArrayList<>();
```

CopyOnWriteArrayList 遍历时容忍订阅变化，但不会自动把回调切换到主线程。

## 第 8 行

```java
    private T value;
```

当前状态值。

## 第 9 行

```java
    public ObservableState(T initial){value=initial;}
```

构造时保存初始状态，不在这里通知监听器。

## 第 10 行

```java
    public T get(){return value;}
```

返回当前值。

## 第 11 行

```java
    public void set(T next){value=next;for(Listener<T> l:listeners)l.changed(next);}
```

替换状态，再逐个同步通知监听器；没有相等判断，每次 set 都通知。

## 第 12 行

```java
    public void observe(Listener<T> l){listeners.addIfAbsent(l);l.changed(value);}
```

去重订阅后立即回调当前值，让新页面马上渲染。

## 第 13 行

```java
    public void remove(Listener<T> l){listeners.remove(l);}
```

取消订阅；Activity 在 onStop 调用，防止隐藏页面继续收到事件。

## 第 14 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
