# core/src/main/java/com/pulse/core/validation/ProfileValidator.java

责任链实现两套检查：允许存档的范围比允许自动生成训练的范围宽。

原文件 SHA-256：`6ef7b637e4b04774808bb74744a34f05697e78e1c36d46b4ae5ded7161bccf03`。行号仅对应此快照；修改源码后应重新核对。

共 33 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core.validation;
```

声明本文件所属包 com.pulse.core.validation；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.model.UserProfile;
```

导入类型命名空间 com.pulse.core.model.UserProfile，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 5 行

```java
/** Chain of Responsibility: independently replaceable numeric, schedule and health handlers. */
```

源码注释，不参与执行。责任链实现两套检查：允许存档的范围比允许自动生成训练的范围宽。

## 第 6 行

```java
public final class ProfileValidator {
```

定义 public final class ProfileValidator。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 7 行

```java
    public abstract static class Handler {
```

所有校验处理器的抽象父类。

## 第 8 行

```java
        private Handler next;
```

指向下一个处理器，null 表示链尾。

## 第 9 行

```java
        public Handler then(Handler handler){next=handler;return handler;}
```

把下个处理器接在当前后面，并返回下个处理器，支持 root.then(A).then(B)。

## 第 10 行

```java
        public final void validate(UserProfile p){check(p);if(next!=null)next.validate(p);}
```

固定校验流程：先执行本节点 check，通过后再交给下一个；抛异常会中断整条链。

## 第 11 行

```java
        protected abstract void check(UserProfile p);
```

子类必须实现当前节点的具体规则。

## 第 12 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 13 行

```java
    public static final class Basics extends Handler {
```

基础信息处理器，继承 Handler。

## 第 14 行

```java
        @Override protected void check(UserProfile p){
```

覆盖基础检查步骤。

## 第 15 行

```java
            if(p==null||p.name==null||p.name.isEmpty()||p.name.length()>24)fail("昵称请输入 1–24 个字");
```

档案或昵称不存在、昵称为空或超过 24 字符时拒绝。|| 短路保证 p 为 null 时不会访问 p.name。

## 第 16 行

```java
            if(p.age<12||p.age>90)fail("年龄请输入 12–90 岁");
```

存档年龄范围 12–90 岁，不代表这个范围都可以自动生成训练。

## 第 17 行

```java
            if(!Double.isFinite(p.heightCm)||!Double.isFinite(p.weightKg)||p.heightCm<100||p.heightCm>230||p.weightKg<25||p.weightKg>250)fail("请检查身高（100–230 cm）和体重（25–250 kg）");
```

同时检查有限数值和范围：身高 100–230 cm、体重 25–250 kg；排除 NaN、正负无穷。

## 第 18 行

```java
            if(p.goal==null||p.experience==null||p.equipment==null||p.sex==null||p.sex.length()>12)fail("请完整选择个人档案");
```

枚举、性别不能缺失，性别文本最多 12 字符。

## 第 19 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 21 行

```java
    public static final class Schedule extends Handler {
```

日程检查处理器。

## 第 22 行

```java
        @Override protected void check(UserProfile p){if(p.daysPerWeek<2||p.daysPerWeek>5||p.minutesPerSession<15||p.minutesPerSession>60)fail("每周安排 2–5 天，每次 15–60 分钟");}
```

每周必须 2–5 天，每次 15–60 分钟；任一越界即失败。

## 第 23 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 24 行

```java
    public static final class Health extends Handler {
```

自动训练的人群门槛处理器。

## 第 25 行

```java
        @Override protected void check(UserProfile p){
```

覆盖人群检查步骤。

## 第 26 行

```java
            if(p.age<18||p.age>69||p.needsProfessional)fail("此档案需要专业人员评估后制定训练计划。当前版本仅为 18–69 岁、无医疗运动限制的成年人自动生成计划。");
```

小于 18 岁、大于 69 岁、需专业评估任一成立就拒绝自动生成；这些档案仍可存档。

## 第 27 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 28 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 29 行

```java
    public static void validateForStorage(UserProfile p){Handler root=new Basics();root.then(new Schedule());root.validate(p);}
```

存储检查只接 Basics → Schedule，然后从根执行。

## 第 30 行

```java
    public static void validateForTraining(UserProfile p){Handler root=new Basics();root.then(new Schedule()).then(new Health());root.validate(p);}
```

训练检查接 Basics → Schedule → Health；基础错误会先于后续错误返回。

## 第 31 行

```java
    private static void fail(String message){throw new IllegalArgumentException(message);}
```

将可读提示包装成 IllegalArgumentException 抛给上层。

## 第 32 行

```java
    private ProfileValidator(){}
```

工具类禁止外部实例化。

## 第 33 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
