# core/src/test/java/com/pulse/core/PhoneAuthTest.java

四个 JUnit 测试以假时钟和固定随机值验证演示规则，无需等 60 秒，也不发送短信。assertThrows 验证失败路径。

原文件 SHA-256：`eb3236859a346a19b3415bdd79ffe5e02388d790ac9cf16698bd6c4826653bb7`。行号仅对应此快照；修改源码后应重新核对。

共 40 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core;
```

声明本文件所属包 com.pulse.core；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.pulse.core.auth.DemoPhoneAuth;
```

导入类型命名空间 com.pulse.core.auth.DemoPhoneAuth，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import org.junit.Test;
```

导入类型命名空间 org.junit.Test，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import static org.junit.Assert.*;
```

静态导入 org.junit.Assert.*，后面可直接写枚举项或断言方法名。

## 第 6 行

```java
import java.util.concurrent.atomic.AtomicLong;
```

导入类型命名空间 java.util.concurrent.atomic.AtomicLong，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
public final class PhoneAuthTest {
```

定义 public final class PhoneAuthTest。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 9 行

```java
    private static final String PHONE="13800138000";
```

测试用示例号码常量，不代表真实登录身份。

## 第 10 行

```java
    @Test public void successConsumesTheCodeAndDoesNotVerifyAnotherPhone(){
```

@Test 标记测试入口：检查验证码绑定号码且成功后一次消费。

## 第 11 行

```java
        AtomicLong time=new AtomicLong(1000);DemoPhoneAuth auth=new DemoPhoneAuth(time::get,()->42);
```

假时钟初值 1000ms，随机供应器固定 42；依赖注入使测试可重复。

## 第 12 行

```java
        DemoPhoneAuth.CodeDelivery delivery=auth.requestCode(PHONE);assertEquals("000042",delivery.code);
```

请求码，断言补零后的字符串恰好为 000042。

## 第 13 行

```java
        assertThrows(IllegalArgumentException.class,()->auth.verify("13900139000",delivery.code));
```

用另一个号码提交同一码，必须抛参数异常。

## 第 14 行

```java
        auth.verify(PHONE,delivery.code);
```

正确号码与码校验成功，不应抛异常。

## 第 15 行

```java
        assertThrows(IllegalArgumentException.class,()->auth.verify(PHONE,delivery.code));
```

再提交相同码必须失败，证明不能重放。

## 第 16 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 17 行

```java
    @Test public void resendCountdownCannotBeBypassedWithAnotherPhone(){
```

测试重发间隔不会因更换号码被绕过。

## 第 18 行

```java
        AtomicLong time=new AtomicLong(1000);DemoPhoneAuth auth=new DemoPhoneAuth(time::get,()->123456);
```

建假时钟和固定六位随机值。

## 第 19 行

```java
        auth.requestCode(PHONE);assertEquals(60,auth.resendSeconds());
```

发码后立即应剩 60 秒。

## 第 20 行

```java
        time.addAndGet(1001);assertEquals(59,auth.resendSeconds());
```

时间前进 1001ms，向上取整还剩 59 秒。

## 第 21 行

```java
        assertThrows(IllegalArgumentException.class,()->auth.requestCode("13900139000"));
```

换手机号请求仍应失败，因为冷却属于实例而非号码。

## 第 22 行

```java
        time.addAndGet(59000);assertEquals(0,auth.resendSeconds());assertEquals("13900139000",auth.requestCode("13900139000").phone);
```

再前进 59000ms，冷却为 0，此时新号码请求成功并返回新号码。

## 第 23 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 24 行

```java
    @Test public void expiredAndRepeatedlyWrongCodesAreRejected(){
```

测试过期和五次错误锁定。

## 第 25 行

```java
        AtomicLong time=new AtomicLong(1000);DemoPhoneAuth auth=new DemoPhoneAuth(time::get,()->123456);
```

新建可控规则对象。

## 第 26 行

```java
        auth.requestCode(PHONE);time.addAndGet(300000);
```

发码后把时间推到满 300 秒。

## 第 27 行

```java
        assertThrows(IllegalArgumentException.class,()->auth.verify(PHONE,"123456"));
```

满有效期边界时正确码也必须失效。

## 第 28 行

```java
        auth.requestCode(PHONE);
```

冷却已结束，可以重新请求一份演示码。

## 第 29 行

```java
        for(int i=0;i<DemoPhoneAuth.MAX_ATTEMPTS;i++)assertThrows(IllegalArgumentException.class,()->auth.verify(PHONE,"999999"));
```

循环输入错误的六位码五次，每次均要求抛异常。

## 第 30 行

```java
        assertThrows(IllegalArgumentException.class,()->auth.verify(PHONE,"123456"));
```

第五次失效后，再提交正确码也必须失败。

## 第 31 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 32 行

```java
    @Test public void phoneAndCodeFormatsAndClockRollbackAreChecked(){
```

测试格式校验与时间倒退保护。

## 第 33 行

```java
        assertEquals(PHONE,DemoPhoneAuth.normalizePhone("138 0013 8000"));
```

带普通空格的号码应正确规范化。

## 第 34 行

```java
        assertThrows(IllegalArgumentException.class,()->DemoPhoneAuth.normalizePhone("123"));
```

位数不足的号码必须失败。

## 第 35 行

```java
        assertThrows(IllegalArgumentException.class,()->DemoPhoneAuth.normalizePhone("1380013800x"));
```

号码含字母必须失败。

## 第 36 行

```java
        AtomicLong time=new AtomicLong(1000);DemoPhoneAuth auth=new DemoPhoneAuth(time::get,()->123456);
```

建新假时钟和规则对象。

## 第 37 行

```java
        auth.requestCode(PHONE);assertThrows(IllegalArgumentException.class,()->auth.verify(PHONE,"abc123"));
```

请求后输入带字母验证码必须失败。

## 第 38 行

```java
        time.set(0);assertThrows(IllegalArgumentException.class,()->auth.verify(PHONE,"123456"));
```

把时间改到早于发码时刻，即使码正确也应失效，避免负经过时间绕过校验。

## 第 39 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 40 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
