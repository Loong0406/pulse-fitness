# core/src/test/java/com/pulse/core/PlanningTest.java

七个测试检查组合档案、健康门槛、危险输出拒绝、深复制、导出、撤销、筛选及 JSON 边界。

原文件 SHA-256：`9ba1a7d2fb5f778f930928555cebe81ac1404400601ee8fecd417b84af2b51df`。行号仅对应此快照；修改源码后应重新核对。

共 64 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core;
```

声明本文件所属包 com.pulse.core；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import org.junit.Test;
```

导入类型命名空间 org.junit.Test，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import static org.junit.Assert.*;
```

静态导入 org.junit.Assert.*，后面可直接写枚举项或断言方法名。

## 第 5 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.core.data.*;
```

导入类型命名空间 com.pulse.core.data.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.core.export.PlanExporter;
```

导入类型命名空间 com.pulse.core.export.PlanExporter，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import com.pulse.core.validation.ProfileValidator;
```

导入类型命名空间 com.pulse.core.validation.ProfileValidator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 13 行

```java
public class PlanningTest {
```

定义 public class PlanningTest。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 14 行

```java
    @Test public void allSupportedProfilesRespectTimeEquipmentAndLimitations()throws Exception{
```

首个测试遍历支持的档案组合，方法可抛异常给 JUnit 判失败。

## 第 15 行

```java
        int checked=0;
```

已检查组合计数，从零开始。

## 第 16 行

```java
        for(UserProfile.Goal goal:UserProfile.Goal.values())for(UserProfile.Experience experience:UserProfile.Experience.values())
```

双层循环遍历 3 种目标×3 种经验。

## 第 17 行

```java
            for(UserProfile.Equipment equipment:UserProfile.Equipment.values())for(int days=2;days<=5;days++)
```

再遍历 3 种器械×4 种周频率。

## 第 18 行

```java
                for(int minutes:new int[]{15,20,30,40,45,60})for(int flags=0;flags<8;flags++)for(int age:new int[]{18,35,65}){
```

再遍历 6 种分钟×8 种三开关组合×3 个年龄。

## 第 19 行

```java
                    UserProfile p=UserProfile.defaults().toBuilder().goal(goal).experience(experience).equipment(equipment).age(age).schedule(days,minutes)
```

基于默认档案建不同目标、经验、器械、年龄和日程。

## 第 20 行

```java
                            .limitations((flags&1)!=0,(flags&2)!=0,(flags&4)!=0,false).build();
```

flags 按位与 1/2/4 解出膝/背/低冲击三个开关，专业评估固定 false。

## 第 21 行

```java
                    WeekPlan plan=new PlanGeneratorFactory.Local().createSafeGenerator().generate(p);PlanSafety.validate(plan,p);
```

经工厂安全入口生成，再显式检查计划合法。

## 第 22 行

```java
                    int count=0;for(DayPlan day:plan){if(day.isRest())continue;count++;assertTrue(PlanStatisticsVisitor.minutes(day)<=minutes);
```

遍历训练日，统计天数并断言每一天估时不超过预算。

## 第 23 行

```java
                        for(Prescription rx:day.exercises)assertTrue(ExerciseCatalog.get(rx.exerciseId).isAllowed(p));}
```

每条处方必须符合这个档案的动作允许条件。

## 第 24 行

```java
                    assertEquals(days,count);checked++;
```

断言训练天数准确，增加已验证组合数量。

## 第 25 行

```java
                }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 26 行

```java
        assertEquals(15552,checked);
```

最终组合数应为 3×3×3×4×6×8×3=15552；这是一个测试中的多组输入，不是 15552 个独立 JUnit 测试。

## 第 27 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 28 行

```java
    @Test public void healthGateRejectsUnsupportedPopulationWithoutLosingStoredProfile(){
```

检查不支持自动训练的人群仍可正常存档。

## 第 29 行

```java
        for(UserProfile p:new UserProfile[]{UserProfile.defaults().toBuilder().age(16).build(),UserProfile.defaults().toBuilder().age(75).build(),UserProfile.defaults().toBuilder().limitations(false,false,false,true).build()}){
```

分别构造 16 岁、75 岁、需要专业评估三种档案。

## 第 30 行

```java
            ProfileValidator.validateForStorage(p);
```

存档检查应正常通过。

## 第 31 行

```java
            assertThrows(IllegalArgumentException.class,()->new LocalPlanGenerator().generate(p));
```

自动生成应抛参数异常，不应无视人群门槛。

## 第 32 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 34 行

```java
    @Test public void incompatibleOrUnsafeModelPlanIsRejected()throws Exception{
```

检查模型不兼容或危险负荷必须拒绝。

## 第 35 行

```java
        UserProfile p=UserProfile.defaults();WeekPlan original=new LocalPlanGenerator().generate(p);
```

先生成一份有效原始计划。

## 第 36 行

```java
        List<DayPlan> days=new ArrayList<>(original.days);days.set(0,new DayPlan(0,"unsafe",Arrays.asList(new Prescription("db_row",4,100,1),new Prescription("squat",2,10,45))));
```

复制天表，把第一天替换为徒手用户不适用的哑铃处方及极端负荷。

## 第 37 行

```java
        WeekPlan unsafe=new WeekPlan("x",1,p.signature(),WeekPlan.Source.AI,"",days);
```

包装成 AI 来源候选，说明来源标签不代表可靠。

## 第 38 行

```java
        assertThrows(IllegalArgumentException.class,()->PlanSafety.validate(unsafe,p));
```

PlanSafety 必须拒绝危险候选。

## 第 39 行

```java
        UserProfile changed=p.toBuilder().equipment(UserProfile.Equipment.GYM).build();
```

改档案器械，新档案签名随之变化。

## 第 40 行

```java
        assertThrows(IllegalArgumentException.class,()->PlanSafety.validate(original,changed));
```

原计划与新档案签名不一致，也必须拒绝。

## 第 41 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 42 行

```java
    @Test public void copyingAndExportingKeepsOriginalIndependent()throws Exception{
```

检查复制后的独立性及两种导出。

## 第 43 行

```java
        WeekPlan p=new LocalPlanGenerator().generate(UserProfile.defaults());WeekPlan copy=p.copyForNextWeek();
```

生成原计划并深复制。

## 第 44 行

```java
        assertNotEquals(p.id,copy.id);assertNotSame(p.days.get(0),copy.days.get(0));assertNotSame(p.days.get(0).exercises.get(0),copy.days.get(0).exercises.get(0));
```

断言新 ID 不同、日对象引用不同、处方对象引用不同；assertNotSame 比较对象身份。

## 第 45 行

```java
        assertThrows(UnsupportedOperationException.class,()->copy.days.clear());
```

复制计划的只读列表不能 clear，必须抛 UnsupportedOperationException。

## 第 46 行

```java
        PlanExporter.MemorySink sink=new PlanExporter.MemorySink();new PlanExporter.Json(sink).export(copy);WeekPlan loaded=JsonCodec.plan(sink.value);PlanSafety.validate(loaded,UserProfile.defaults());
```

导出 JSON 到内存，再读回来并重新校验，检查往返转换。

## 第 47 行

```java
        new PlanExporter.Text(sink).export(p);assertTrue(sink.value.contains("本地规则"));assertTrue(sink.value.contains(ExerciseCatalog.get(p.days.get(0).exercises.get(0).exerciseId).name));
```

导出可读文本，检查来源及真实动作名字。

## 第 48 行

```java
        PlanStatisticsVisitor stats=new PlanStatisticsVisitor();p.accept(stats);assertEquals(3,stats.trainingDays);assertTrue(stats.totalSets>0);
```

用访问者统计，默认档案应 3 个训练日且总组数为正。

## 第 49 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 50 行

```java
    @Test public void saveUndoAndDuplicateRecordAreConsistent(){
```

检查保存撤销和完成记录去重。

## 第 51 行

```java
        Repositories.Factory f=new MemoryRepositoryFactory();f.profiles().save(UserProfile.defaults());
```

建独立内存仓库并存默认档案，不污染 Android 数据。

## 第 52 行

```java
        ProfileCommand command=new ProfileCommand(f.profiles(),UserProfile.defaults().toBuilder().name("小林").build());command.execute();assertEquals("小林",f.profiles().get().name);command.undo();assertEquals("训练者",f.profiles().get().name);
```

执行昵称修改命令，检查新昵称，再撤销检查恢复旧昵称。

## 第 53 行

```java
        TrainingRecord r=new TrainingRecord("once","训练",1,100,4);f.history().add(r);f.history().add(r);assertEquals(1,f.history().all().size());
```

同一 ID 记录添加两遍，最终必须只有一条。

## 第 54 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 55 行

```java
    @Test public void filterGrammarRespectsAndBeforeOr(){
```

检查搜索表达式中 AND 比 OR 优先。

## 第 56 行

```java
        ExerciseQuery.Expression query=ExerciseQuery.parse("group:上肢 & equipment:徒手 | group:核心");
```

解析“徒手上肢或核心”表达式。

## 第 57 行

```java
        assertTrue(query.matches(ExerciseCatalog.get("wall_push")));assertTrue(query.matches(ExerciseCatalog.get("dead_bug")));assertFalse(query.matches(ExerciseCatalog.get("db_row")));assertFalse(query.matches(ExerciseCatalog.get("squat")));
```

靠墙俯卧撑和死虫式匹配，哑铃划船及深蹲不匹配，四个断言验证组合语义。

## 第 58 行

```java
        assertThrows(IllegalArgumentException.class,()->ExerciseQuery.parse("上肢 &"));
```

尾部缺条件的表达式必须拒绝。

## 第 59 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 60 行

```java
    @Test public void jsonBoundariesRejectFractionalIntegersAndInvalidBodies(){
```

检查 JSON 边界不悄悄接受小数年龄或离谱身高。

## 第 61 行

```java
        String p=JsonCodec.profile(UserProfile.defaults());assertThrows(RuntimeException.class,()->JsonCodec.profile(p.replace("\"age\":25","\"age\":25.5")));
```

把合法 JSON 的年龄改为 25.5，档案解析应失败而不是截成 25。

## 第 62 行

```java
        assertThrows(RuntimeException.class,()->JsonCodec.profile(p.replace("\"heightCm\":170.0","\"heightCm\":1")));
```

把身高改成 1cm，解析后的范围检查必须失败。

## 第 63 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 64 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
