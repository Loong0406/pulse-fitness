# core/src/test/java/com/pulse/core/SessionTest.java

两项纯 Java 测试检查热身、组进度、休息、暂停、JSON 恢复、放松和完成。

原文件 SHA-256：`4cb2a45c0fbb1cfb6c272fe465adeda0b1aebd6e115a17cf2433c1bdb31ba976`。行号仅对应此快照；修改源码后应重新核对。

共 24 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.core;
```

声明本文件所属包 com.pulse.core；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
import org.junit.Test;
```

导入类型命名空间 org.junit.Test，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 3 行

```java
import static org.junit.Assert.*;
```

静态导入 org.junit.Assert.*，后面可直接写枚举项或断言方法名。

## 第 4 行

```java
import com.pulse.core.session.WorkoutSession;
```

导入类型命名空间 com.pulse.core.session.WorkoutSession，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 9 行

```java
public class SessionTest {
```

定义 public class SessionTest。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    private DayPlan day(){return new DayPlan(0,"基础训练",Arrays.asList(new Prescription("wall_push",2,10,30),new Prescription("calf_raise",1,10,45)));}
```

测试日程有两个动作，共 3 组；休息分别 30 与 45 秒。

## 第 11 行

```java
    @Test public void pauseProcessRestoreAndCompletionPreserveProgress(){
```

完整会话恢复测试入口。

## 第 12 行

```java
        WorkoutSession s=new WorkoutSession(day());assertEquals("WARMUP",s.phase());s.tick(15);s.primary();s.tick(30);s.primary();assertEquals("REST",s.phase());s.tick(10);s.pause();s.tick(100);
```

从热身计 15 秒，手动进入训练计 30 秒，完成一组进入休息，休息 10 秒后暂停；暂停后的 tick(100) 不计入。

## 第 13 行

```java
        assertEquals(55,s.seconds());assertEquals(20,s.remaining());
```

活跃时间应为 15+30+10=55 秒，休息应剩 30-10=20 秒。

## 第 14 行

```java
        WorkoutSession.Snapshot snapshot=JsonCodec.GSON.fromJson(JsonCodec.GSON.toJson(s.snapshot()),WorkoutSession.Snapshot.class);
```

快照经 JSON 序列化再反序列化，模拟进程状态保存，不只是保留原对象引用。

## 第 15 行

```java
        WorkoutSession restored=new WorkoutSession(day(),snapshot);restored.primary();restored.tick(20);assertEquals("RUNNING",restored.phase());assertEquals(1,restored.setIndex());
```

构建恢复会话，继续后先回 Rest，再走完 20 秒自动 Running；当前组位置应为 1，也就是第二组。

## 第 16 行

```java
        restored.primary();assertEquals("REST",restored.phase());restored.primary();assertEquals(1,restored.exerciseIndex());restored.primary();assertEquals("COOLDOWN",restored.phase());
```

完成第二组，跳过休息，进入第二动作，完成后进入放松。

## 第 17 行

```java
        assertThrows(IllegalStateException.class,()->restored.record(1));restored.tick(240);restored.primary();assertTrue(restored.complete());assertEquals(3,restored.record(1).completedSets);assertEquals(snapshot.id,restored.record(1).id);
```

放松前不能导出完成记录；放松计时并确认后完成，总完成组数为 3，ID 与快照一致。

## 第 18 行

```java
        int seconds=restored.seconds();restored.tick(100);assertEquals(seconds,restored.seconds());
```

完成后 tick 不应改变累计时间。

## 第 19 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
    @Test public void invalidProgressAndBackwardClockAreRejected(){
```

检查非法快照和负时间。

## 第 21 行

```java
        WorkoutSession s=new WorkoutSession(day());WorkoutSession.Snapshot snapshot=s.snapshot();snapshot.exerciseIndex=20;
```

修改快照动作位置到 20，超过实际动作数量。

## 第 22 行

```java
        assertThrows(IllegalArgumentException.class,()->new WorkoutSession(day(),snapshot));assertThrows(IllegalArgumentException.class,()->s.tick(-1));
```

恢复坏位置必须失败；tick(-1) 也必须失败。

## 第 23 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 24 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
