# docker-compose.yml

可选容器配置，仅定义 Java 网关；本次只是解释，不执行 docker compose。

原文件 SHA-256：`71ff8c0053555335cc1d5bc3e26be91882f8e1ccadb5f1cfc6c181d6ff13e85d`。行号仅对应此快照；修改源码后应重新核对。

共 16 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
# Optional Java gateway only. No model is downloaded or started.
```

配置注释，不执行；正文记录该项的适用环境或工具生成来源。

## 第 2 行

```text
services:
```

声明 compose 服务集合。

## 第 3 行

```text
  server:
```

服务名称 server。

## 第 4 行

```text
    build:
```

镜像通过本地 Dockerfile 构建。

## 第 5 行

```text
      context: .
```

构建上下文为项目根目录。

## 第 6 行

```text
      dockerfile: server/Dockerfile
```

指定 server/Dockerfile。

## 第 7 行

```text
    restart: unless-stopped
```

除非人为停止，否则由容器运行器按策略重启服务。

## 第 8 行

```text
    ports:
```

端口映射列表开始。

## 第 9 行

```text
      - "127.0.0.1:8080:8080"
```

宿主仅监听 127.0.0.1:8080，转到容器 8080；外部机器不能直接连此宿主绑定。

## 第 10 行

```text
    environment:
```

传入容器的环境变量开始。

## 第 11 行

```text
      HOST: 0.0.0.0
```

容器内部监听 0.0.0.0，以便转发能到达；与宿主绑定范围是两回事。

## 第 12 行

```text
      PORT: 8080
```

容器 Java 服务端口 8080。

## 第 13 行

```text
      APP_TOKEN: ${APP_TOKEN:?Set a random APP_TOKEN of at least 24 characters in .env}
```

从外部环境或 .env 读取 APP_TOKEN；:? 在缺失/空时提示错误，不自动生成。

## 第 14 行

```text
      AI_BASE_URL: ${AI_BASE_URL:-}
```

可选上游模型地址，未设则空，服务生成本地规则计划。

## 第 15 行

```text
      AI_MODEL: ${AI_MODEL:-configured-model}
```

模型展示名未设时用 configured-model。

## 第 16 行

```text
      AI_API_KEY: ${AI_API_KEY:-}
```

可选上游密钥，未设则空；这不是手机网关令牌。
