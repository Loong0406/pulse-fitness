# gradle.properties

工程级 Gradle 行为。编码设置用于当前 Windows 中文路径环境，源码编译编码仍各模块显式 UTF-8。

原文件 SHA-256：`42866a57f3a020f474405edff40cc39dbff2fcd4a9fbb477093856945e2dc790`。行号仅对应此快照；修改源码后应重新核对。

共 10 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
# Java argument files must use the Windows native encoding when paths contain Chinese.
```

配置注释，不执行；正文记录该项的适用环境或工具生成来源。

## 第 2 行

```text
# Source compilation is explicitly UTF-8 in every module.
```

配置注释，不执行；正文记录该项的适用环境或工具生成来源。

## 第 3 行

```text
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=COMPAT
```

Gradle JVM 最大堆 2048MiB；COMPAT 使用平台兼容默认字符编码，处理 Windows 中文路径参数文件。

## 第 4 行

```text
org.gradle.parallel=true
```

允许 Gradle 并行执行可独立的项目任务，不代表业务线程自动变多。

## 第 5 行

```text
android.useAndroidX=true
```

启用 AndroidX 依赖体系支持；本项目页面主要使用平台原生 View。

## 第 6 行

```text
android.nonTransitiveRClass=true
```

使用非传递 R 类，各模块只生成自己的资源索引，减少资源耦合。

## 第 7 行

```text
android.overridePathCheck=true
```

绕过 Android 插件对工程路径字符的检查，供本机中文目录使用，不修复所有第三方工具的路径兼容问题。

## 第 8 行

```text
（原文件此行为空）
```

空行，仅帮助阅读，不改变配置。

## 第 9 行

```text
# Enabled parallel sync for Gradle 9.4+
```

配置注释，不执行；正文记录该项的适用环境或工具生成来源。

## 第 10 行

```text
org.gradle.tooling.parallel=true
```

启用支持此属性的 Gradle 工具并行同步；实际能力取决于运行版本。
