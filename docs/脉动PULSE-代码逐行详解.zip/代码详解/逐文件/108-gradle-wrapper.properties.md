# gradle/wrapper/gradle-wrapper.properties

构建工具读取的工程配置，逐行说明其取值和实际影响。

原文件 SHA-256：`f847316fccf58162dc7076d8fb633c3fffd472dff7ca6d11bb72374adbd1e95d`。行号仅对应此快照；修改源码后应重新核对。

共 9 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
#Sun Sep 13 16:39:23 CST 2026
```

配置注释，不执行；正文记录该项的适用环境或工具生成来源。

## 第 2 行

```text
distributionBase=GRADLE_USER_HOME
```

distributionBase=GRADLE_USER_HOME：下载解压的 Gradle 分发根目录，GRADLE_USER_HOME 是用户缓存目录。

## 第 3 行

```text
distributionPath=wrapper/dists
```

distributionPath=wrapper/dists：分发版本在根目录下的相对子目录。

## 第 4 行

```text
distributionSha256Sum=553c78f50dafcd54d65b9a444649057857469edf836431389695608536d6b746
```

distributionSha256Sum=553c78f50dafcd54d65b9a444649057857469edf836431389695608536d6b746：下载 zip 的 SHA-256 校验值，帮助检测文件是否被篡改或损坏。

## 第 5 行

```text
distributionUrl=https\://services.gradle.org/distributions/gradle-9.5.0-bin.zip
```

distributionUrl=https\://services.gradle.org/distributions/gradle-9.5.0-bin.zip：wrapper 选择的 Gradle 9.5.0 二进制分发地址，https\: 是 properties 转义。

## 第 6 行

```text
networkTimeout=10000
```

networkTimeout=10000：wrapper 网络操作超时，单位毫秒。

## 第 7 行

```text
validateDistributionUrl=true
```

validateDistributionUrl=true：是否校验分发 URL。

## 第 8 行

```text
zipStoreBase=GRADLE_USER_HOME
```

zipStoreBase=GRADLE_USER_HOME：下载 zip 的缓存根目录。

## 第 9 行

```text
zipStorePath=wrapper/dists
```

zipStorePath=wrapper/dists：zip 在缓存根下的相对子目录。
