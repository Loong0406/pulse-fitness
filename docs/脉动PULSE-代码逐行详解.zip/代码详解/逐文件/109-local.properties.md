# local.properties

当前电脑专用 Android SDK 路径，换电脑可由 Android Studio 重新生成。

原文件 SHA-256：`7d20e3eb776b88a4abe020afc24563194299f9f9038f7ac97b645edbce50cbdd`。行号仅对应此快照；修改源码后应重新核对。

共 1 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
sdk.dir=D\:/Android studio/Android SDK
```

sdk.dir 指向现有 Android SDK；D\: 中反斜杠转义 properties 的冒号，空格属于路径一部分。此设置不会新建盘符。
