# scripts/Build.ps1

统一构建验证脚本；只讲解而不在本次文档工作中执行构建或安装。

原文件 SHA-256：`f64e5158910a57e598a68dc4e5a393cf59c9308c35d4291883f78d9f6de7c758`。行号仅对应此快照；修改源码后应重新核对。

共 9 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
param([switch]$Offline)
```

定义可选开关 -Offline，传入时只使用已有缓存。

## 第 2 行

```text
. (Join-Path $PSScriptRoot 'Common.ps1')
```

点调用 Common.ps1，让其中 JDK 选择及 ProjectRoot 变量在当前脚本作用域生效。

## 第 3 行

```text
$arguments = @(':core:test',':server:test',':app:lintDebug',':app:assembleDebug',':server:installDist','--console=plain')
```

Gradle 任务数组依次指定核心/服务测试、Android Lint、debug APK、服务分发，plain 输出便于终端阅读。

## 第 4 行

```text
if ($Offline) { $arguments += '--offline' }
```

-Offline 为 true 就追加 --offline；缺依赖缓存时会失败，不会凭空生成依赖。

## 第 5 行

```text
& (Join-Path $ProjectRoot 'gradlew.bat') @arguments
```

& 调用本工程 wrapper；@arguments 将数组每项作为独立参数传入。

## 第 6 行

```text
if ($LASTEXITCODE -ne 0) { throw 'Build or validation failed. See output above.' }
```

非零退出码立即 throw，防止把失败构建当成功交付。

## 第 7 行

```text
New-Item -ItemType Directory -Path (Join-Path $ProjectRoot 'deliverables') -Force | Out-Null
```

创建 deliverables 文件夹，存在时 -Force 不报错，丢弃命令返回对象。

## 第 8 行

```text
Copy-Item -LiteralPath (Join-Path $ProjectRoot 'app\build\outputs\apk\debug\app-debug.apk') -Destination (Join-Path $ProjectRoot 'deliverables\PulseFitness-debug.apk') -Force
```

将生成的 debug APK 复制到交付路径，同名覆盖；这不会自动安装到手机。

## 第 9 行

```text
Write-Output 'Ready: deliverables\PulseFitness-debug.apk'
```

打印交付文件相对路径。
