# scripts/Common.ps1

构建脚本共用的本机 JDK 选择，不修改系统全局 JAVA_HOME，只影响当前进程及其子进程。

原文件 SHA-256：`1591be430c5e5d161d8a2bda3c3cbbf7448dbb837c6af89f62d0f3b2efacae36`。行号仅对应此快照；修改源码后应重新核对。

共 28 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
$ErrorActionPreference = 'Stop'
```

PowerShell 非终止错误提升为终止行为，便于脚本失败时停止。

## 第 2 行

```text
$ProjectRoot = Split-Path -Parent $PSScriptRoot
```

从脚本目录的上一级计算项目根目录。

## 第 3 行

```text
function Use-ProjectJdk {
```

定义选择本项目 JDK 的函数，定义时不会立即执行函数体。

## 第 4 行

```text
    $requiredVersion=21
```

未发现守护进程 JDK 条件时默认最低 21。

## 第 5 行

```text
    $criteriaFile=Join-Path $ProjectRoot 'gradle\gradle-daemon-jvm.properties'
```

拼出 Gradle daemon JVM 条件文件路径。

## 第 6 行

```text
    if ((Test-Path -LiteralPath $criteriaFile) -and ([IO.File]::ReadAllText($criteriaFile) -match '(?m)^toolchainVersion=(\d+)')) { $requiredVersion=[int]$Matches[1] }
```

文件存在且匹配 toolchainVersion=数字时，提取版本号；(?m) 让 ^ 匹配每行行首。

## 第 7 行

```text
    $candidates = @($env:JAVA_HOME)
```

候选数组先放当前进程 JAVA_HOME。

## 第 8 行

```text
    $javaCommand = Get-Command java.exe -ErrorAction SilentlyContinue
```

查 PATH 的 java.exe，找不到时静默继续。

## 第 9 行

```text
    if ($javaCommand) { $candidates += Split-Path -Parent (Split-Path -Parent $javaCommand.Source) }
```

从 java.exe 路径上溯两级取得 JDK 根目录。

## 第 10 行

```text
    $adoptium = Join-Path $env:ProgramFiles 'Eclipse Adoptium'
```

拼出 Adoptium 安装目录。

## 第 11 行

```text
    if (Test-Path -LiteralPath $adoptium) { $candidates += Get-ChildItem -LiteralPath $adoptium -Directory | Select-Object -ExpandProperty FullName }
```

若存在，枚举其直接子目录作为 JDK 候选，不递归修改文件。

## 第 12 行

```text
    $candidates += @('D:\Android studio\Android studio\jbr', (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'))
```

再添加本机 Android Studio 和默认安装路径下的 jbr 候选。

## 第 13 行

```text
    foreach ($candidate in $candidates) {
```

逐个检查候选。

## 第 14 行

```text
        if (-not $candidate) { continue }
```

空候选跳过，防止 Join-Path 空参数错误。

## 第 15 行

```text
        $releaseFile = Join-Path $candidate 'release'
```

每个 JDK 根目录下的 release 文件记录版本信息。

## 第 16 行

```text
        if (Test-Path -LiteralPath $releaseFile) {
```

只有 release 文件存在才检查。

## 第 17 行

```text
            $release = [IO.File]::ReadAllText($releaseFile)
```

读取整个 release 文件文本。

## 第 18 行

```text
            if ($release -match 'JAVA_VERSION="(\d+)') {
```

从 JAVA_VERSION 中提取主版本号。

## 第 19 行

```text
                $major=[int]$Matches[1]
```

将捕获字符串转整数。

## 第 20 行

```text
                $matchesCriteria=if(Test-Path -LiteralPath $criteriaFile){$major -eq $requiredVersion}else{$major -ge $requiredVersion}
```

有 daemon 条件文件必须精确匹配主版本；没有则允许大于等于默认最低版本。

## 第 21 行

```text
                if ($matchesCriteria -and (Test-Path -LiteralPath (Join-Path $candidate 'bin\java.exe'))) { $env:JAVA_HOME=$candidate; return }
```

版本满足且 bin/java.exe 存在就设置当前进程 JAVA_HOME 并返回，首个有效候选优先。

## 第 22 行

```text
            }
```

结束当前配置块/条件/循环，按最近未关闭的花括号配对。

## 第 23 行

```text
        }
```

结束当前配置块/条件/循环，按最近未关闭的花括号配对。

## 第 24 行

```text
    }
```

结束当前配置块/条件/循环，按最近未关闭的花括号配对。

## 第 25 行

```text
    throw "Choose an installed JDK matching version $requiredVersion or the Android Studio bundled JDK."
```

没找到匹配 JDK 抛出明确错误，不静默使用错误版本。

## 第 26 行

```text
}
```

结束当前配置块/条件/循环，按最近未关闭的花括号配对。

## 第 27 行

```text
Use-ProjectJdk
```

实际执行 JDK 选择函数。

## 第 28 行

```text
Set-Location -LiteralPath $ProjectRoot
```

把当前工作目录切到项目根，后续相对路径统一。
