# scripts/Start-Server.ps1

可选启动 Java 网关，不下载或启动任何大模型；默认模型地址为空。

原文件 SHA-256：`ddbeaaaa5eed809ca382de675c02fd9b71a1590ddee305b3163d7b75b77bed55`。行号仅对应此快照；修改源码后应重新核对。

共 21 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
param([string]$AiBaseUrl='',[string]$Model='configured-model',[int]$Port=8080,[string]$ListenAddress='127.0.0.1',[switch]$LocalOnly)
```

定义可选模型地址、展示模型名、端口、回环监听地址，以及 LocalOnly 开关。

## 第 2 行

```text
. (Join-Path $PSScriptRoot 'Common.ps1')
```

导入公共路径和 JDK 选择逻辑。

## 第 3 行

```text
& (Join-Path $ProjectRoot 'gradlew.bat') '-PserverOnly=true' ':server:installDist' '--console=plain'
```

以 serverOnly 构建服务分发，不把 Android 模块纳入本次构建。

## 第 4 行

```text
if ($LASTEXITCODE -ne 0) { throw 'Server build failed.' }
```

构建失败立即停止。

## 第 5 行

```text
$runtime = Join-Path $ProjectRoot '.runtime'
```

本机运行资料保存在工程内 .runtime。

## 第 6 行

```text
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
```

创建目录；本脚本没有创建盘符的操作。

## 第 7 行

```text
if (-not $env:APP_TOKEN) {
```

当前环境未设置 APP_TOKEN 才生成或复用本地开发令牌。

## 第 8 行

```text
    $tokenFile = Join-Path $runtime 'dev-token.txt'
```

本地开发令牌文件路径。

## 第 9 行

```text
    if (Test-Path -LiteralPath $tokenFile) { $env:APP_TOKEN = [IO.File]::ReadAllText($tokenFile).Trim() }
```

文件存在就读入环境变量，后面不把实际令牌写到日志。

## 第 10 行

```text
    else {
```

不存在则进入生成分支。

## 第 11 行

```text
        $random = [Security.Cryptography.RandomNumberGenerator]::Create()
```

创建密码学随机数生成器。

## 第 12 行

```text
        $bytes = New-Object byte[] 24
```

准备 24 字节数组。

## 第 13 行

```text
        $random.GetBytes($bytes); $random.Dispose()
```

填充随机字节并释放随机源资源。

## 第 14 行

```text
        $env:APP_TOKEN = ([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant()
```

转成无短横线、小写十六进制，24 字节变 48 字符。

## 第 15 行

```text
        [IO.File]::WriteAllText($tokenFile,$env:APP_TOKEN)
```

将开发令牌写入本机文件；这是开发便利机制，不是部署后的密钥管理系统。

## 第 16 行

```text
    }
```

结束当前配置块/条件/循环，按最近未关闭的花括号配对。

## 第 17 行

```text
}
```

结束当前配置块/条件/循环，按最近未关闭的花括号配对。

## 第 18 行

```text
$env:HOST=$ListenAddress; $env:PORT=[string]$Port; $env:AI_MODEL=$Model
```

设置传给 Java 子进程的监听地址、端口和模型名环境变量。

## 第 19 行

```text
if ($LocalOnly) { $env:AI_BASE_URL='' } else { $env:AI_BASE_URL=$AiBaseUrl }
```

LocalOnly 则清空 AI_BASE_URL，否则用用户传入地址；两者都不会启动模型。

## 第 20 行

```text
Write-Output 'Copy the gateway token from .runtime\dev-token.txt into the app connection settings. Keep this terminal open; Ctrl+C stops the server.'
```

打印如何从本机文件取开发令牌及 Ctrl+C 停止说明，不输出令牌本身。

## 第 21 行

```text
& (Join-Path $env:JAVA_HOME 'bin\java.exe') '-cp' (Join-Path $ProjectRoot 'server\build\install\server\lib\*') 'com.pulse.server.FitnessServer'
```

调用已选 JDK，classpath 指向服务依赖 jar，前台运行 FitnessServer；窗口关闭或 Ctrl+C 会结束服务。
