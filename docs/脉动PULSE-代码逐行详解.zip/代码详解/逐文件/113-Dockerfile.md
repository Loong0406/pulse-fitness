# server/Dockerfile

两阶段镜像：先编译 Java 分发，再将运行结果复制进较小 JRE 镜像；不包含模型。

原文件 SHA-256：`3c7198d3ccc9a582316999c503ae58e4883e4923dc78c4f50df0eb74a6e02c13`。行号仅对应此快照；修改源码后应重新核对。

共 15 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
FROM eclipse-temurin:21-jdk AS build
```

构建阶段使用 Temurin JDK 21，阶段名 build；若保留工程 daemon JDK25 条件，wrapper 仍可能下载匹配工具链，离线容器需提前准备。

## 第 2 行

```text
WORKDIR /workspace
```

构建工作目录 /workspace。

## 第 3 行

```text
COPY gradlew settings.gradle.kts build.gradle.kts gradle.properties ./
```

复制 wrapper 启动脚本和根构建文件，尚未复制 Android 模块。

## 第 4 行

```text
COPY gradle ./gradle
```

复制 Gradle wrapper 目录及 daemon 条件文件。

## 第 5 行

```text
COPY core ./core
```

复制 core 模块。

## 第 6 行

```text
COPY server ./server
```

复制 server 模块。

## 第 7 行

```text
RUN chmod +x gradlew && ./gradlew -PserverOnly=true :server:installDist --no-daemon
```

给 Unix wrapper 执行权，再仅构建 Java 服务分发；--no-daemon 避免保留长期守护进程。

## 第 8 行

```text
（原文件此行为空）
```

空行，仅帮助阅读，不改变配置。

## 第 9 行

```text
FROM eclipse-temurin:21-jre
```

运行阶段使用 JRE 21，Java 17 目标字节码可运行在更高版本 JRE。

## 第 10 行

```text
WORKDIR /app
```

运行工作目录 /app。

## 第 11 行

```text
COPY --from=build /workspace/server/build/install/server /app
```

从 build 阶段复制完整服务分发，包含启动器及依赖。

## 第 12 行

```text
ENV HOST=0.0.0.0 PORT=8080
```

默认容器内监听全部地址和 8080 端口；非回环监听要求有效长度令牌。

## 第 13 行

```text
USER 10001
```

以数值用户 10001 而非 root 运行。

## 第 14 行

```text
EXPOSE 8080
```

声明使用 8080，不代表自动开放宿主端口。

## 第 15 行

```text
ENTRYPOINT ["/app/bin/server"]
```

容器主进程运行分发启动脚本。
