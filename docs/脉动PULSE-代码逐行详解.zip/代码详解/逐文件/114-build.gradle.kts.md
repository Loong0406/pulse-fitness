# server/build.gradle.kts

独立 Java 应用模块，生成带依赖启动目录，可选运行，不自动部署模型。

原文件 SHA-256：`57d9197631f524fd95f6d203e3b3e62889977df27a28cbfe03901829f620e50e`。行号仅对应此快照；修改源码后应重新核对。

共 11 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
plugins { application }
```

application 插件提供 run 和 installDist 等任务。

## 第 2 行

```text
java {
```

开始 Java 配置。

## 第 3 行

```text
    sourceCompatibility = JavaVersion.VERSION_17
```

源语言级别 17。

## 第 4 行

```text
    targetCompatibility = JavaVersion.VERSION_17
```

目标字节码级别 17。

## 第 5 行

```text
}
```

结束 Java 配置。

## 第 6 行

```text
application { mainClass = "com.pulse.server.FitnessServer" }
```

设置 Java 可执行入口类，installDist 生成的启动器调用它。

## 第 7 行

```text
tasks.withType<JavaCompile>().configureEach { options.encoding = "UTF-8" }
```

所有 Java 源码 UTF-8。

## 第 8 行

```text
dependencies {
```

开始依赖配置。

## 第 9 行

```text
    implementation(project(":core"))
```

服务器复用 core 的领域模型、规则、JSON 和校验器。

## 第 10 行

```text
    testImplementation("junit:junit:4.13.2")
```

测试依赖 JUnit，不属于服务生产运行包。

## 第 11 行

```text
}
```

结束依赖声明。
