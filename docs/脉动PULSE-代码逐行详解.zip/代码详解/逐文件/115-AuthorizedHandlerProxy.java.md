# server/src/main/java/com/pulse/server/AuthorizedHandlerProxy.java

HTTP 鉴权代理，先判断网关令牌，再转发给真正计划处理器。

原文件 SHA-256：`f27c6d5e018e669aee0aa9e2455958ae28d4f91523304ead050259b8d3690572`。行号仅对应此快照；修改源码后应重新核对。

共 22 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.server;
```

声明本文件所属包 com.pulse.server；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.sun.net.httpserver.*;
```

导入类型命名空间 com.sun.net.httpserver.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.io.IOException;
```

导入类型命名空间 java.io.IOException，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.nio.charset.StandardCharsets;
```

导入类型命名空间 java.nio.charset.StandardCharsets，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.security.MessageDigest;
```

导入类型命名空间 java.security.MessageDigest，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 8 行

```java
/** Proxy controls access before the actual plan handler is invoked. */
```

源码注释，不参与执行。HTTP 鉴权代理，先判断网关令牌，再转发给真正计划处理器。

## 第 9 行

```java
public final class AuthorizedHandlerProxy implements HttpHandler {
```

定义 public final class AuthorizedHandlerProxy implements HttpHandler。实现 HttpHandler 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 10 行

```java
    private final HttpHandler target;
```

真正处理请求的目标对象。

## 第 11 行

```java
    private final String token;
```

配置的 APP_TOKEN，区别于模型供应商 AI_API_KEY。

## 第 12 行

```java
    public AuthorizedHandlerProxy(String token,HttpHandler target){this.token=token;this.target=target;}
```

构造器注入令牌和目标处理器。

## 第 13 行

```java
    @Override public void handle(HttpExchange exchange)throws IOException{
```

实现 HttpHandler 的请求回调，允许 IO 异常。

## 第 14 行

```java
        if(!token.isEmpty()){
```

配了非空令牌才检查；空令牌的回环开发服务会跳过认证。

## 第 15 行

```java
            String value=exchange.getRequestHeaders().getFirst("Authorization");
```

从 HTTP 请求头读 Authorization。

## 第 16 行

```java
            if(value==null||!MessageDigest.isEqual(("Bearer "+token).getBytes(StandardCharsets.UTF_8),value.getBytes(StandardCharsets.UTF_8))){
```

比较完整“Bearer 空格令牌”字节；MessageDigest.isEqual 用于比较敏感字节，避免普通字符串逐字符比较方式。

## 第 17 行

```java
                FitnessServer.json(exchange,401,"{\"error\":\"服务访问令牌无效\"}");return;
```

缺失或不匹配返回 401 JSON，return 保证不会调用目标。

## 第 18 行

```java
            }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 19 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 20 行

```java
        target.handle(exchange);
```

通过检查才把同一个 HttpExchange 转交真实处理器。

## 第 21 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 22 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
