# server/src/main/java/com/pulse/server/CompatibleLlmAdapter.java

把兼容 Chat Completions 的模型服务报文适配为 WeekPlan。按现有代码说明，不保证任何第三方服务都支持这些 JSON Schema 关键字。

原文件 SHA-256：`eae062bda8a689e4d9105d68fd63e2d19a025e56439d43369db682fc27558df3`。行号仅对应此快照；修改源码后应重新核对。

共 90 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.server;
```

声明本文件所属包 com.pulse.server；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.google.gson.*;
```

导入类型命名空间 com.google.gson.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.net.URI;
```

导入类型命名空间 java.net.URI，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import java.net.http.*;
```

导入类型命名空间 java.net.http.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import java.time.Duration;
```

导入类型命名空间 java.time.Duration，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.util.*;
```

导入类型命名空间 java.util.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 12 行

```java
/** Adapter: provider chat-completion messages become the domain PlanGenerator contract. */
```

源码注释，不参与执行。把兼容 Chat Completions 的模型服务报文适配为 WeekPlan。按现有代码说明，不保证任何第三方服务都支持这些 JSON Schema 关键字。

## 第 13 行

```java
public final class CompatibleLlmAdapter extends PlanGenerationTemplate {
```

定义 public final class CompatibleLlmAdapter extends PlanGenerationTemplate。继承 PlanGenerationTemplate 的实现与扩展点。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 14 行

```java
    private final URI endpoint;
```

模型上游完整 HTTP URI。

## 第 15 行

```java
    private final String model,key;
```

模型名与供应商密钥；密钥保留服务端，不打入 APK。

## 第 16 行

```java
    private final HttpClient client;
```

JDK HttpClient 实例，复用连接能力。

## 第 17 行

```java
    public CompatibleLlmAdapter(String baseUrl,String model,String key){
```

构造器接收上游基础地址、模型名、密钥。

## 第 18 行

```java
        endpoint=URI.create(baseUrl.replaceAll("/+$","")+"/chat/completions");
```

去末尾斜线再接 /chat/completions，例如基础地址包含 /v1 时得到 /v1/chat/completions。

## 第 19 行

```java
        if(!Set.of("http","https").contains(endpoint.getScheme())||endpoint.getHost()==null)throw new IllegalArgumentException("AI_BASE_URL 必须是 http(s) 地址");
```

只允许 http/https 且必须有主机。

## 第 20 行

```java
        this.model=model;this.key=key;client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
```

保存参数，并给 HTTP 客户端设置 8 秒连接超时。

## 第 21 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 22 行

```java
    @Override protected WeekPlan createCandidate(UserProfile p)throws Exception{
```

模板方法的候选生成扩展点。

## 第 23 行

```java
        JsonObject body=new JsonObject();body.addProperty("model",model);body.addProperty("stream",false);
```

创建请求 JSON，填 model，stream=false 表示等待完整返回而非流式片段。

## 第 24 行

```java
        body.addProperty("temperature",0.35);body.addProperty("max_tokens",4500);
```

temperature=0.35，max_tokens=4500；这些是请求参数，实际含义和支持程度取决于服务提供方。

## 第 25 行

```java
        JsonObject format=new JsonObject();format.addProperty("type","json_schema");
```

请求结构化输出格式 json_schema。

## 第 26 行

```java
        JsonObject definition=new JsonObject();definition.addProperty("name","fitness_plan");definition.addProperty("strict",true);definition.add("schema",outputSchema(p));format.add("json_schema",definition);body.add("response_format",format);
```

构建名 fitness_plan、strict=true、schema 对象，放入 response_format；是否严格实现由上游能力决定，本地仍会复检。

## 第 27 行

```java
        JsonArray messages=new JsonArray();
```

创建 messages 数组。

## 第 28 行

```java
        JsonObject system=new JsonObject();system.addProperty("role","system");system.addProperty("content",systemPrompt(p));messages.add(system);
```

添加 system 消息，内容由本机规则、时间预算和允许动作目录生成。

## 第 29 行

```java
        // No name or sex is sent: neither is needed to choose safe movements.
```

源码注释，不参与执行。昵称和性别不用于这里选择允许动作，向上游模型发请求前将删除这两个字段。

## 第 30 行

```java
        JsonObject trainingProfile=JsonParser.parseString(JsonCodec.profile(p)).getAsJsonObject();trainingProfile.remove("name");trainingProfile.remove("sex");
```

档案先转 JSON，再删 name/sex，只向上游发训练需要的字段；手机→网关的请求仍包含原完整档案。

## 第 31 行

```java
        JsonObject user=new JsonObject();user.addProperty("role","user");user.addProperty("content","为此档案生成七天训练计划，只返回 JSON："+trainingProfile+" /no_think");messages.add(user);body.add("messages",messages);
```

添加 user 消息要求七天 JSON；/no_think 只是提示字符串，能否生效由上游决定；把消息数组放入正文。

## 第 32 行

```java
        HttpRequest.Builder request=HttpRequest.newBuilder(endpoint).timeout(Duration.ofSeconds(150)).header("Content-Type","application/json");
```

建立 HTTP 请求，单次 request timeout 150 秒并声明 JSON。

## 第 33 行

```java
        if(key!=null&&!key.isBlank())request.header("Authorization","Bearer "+key);
```

key 非空才加供应商 Bearer 认证头。

## 第 34 行

```java
        java.util.concurrent.CompletableFuture<HttpResponse<byte[]>> pending=client.sendAsync(request.POST(HttpRequest.BodyPublishers.ofString(body.toString())).build(),new LimitedBodyHandler(262144));
```

异步 POST，BodyPublisher 把 JSON 文本发出去；用 LimitedBodyHandler 限返回最多 256KiB。

## 第 35 行

```java
        HttpResponse<byte[]> response;
```

声明响应对象。

## 第 36 行

```java
        try{response=pending.get(155,java.util.concurrent.TimeUnit.SECONDS);}catch(Exception failure){pending.cancel(true);throw failure;}
```

最多等待 155 秒，失败则取消 pending 并把异常向上传播，由网关决定回退。

## 第 37 行

```java
        byte[] bytes=response.body();
```

取已限长的响应字节。

## 第 38 行

```java
        if(response.statusCode()/100!=2)throw new IllegalStateException("模型服务未正常返回");
```

非 2xx 拒绝，不把供应商原始错误正文透传到手机。

## 第 39 行

```java
        String content=JsonParser.parseString(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
```

按 UTF-8 解析兼容响应，依次取 choices[0].message.content；结构缺失会抛异常并触发回退。

## 第 40 行

```java
        return adapt(content,p);
```

将模型内容适配成受控领域计划。

## 第 41 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 42 行

```java
    public static WeekPlan adapt(String content,UserProfile p){
```

静态适配入口，测试可不连接模型直接传字符串验证。

## 第 43 行

```java
        String json=content.trim();int endThink=json.lastIndexOf("</think>");if(endThink>=0)json=json.substring(endThink+8).trim();
```

去首尾空白；若有 </think>，舍弃最后该标签之前的内容，避免思考文本干扰 JSON。

## 第 44 行

```java
        if(json.startsWith("```")){int newline=json.indexOf('\n');int end=json.lastIndexOf("```");if(newline>=0&&end>newline)json=json.substring(newline+1,end).trim();}
```

若是 Markdown 代码围栏，取第一个换行和最后围栏之间的内容；不是任意自然语言 JSON 提取器。

## 第 45 行

```java
        JsonObject o=JsonParser.parseString(json).getAsJsonObject();
```

将剩余内容解析为 JSON 对象。

## 第 46 行

```java
        String note=JsonCodec.str(o,"note");
```

严格读取 note 字符串。

## 第 47 行

```java
        WeekPlan plan=new WeekPlan(UUID.randomUUID().toString(),System.currentTimeMillis(),p.signature(),WeekPlan.Source.AI,note,JsonCodec.days(o.getAsJsonArray("days")));
```

计划 ID、时间、档案签名和 AI 来源由服务器自己生成，不信任模型传来的身份字段；天表经 JsonCodec 重建。

## 第 48 行

```java
        PlanSafety.validate(plan,p);return plan;
```

进行最终安全校验，成功才返回。

## 第 49 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 50 行

```java
    private static String systemPrompt(UserProfile p){
```

构建 system 提示词入口。

## 第 51 行

```java
        JsonArray catalog=new JsonArray();for(Exercise e:ExerciseCatalog.allowed(p)){JsonObject x=new JsonObject();x.addProperty("id",e.id);x.addProperty("name",e.name);x.addProperty("group",e.group);x.addProperty("timed",e.timed);catalog.add(x);}
```

遍历此档案允许动作，输出 ID、名字、部位、计时标志作为模型动作白名单。

## 第 52 行

```java
        int maxSets=schemaMaxSets(p);
```

算每动作最大组数，用于提示和结构化约束。

## 第 53 行

```java
        return "你是一般健身计划助手，不提供医疗、康复或饮食处方。档案已通过年龄与健康门槛。只使用下列允许动作，不添加自由文本动作。根据目标、经验、器械和限制选择不同动作与负荷。训练日交替侧重不同部位，避免连续高负荷。"
```

提示限定一般训练用途、只用允许动作并要求按人群和目标选择。

## 第 54 行

```java
                +"严格返回 JSON 对象：{\"note\":\"中文简短个性化理由和强度建议\",\"days\":[{\"dayIndex\":0,\"title\":\"中文标题\",\"exercises\":[{\"exerciseId\":\"wall_push\",\"sets\":2,\"amount\":10,\"restSeconds\":45}]}]}。"
```

用字符串给出输出 JSON 的形状示例；反斜杠引号是 Java 字符串转义。

## 第 55 行

```java
                +"days 必须恰好7项，dayIndex按0到6排序。训练日索引为"+scheduled(p)+"，其余为休息日exercises=[]。每训练日2到"+schemaMaxExercises(p)+"个不同动作；每动作1到"+maxSets+"组；计次动作6到15次，计时动作15到45秒；休息固定45秒；每天不超过18组。note只简短解释目标与动作选择，不重复负荷数字，不提供医疗或饮食建议。"
```

明确七天顺序、训练日索引、数量/负荷/休息及说明文本限制。

## 第 56 行

```java
                +"时间约束严格满足：480 + sum(sets*(timed ? amount : amount*3)+sets*restSeconds) <= "+(p.minutesPerSession*60)+"秒，480秒是热身和放松。较短的训练优先2动作×2组、10次、休息45秒。"
```

写入 480 秒热身放松+各组训练与休息的时间公式，并给短训练参考；模型提示本身不是强制校验。

## 第 57 行

```java
                +"不要解释思考过程，不要Markdown。允许动作："+catalog;
```

要求纯 JSON 不输出 Markdown，附上白名单目录。

## 第 58 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 59 行

```java
    private static int schemaMaxSets(UserProfile p){return p.experience==UserProfile.Experience.BEGINNER||p.age>=60||p.daysPerWeek>=4||p.minutesPerSession<20?2:4;}
```

新手、长者、高频或短时最多 2 组，其他最多 4 组；短时条件比通用 PlanSafety 更严格。

## 第 60 行

```java
    private static int schemaMaxExercises(UserProfile p){return Math.min(5,Math.min(18/schemaMaxSets(p),(p.minutesPerSession*60-480)/(schemaMaxSets(p)*90)));}
```

动作数量上限同时受 5 个、总组数 18 和时间预算约束；每组按最多 45 秒训练+45 秒休息估算。

## 第 61 行

```java
    private static Set<Integer> scheduled(UserProfile p){Set<Integer> result=new LinkedHashSet<>();for(int i=0;i<p.daysPerWeek;i++)result.add(i*7/p.daysPerWeek);return result;}
```

用 LinkedHashSet 保留训练日顺序，整数均匀散布算法与本地生成器一致。

## 第 62 行

```java
    /** JSON Schema constrains structure at decoding time, including exact training/rest dates.
```

源码注释，不参与执行。JSON Schema 希望在上游生成阶段限制结构与七个训练/恢复位置；实际支持取决于上游。

## 第 63 行

```java
     * Per-set time is <= 45 seconds + 45 rest, so the item/sets bounds guarantee the time budget. */
```

源码注释，不参与执行。每组训练最多 45 秒、休息 45 秒，配合组数和动作数上限，使 schema 预算不超可用时长。

## 第 64 行

```java
    static JsonObject outputSchema(UserProfile p){
```

构造结构化输出 JSON Schema 的入口。

## 第 65 行

```java
        JsonObject schema=object();JsonObject properties=schema.getAsJsonObject("properties");
```

根对象禁止额外字段，取得 properties 继续添加属性定义。

## 第 66 行

```java
        JsonObject note=type("string");note.addProperty("maxLength",600);properties.add("note",note);
```

note 必须字符串，最多 600 字符，比通用结果校验的 1200 更严格。

## 第 67 行

```java
        JsonObject days=type("array");days.addProperty("minItems",7);days.addProperty("maxItems",7);
```

days 必须数组且恰好七项。

## 第 68 行

```java
        JsonArray prefix=new JsonArray();Set<Integer> training=scheduled(p);
```

prefix 用于分别约束七个位置，training 是训练日集合。

## 第 69 行

```java
        for(int day=0;day<7;day++){
```

遍历周内七天。

## 第 70 行

```java
            JsonObject d=object(),dp=d.getAsJsonObject("properties");JsonObject index=type("integer");index.addProperty("const",day);dp.add("dayIndex",index);
```

每天建对象 schema，dayIndex 为 integer 且 const 等于当前位置。

## 第 71 行

```java
            JsonObject title=type("string");title.addProperty("maxLength",48);dp.add("title",title);
```

title 为字符串，最多 48 字符。

## 第 72 行

```java
            JsonObject exercises=type("array");exercises.addProperty("minItems",training.contains(day)?2:0);exercises.addProperty("maxItems",training.contains(day)?schemaMaxExercises(p):0);
```

exercises 数组：训练日至少 2、最多由预算算出，恢复日最少最多均为 0。

## 第 73 行

```java
            JsonObject rx=object(),rp=rx.getAsJsonObject("properties");JsonObject id=type("string");JsonArray ids=new JsonArray();for(Exercise e:ExerciseCatalog.allowed(p))ids.add(e.id);id.add("enum",ids);rp.add("exerciseId",id);
```

创建一个候选处方 schema，动作 ID 枚举只含该档案允许动作。

## 第 74 行

```java
            rp.add("sets",integer(1,schemaMaxSets(p)));rp.add("amount",integer(6,45));JsonObject rest=type("integer");rest.addProperty("const",45);rp.add("restSeconds",rest);required(rx,"exerciseId","sets","amount","restSeconds");
```

为该候选添加组数、数量、固定 45 秒休息及必需字段。注意 rx 在当前实现后续没有挂到结果 schema，实际使用下面 anyOf 分支。

## 第 75 行

```java
            // Conditional amount ranges retain compatibility with timed and repetition-based catalog actions.
```

源码注释，不参与执行。为计时和计次两种动作建立不同数量范围，避免把 30 秒误当 30 次。

## 第 76 行

```java
            JsonArray alternatives=new JsonArray();
```

为计时与计次分别准备互斥类型分支。

## 第 77 行

```java
            for(boolean timed:new boolean[]{false,true}){
```

遍历 timed=false 与 true 两类动作。

## 第 78 行

```java
                JsonArray subset=new JsonArray();for(Exercise e:ExerciseCatalog.allowed(p))if(e.timed==timed)subset.add(e.id);
```

收集此类型允许的动作 ID。

## 第 79 行

```java
                if(subset.isEmpty())continue;
```

某类型没有动作则跳过，避免空 enum 分支。

## 第 80 行

```java
                JsonObject branch=object(),bp=branch.getAsJsonObject("properties");JsonObject bid=type("string");bid.add("enum",subset);bp.add("exerciseId",bid);bp.add("sets",integer(1,schemaMaxSets(p)));bp.add("amount",integer(timed?15:6,timed?45:15));bp.add("restSeconds",rest);required(branch,"exerciseId","sets","amount","restSeconds");alternatives.add(branch);
```

建立实际处方分支：ID 枚举、组数、计次 6–15 或计时 15–45、休息 45，四字段都 required，加入 alternatives。

## 第 81 行

```java
            }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 82 行

```java
            JsonObject choices=new JsonObject();choices.add("anyOf",alternatives);exercises.add("items",choices);dp.add("exercises",exercises);required(d,"dayIndex","title","exercises");prefix.add(d);
```

用 anyOf 允许满足任一计量类型分支，把它挂到 exercises.items，再把日字段设为 required，加入 prefix。

## 第 83 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 84 行

```java
        days.add("prefixItems",prefix);days.add("items",new JsonObject());properties.add("days",days);required(schema,"note","days");return schema;
```

七个位置定义放到 prefixItems；限制长度已保证恰好七项；根必需 note/days，最后返回 schema。

## 第 85 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 86 行

```java
    private static JsonObject type(String value){JsonObject o=new JsonObject();o.addProperty("type",value);return o;}
```

创建只带 type 字段的 schema 小对象。

## 第 87 行

```java
    private static JsonObject integer(int min,int max){JsonObject o=type("integer");o.addProperty("minimum",min);o.addProperty("maximum",max);return o;}
```

创建带 minimum/maximum 的整数 schema。

## 第 88 行

```java
    private static JsonObject object(){JsonObject o=type("object");o.add("properties",new JsonObject());o.addProperty("additionalProperties",false);return o;}
```

创建对象 schema，初始化 properties，additionalProperties=false 禁额外键。

## 第 89 行

```java
    private static void required(JsonObject o,String... fields){JsonArray array=new JsonArray();for(String f:fields)array.add(f);o.add("required",array);}
```

把可变参数字段名依次加入 required 数组，装到指定对象 schema。

## 第 90 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
