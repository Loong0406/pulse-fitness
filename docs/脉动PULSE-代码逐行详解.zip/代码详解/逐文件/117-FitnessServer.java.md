# server/src/main/java/com/pulse/server/FitnessServer.java

可选 Java HTTP 网关：校验手机档案、限制并发、调用模型并诚实回退本地规则；读取源码不等于启动部署。

原文件 SHA-256：`a6e897c58446f7d7b0029ed6a033ef3454a021da15bf8e5cec6fd9dba3d24052`。行号仅对应此快照；修改源码后应重新核对。

共 72 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.server;
```

声明本文件所属包 com.pulse.server；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import com.sun.net.httpserver.*;
```

导入类型命名空间 com.sun.net.httpserver.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import com.google.gson.*;
```

导入类型命名空间 com.google.gson.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.core.validation.ProfileValidator;
```

导入类型命名空间 com.pulse.core.validation.ProfileValidator，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import java.io.*;
```

导入类型命名空间 java.io.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.net.*;
```

导入类型命名空间 java.net.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.nio.charset.StandardCharsets;
```

导入类型命名空间 java.nio.charset.StandardCharsets，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
import java.util.concurrent.*;
```

导入类型命名空间 java.util.concurrent.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 13 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 14 行

```java
/** Small Java 17 HTTP service. Model keys never ship in the Android APK. */
```

源码注释，不参与执行。可选 Java HTTP 网关：校验手机档案、限制并发、调用模型并诚实回退本地规则；读取源码不等于启动部署。

## 第 15 行

```java
public final class FitnessServer {
```

定义 public final class FitnessServer。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 16 行

```java
    private final HttpServer server;
```

JDK 自带 HttpServer 实例。

## 第 17 行

```java
    private final ExecutorService executor;
```

专用有界请求线程池。

## 第 18 行

```java
    private final Semaphore modelSlots=new Semaphore(2);
```

信号量最多同时放行两个计划生成请求。

## 第 19 行

```java
    private final PlanGenerator generator;
```

注入的模型生成器，null 表示仅使用本地规则。

## 第 20 行

```java
    private final String model;
```

用于健康检测展示的模型名。

## 第 21 行

```java
    public FitnessServer(String host,int port,String token,String model,PlanGenerator generator)throws IOException{
```

服务构造器接收监听地址、端口、APP_TOKEN、模型名和生成器。

## 第 22 行

```java
        if(!InetAddress.getByName(host).isLoopbackAddress()&&token.length()<24)throw new IllegalArgumentException("对外监听时 APP_TOKEN 至少 24 字符");
```

监听非回环地址时要求 APP_TOKEN 至少 24 字符；此长度检查不等于随机强度检查。

## 第 23 行

```java
        this.model=model;this.generator=generator;
```

保存模型名和生成器。

## 第 24 行

```java
        server=HttpServer.create(new InetSocketAddress(host,port),16);
```

绑定监听地址和端口，backlog=16 是待接入队列提示；传 0 端口可让系统分配临时端口供测试。

## 第 25 行

```java
        executor=new ThreadPoolExecutor(4,4,0L,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(16),new ThreadPoolExecutor.AbortPolicy());
```

创建固定 4 个线程、容量 16 的任务队列，超过容量用 AbortPolicy 拒绝，避免无限排队。

## 第 26 行

```java
        server.setExecutor(executor);
```

将请求执行交给此线程池。

## 第 27 行

```java
        server.createContext("/health",e->{
```

注册公开 /health 路径处理器，暂不要求 APP_TOKEN。

## 第 28 行

```java
            if(!e.getRequestURI().getPath().equals("/health")){json(e,404,"{\"error\":\"接口不存在\"}");return;}
```

HttpServer context 是前缀匹配，因此额外要求路径恰好 /health，否则 404。

## 第 29 行

```java
            if(!e.getRequestMethod().equals("GET")){json(e,405,"{\"error\":\"仅支持 GET\"}");return;}
```

仅允许 GET，否则 405。

## 第 30 行

```java
            JsonObject o=new JsonObject();o.addProperty("status","ok");o.addProperty("model",model);o.addProperty("modelConfigured",generator!=null);json(e,200,o.toString());
```

返回 ok、模型名和是否配置生成器；此处不调用真实模型，不能证明推理一定可用。

## 第 31 行

```java
        });
```

结束 Lambda 回调的代码块，并关闭注册/提交该回调的方法调用；回调中的语句等事件或任务发生时才执行。

## 第 32 行

```java
        server.createContext("/api/v1/plans",new AuthorizedHandlerProxy(token,this::handlePlan));
```

注册计划路径，并把真实 handlePlan 包在鉴权代理后面。

## 第 33 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 34 行

```java
    private void handlePlan(HttpExchange e)throws IOException{
```

实际计划请求处理入口，只有代理放行才到这里。

## 第 35 行

```java
        try {
```

try 用于捕获处理失败，finally 关闭请求。

## 第 36 行

```java
            if(!e.getRequestURI().getPath().equals("/api/v1/plans")){json(e,404,"{\"error\":\"接口不存在\"}");return;}
```

精确匹配路径，拒绝 /api/v1/plans/unknown 之类前缀碰撞。

## 第 37 行

```java
            if(!e.getRequestMethod().equals("POST")){e.getResponseHeaders().set("Allow","POST");json(e,405,"{\"error\":\"仅支持 POST\"}");return;}
```

仅接受 POST，并在 405 响应中给出 Allow: POST。

## 第 38 行

```java
            String type=e.getRequestHeaders().getFirst("Content-Type");
```

读取正文类型请求头。

## 第 39 行

```java
            if(type==null||!type.toLowerCase(java.util.Locale.ROOT).startsWith("application/json")){json(e,415,"{\"error\":\"请求需为 JSON\"}");return;}
```

Content-Type 必须以 application/json 开头；缺失或其他类型返回 415。

## 第 40 行

```java
            byte[] bytes;try(InputStream input=e.getRequestBody()){bytes=input.readNBytes(32769);}
```

最多读 32769 字节，是“允许的 32768+1”，用于检测超限而不是无限读完；自动关闭输入流。

## 第 41 行

```java
            if(bytes.length>32768){json(e,413,"{\"error\":\"请求过大\"}");return;}
```

超过 32KiB 返回 413。

## 第 42 行

```java
            UserProfile p;
```

声明要恢复的档案变量。

## 第 43 行

```java
            try {p=JsonCodec.profile(new String(bytes,StandardCharsets.UTF_8));ProfileValidator.validateForTraining(p);}
```

UTF-8 解码、JSON 重建档案，并检查能否自动训练。

## 第 44 行

```java
            catch(RuntimeException invalid){JsonObject o=new JsonObject();o.addProperty("error",invalid instanceof IllegalArgumentException?"档案不完整或不适合自动训练，请检查年龄、时间和健康限制":"档案格式无效");json(e,400,o.toString());return;}
```

坏 JSON/坏档案返回 400 固定提示，避免原始报文或异常细节外泄。

## 第 45 行

```java
            if(!modelSlots.tryAcquire()){json(e,429,"{\"error\":\"计划生成繁忙，请稍后重试\"}");return;}
```

立即尝试获取一个生成名额，不阻塞等待；已有两个则 429。

## 第 46 行

```java
            try {
```

获得名额后进入 try/finally，确保归还。

## 第 47 行

```java
                WeekPlan plan;String message;
```

声明结果计划和响应说明。

## 第 48 行

```java
                if(generator==null){plan=new LocalPlanGenerator().generate(p);message="服务尚未配置模型，已生成本地规则计划";}
```

没模型生成器就直接用 LocalPlanGenerator，并明确说明是本地规则。

## 第 49 行

```java
                else {
```

前面的 if 条件不成立时才进入此分支；这里表示已经配置生成器，将尝试模型生成。

## 第 50 行

```java
                    try {plan=new SafePlanGeneratorDecorator(generator).generate(p);message="大模型已生成并通过规则校验";}
```

有模型时先加安全装饰生成；成功说明通过规则检查。

## 第 51 行

```java
                    catch(Exception unavailable){plan=new LocalPlanGenerator().generate(p);message="模型连接失败或输出未通过校验，已改用本地规则计划";}
```

模型连接或输出失败，重新用本地规则生成并明确回退，不把供应商原始错误发给客户端。

## 第 52 行

```java
                }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 53 行

```java
                JsonObject payload=new JsonObject();payload.add("plan",JsonParser.parseString(JsonCodec.plan(plan)));payload.addProperty("message",message);json(e,200,payload.toString());
```

将 plan 作为 JSON 对象加入响应，附 message，返回 200。不是把 JSON 再包成带转义的大字符串。

## 第 54 行

```java
            }finally{modelSlots.release();}
```

无论生成/发送成功失败都释放信号量名额。

## 第 55 行

```java
        }catch(Exception failure){if(e.getResponseCode()==-1)json(e,500,"{\"error\":\"服务暂时不可用\"}");}
```

意外错误且还没发响应时返回通用 500，已经发过则不重复发头。

## 第 56 行

```java
        finally{e.close();}
```

最终关闭 HttpExchange。

## 第 57 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 58 行

```java
    public void start(){server.start();}
```

start 开始监听处理请求，构造本身不执行此方法。

## 第 59 行

```java
    public int port(){return server.getAddress().getPort();}
```

读取实际监听端口，测试端口 0 时尤其有用。

## 第 60 行

```java
    public void stop(){server.stop(0);executor.shutdownNow();}
```

立即停 HTTP 服务并中断线程池，用于测试清理或退出。

## 第 61 行

```java
    static void json(HttpExchange e,int code,String body)throws IOException{
```

共用 JSON 响应工具方法。

## 第 62 行

```java
        byte[] bytes=body.getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");e.getResponseHeaders().set("Cache-Control","no-store");e.getResponseHeaders().set("X-Content-Type-Options","nosniff");
```

UTF-8 编码正文；设置类型、no-store 禁缓存、nosniff 禁类型猜测。

## 第 63 行

```java
        e.sendResponseHeaders(code,bytes.length);try(OutputStream out=e.getResponseBody()){out.write(bytes);}e.close();
```

按字节长度发响应头，再写正文并自动关闭流，最后关闭请求。

## 第 64 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 65 行

```java
    private static String env(String name,String fallback){String s=System.getenv(name);return s==null||s.isBlank()?fallback:s;}
```

环境变量缺失或仅空白则返回默认值，否则保留原值。

## 第 66 行

```java
    public static void main(String[] args)throws Exception{
```

Java 服务可执行 main 入口。

## 第 67 行

```java
        String host=env("HOST","127.0.0.1"),model=env("AI_MODEL","configured-model"),base=env("AI_BASE_URL","");
```

默认回环监听、默认显示模型名；AI_BASE_URL 默认空，因而不要求本地模型。

## 第 68 行

```java
        FitnessServer service=new FitnessServer(host,Integer.parseInt(env("PORT","8080")),env("APP_TOKEN",""),model,base.isEmpty()?null:new CompatibleLlmAdapter(base,model,env("AI_API_KEY","")));
```

解析端口、令牌等变量；base 空则注入 null，否则只创建远程 HTTP 适配器，不下载模型。

## 第 69 行

```java
        Runtime.getRuntime().addShutdownHook(new Thread(service::stop));service.start();
```

注册 JVM 退出时停止服务的钩子，然后正式 start。

## 第 70 行

```java
        System.out.println("PULSE service: http://"+host+":"+service.port()+" | model configured="+!base.isEmpty());
```

控制台输出地址和是否配置模型，不输出令牌或个人档案。

## 第 71 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 72 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
