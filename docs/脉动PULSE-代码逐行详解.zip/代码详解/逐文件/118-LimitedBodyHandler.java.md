# server/src/main/java/com/pulse/server/LimitedBodyHandler.java

限制上游模型响应大小，使用 Java HTTP 响应流订阅机制，避免收到任意大正文后才检查。

原文件 SHA-256：`56da8ce16186bef6feca244731adb702e7a3585e9d39eb94d10dbae731ad0971`。行号仅对应此快照；修改源码后应重新核对。

共 32 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.server;
```

声明本文件所属包 com.pulse.server；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import java.net.http.HttpResponse;
```

导入类型命名空间 java.net.http.HttpResponse，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import java.nio.ByteBuffer;
```

导入类型命名空间 java.nio.ByteBuffer，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 5 行

```java
import java.io.ByteArrayOutputStream;
```

导入类型命名空间 java.io.ByteArrayOutputStream，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import java.util.List;
```

导入类型命名空间 java.util.List，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import java.util.concurrent.*;
```

导入类型命名空间 java.util.concurrent.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import java.util.concurrent.Flow;
```

导入类型命名空间 java.util.concurrent.Flow，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 10 行

```java
/** Bounds upstream bytes before allocating a complete provider response. */
```

源码注释，不参与执行。限制上游模型响应大小，使用 Java HTTP 响应流订阅机制，避免收到任意大正文后才检查。

## 第 11 行

```java
final class LimitedBodyHandler implements HttpResponse.BodyHandler<byte[]> {
```

定义 final class LimitedBodyHandler implements HttpResponse.BodyHandler<byte[]>。实现 HttpResponse.BodyHandler<byte[]> 契约。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 12 行

```java
    private final int limit;
```

最大允许字节数。

## 第 13 行

```java
    LimitedBodyHandler(int limit){this.limit=limit;}
```

构造器记录上限。

## 第 14 行

```java
    public HttpResponse.BodySubscriber<byte[]> apply(HttpResponse.ResponseInfo info){return new Subscriber(limit);}
```

收到响应信息时为该响应创建独立 Subscriber。

## 第 15 行

```java
    private static final class Subscriber implements HttpResponse.BodySubscriber<byte[]> {
```

具体订阅者实现，收到 ByteBuffer 列表并最终提供 byte[]。

## 第 16 行

```java
        private final int limit;
```

当前响应的上限。

## 第 17 行

```java
        private final CompletableFuture<byte[]> result=new CompletableFuture<>();
```

Future 用于把异步正文结果交给 HTTP 客户端。

## 第 18 行

```java
        private final ByteArrayOutputStream bytes=new ByteArrayOutputStream();
```

累加收到的字节。

## 第 19 行

```java
        private Flow.Subscription subscription;
```

保存上游订阅控制句柄，用于按需请求或取消。

## 第 20 行

```java
        Subscriber(int limit){this.limit=limit;}
```

子订阅者构造器保存上限。

## 第 21 行

```java
        public CompletionStage<byte[]> getBody(){return result;}
```

返回未来结果，不在此阻塞等待。

## 第 22 行

```java
        public void onSubscribe(Flow.Subscription s){subscription=s;s.request(1);}
```

保存订阅并请求一批数据，使用背压逐批接收。

## 第 23 行

```java
        public void onNext(List<ByteBuffer> buffers){
```

有一批缓冲区到达时调用。

## 第 24 行

```java
            for(ByteBuffer buffer:buffers){
```

遍历当前批次每块 ByteBuffer。

## 第 25 行

```java
                if(bytes.size()+buffer.remaining()>limit){subscription.cancel();result.completeExceptionally(new IllegalArgumentException("模型返回数据过大"));return;}
```

当前累计+剩余字节超过上限就取消上游、将 Future 标为异常并结束。

## 第 26 行

```java
                byte[] chunk=new byte[buffer.remaining()];buffer.get(chunk);bytes.write(chunk,0,chunk.length);
```

按剩余大小创建字节数组，取出缓冲内容，追加到输出缓冲。

## 第 27 行

```java
            }subscription.request(1);
```

本批处理完后再请求下一批，不无界请求。

## 第 28 行

```java
        }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 29 行

```java
        public void onError(Throwable error){result.completeExceptionally(error);}
```

上游失败时让 Future 以同一异常结束。

## 第 30 行

```java
        public void onComplete(){result.complete(bytes.toByteArray());}
```

上游结束时把累计结果复制为 byte[] 完成 Future。

## 第 31 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 32 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
