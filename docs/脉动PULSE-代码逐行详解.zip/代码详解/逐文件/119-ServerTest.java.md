# server/src/test/java/com/pulse/server/ServerTest.java

四项 HTTP 集成测试：服务绑定回环临时端口，模型上游用本机假服务代替，无需真实 key 或部署模型。

原文件 SHA-256：`8fbbe29635770f547ed31743f17436a181d770a580fac56abc220f10467f9052`。行号仅对应此快照；修改源码后应重新核对。

共 48 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```java
package com.pulse.server;
```

声明本文件所属包 com.pulse.server；包用于命名与访问控制，目录按包名分层，不能把它当作创建对象的语句。

## 第 2 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 3 行

```java
import org.junit.*;
```

导入类型命名空间 org.junit.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 4 行

```java
import static org.junit.Assert.*;
```

静态导入 org.junit.Assert.*，后面可直接写枚举项或断言方法名。

## 第 5 行

```java
import com.google.gson.*;
```

导入类型命名空间 com.google.gson.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 6 行

```java
import com.pulse.core.model.*;
```

导入类型命名空间 com.pulse.core.model.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 7 行

```java
import com.pulse.core.plan.*;
```

导入类型命名空间 com.pulse.core.plan.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 8 行

```java
import com.pulse.core.util.JsonCodec;
```

导入类型命名空间 com.pulse.core.util.JsonCodec，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 9 行

```java
import java.net.*;
```

导入类型命名空间 java.net.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 10 行

```java
import java.net.http.*;
```

导入类型命名空间 java.net.http.*，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 11 行

```java
import java.time.Duration;
```

导入类型命名空间 java.time.Duration，后面可用短类型名，不必每次写完整包名；* 表示按需解析该包下类型，不会导入子包，也不在此创建对象。

## 第 12 行

```java
// （原文件此行为空）
```

空行，仅用于分隔成员或语句，不执行任何操作。

## 第 13 行

```java
public class ServerTest {
```

定义 public class ServerTest。本行开始类型作用域；public 对包外可见，final 类不能再被继承，abstract 类不能直接 new。

## 第 14 行

```java
    private FitnessServer server;
```

当前测试服务引用。

## 第 15 行

```java
    private final HttpClient client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
```

测试 HTTP 客户端，连接超时 2 秒。

## 第 16 行

```java
    private static final String TOKEN="test-token-with-24-characters";
```

测试固定令牌，不是生产凭据。

## 第 17 行

```java
    @After public void stop(){if(server!=null)server.stop();}
```

@After 保证每个测试结束后停止服务，失败也执行。

## 第 18 行

```java
    private void start(PlanGenerator generator)throws Exception{server=new FitnessServer("127.0.0.1",0,TOKEN,"test",generator);server.start();}
```

监听 127.0.0.1:0 让系统选空闲端口，并注入测试生成器。

## 第 19 行

```java
    private HttpResponse<String> post(String path,String body,String token)throws Exception{
```

通用测试 POST 帮助函数。

## 第 20 行

```java
        HttpRequest.Builder b=HttpRequest.newBuilder(URI.create("http://127.0.0.1:"+server.port()+path)).timeout(Duration.ofSeconds(5)).header("Content-Type","application/json");if(token!=null)b.header("Authorization","Bearer "+token);
```

建临时服务 URI，5 秒超时、JSON 类型；token 非 null 才加 Authorization。

## 第 21 行

```java
        return client.send(b.POST(HttpRequest.BodyPublishers.ofString(body)).build(),HttpResponse.BodyHandlers.ofString());
```

同步发 POST 并把响应正文读成字符串，测试线程可以阻塞。

## 第 22 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 23 行

```java
    @Test public void authValidationAndLocalModeAreHonest()throws Exception{
```

检查认证、档案错误和无模型模式。

## 第 24 行

```java
        start(null);String body=JsonCodec.profile(UserProfile.defaults());assertEquals(401,post("/api/v1/plans",body,null).statusCode());assertEquals(400,post("/api/v1/plans","{}",TOKEN).statusCode());
```

无模型启动；无令牌必须 401，带令牌但空档案必须 400。

## 第 25 行

```java
        assertEquals(400,post("/api/v1/plans",JsonCodec.profile(UserProfile.defaults().toBuilder().age(16).build()),TOKEN).statusCode());
```

16 岁档案自动训练请求必须 400。

## 第 26 行

```java
        HttpResponse<String> response=post("/api/v1/plans",body,TOKEN);assertEquals(200,response.statusCode());JsonObject json=JsonParser.parseString(response.body()).getAsJsonObject();WeekPlan p=JsonCodec.plan(json.get("plan").toString());assertEquals(WeekPlan.Source.LOCAL,p.source);PlanSafety.validate(p,UserProfile.defaults());
```

合法请求应 200；解析计划，确认 LOCAL 来源并通过安全检查。

## 第 27 行

```java
        assertEquals(413,post("/api/v1/plans","x".repeat(32769),TOKEN).statusCode());assertEquals(404,post("/api/v1/plans/unknown",body,TOKEN).statusCode());
```

32769 字节正文必须 413；多余子路径必须 404。

## 第 28 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 29 行

```java
    @Test public void modelFailureFallsBackInsteadOfPretendingAiSucceeded()throws Exception{
```

检查模型失败回退仍诚实标注本地。

## 第 30 行

```java
        start(p->{throw new java.io.IOException("provider secret must never leak");});HttpResponse<String> response=post("/api/v1/plans",JsonCodec.profile(UserProfile.defaults()),TOKEN);
```

注入一调用就抛 IOException 的假模型，异常里放秘密样本文本以检查它不会泄露。

## 第 31 行

```java
        assertEquals(200,response.statusCode());assertTrue(response.body().contains("LOCAL"));assertTrue(response.body().contains("本地规则"));assertFalse(response.body().contains("provider secret"));
```

最终仍应 200，含 LOCAL 和本地规则提示，不含原始秘密异常。

## 第 32 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 33 行

```java
    @Test public void compatibleAdapterAcceptsValidJsonAndRejectsHallucinations()throws Exception{
```

检查适配器能清除包装文本并拒绝模型编造动作。

## 第 34 行

```java
        UserProfile p=UserProfile.defaults();WeekPlan local=new LocalPlanGenerator().generate(p);JsonObject payload=JsonParser.parseString(JsonCodec.plan(local)).getAsJsonObject();
```

先生成已知合法计划，把它变为假上游 JSON。

## 第 35 行

```java
        WeekPlan ai=CompatibleLlmAdapter.adapt("<think>hidden</think>\n```json\n"+payload+"\n```",p);assertEquals(WeekPlan.Source.AI,ai.source);
```

用 think 标签及代码围栏包装后 adapt，检查来源由服务端设为 AI。

## 第 36 行

```java
        String bad=payload.toString().replace("wall_push","invented_dangerous_action");
```

初步尝试替换 wall_push；下一条实际替换会覆盖这个变量，所以此行不是最终测试依据。

## 第 37 行

```java
        // Find an actual first exercise rather than depending on goal sort order.
```

源码注释，不参与执行。使用实际第一个动作 ID 构造非法替换，不假设策略排序一定把 wall_push 排在首位。

## 第 38 行

```java
        bad=payload.toString().replace(local.days.get(0).exercises.get(0).exerciseId,"invented_dangerous_action");String invalid=bad;
```

从实际第一个处方取 ID 再替换成不存在 ID，保证不依赖排序先后；复制到 invalid 供 Lambda 捕获。

## 第 39 行

```java
        assertThrows(RuntimeException.class,()->CompatibleLlmAdapter.adapt(invalid,p));
```

适配非法动作必须抛异常。

## 第 40 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 41 行

```java
    @Test public void actualHttpAdapterSendsOnlyNeededModelProfile()throws Exception{
```

检查真实 HTTP 适配请求只向模型发必要资料。

## 第 42 行

```java
        UserProfile p=UserProfile.defaults().toBuilder().name("private-name").sex("女").build();WeekPlan local=new LocalPlanGenerator().generate(p);
```

设置私密昵称与性别，准备合法本地计划作假模型响应。

## 第 43 行

```java
        com.sun.net.httpserver.HttpServer upstream=com.sun.net.httpserver.HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
```

启动前创建临时回环 HTTP 上游。

## 第 44 行

```java
        java.util.concurrent.atomic.AtomicReference<String> request=new java.util.concurrent.atomic.AtomicReference<>();
```

AtomicReference 保存实际收到的上游请求，便于不同线程间传递。

## 第 45 行

```java
        upstream.createContext("/v1/chat/completions",e->{request.set(new String(e.getRequestBody().readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));JsonObject message=new JsonObject();message.addProperty("content",JsonCodec.plan(local));JsonObject choice=new JsonObject();choice.add("message",message);JsonArray choices=new JsonArray();choices.add(choice);JsonObject response=new JsonObject();response.add("choices",choices);FitnessServer.json(e,200,response.toString());});upstream.start();
```

注册兼容 /v1/chat/completions；捕获请求，按 choices[0].message.content 形状返回合法计划，然后启动假服务。

## 第 46 行

```java
        try{start(new CompatibleLlmAdapter("http://127.0.0.1:"+upstream.getAddress().getPort()+"/v1","test",""));HttpResponse<String> response=post("/api/v1/plans",JsonCodec.profile(p),TOKEN);assertEquals(200,response.statusCode());assertTrue(response.body().contains("\"source\":\"AI\""));assertFalse(request.get().contains("private-name"));assertFalse(request.get().contains("\\\"sex\\\""));assertTrue(request.get().contains("wall_push"));}finally{upstream.stop(0);}
```

启动真实适配器并向网关发请求；应得到 AI 来源，捕获上游报文不含昵称/性别字段且含动作白名单，finally 停掉假上游。

## 第 47 行

```java
    }
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。

## 第 48 行

```java
}
```

关闭或界定当前代码作用域；} 对应最近未关闭的 {，; 结束声明。仅此行不发起新的业务操作。
