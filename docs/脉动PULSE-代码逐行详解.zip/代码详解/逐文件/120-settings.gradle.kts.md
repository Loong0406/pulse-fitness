# settings.gradle.kts

Gradle 项目入口，决定仓库和包含哪些模块；在 Android Studio 应打开包含它的 fitness-sever 文件夹。

原文件 SHA-256：`95319f8e53453689a1bfe763e5507ff04644e8e2c4f282b5a89d545acef41c3f`。行号仅对应此快照；修改源码后应重新核对。

共 8 行。下面每行均先列原代码，再解释；同一行的多语句按执行顺序说明。

## 第 1 行

```text
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
```

为插件解析配置 Google、MavenCentral、Gradle 插件门户；与普通依赖仓库分开。

## 第 2 行

```text
dependencyResolutionManagement {
```

开始配置所有模块共用的依赖解析规则。

## 第 3 行

```text
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
```

禁止子模块自行声明仓库，依赖来源统一在这里管理。

## 第 4 行

```text
    repositories { google(); mavenCentral() }
```

业务依赖从 Google 和 MavenCentral 查找。

## 第 5 行

```text
}
```

结束依赖解析配置块。

## 第 6 行

```text
rootProject.name = "PulseFitness"
```

工程逻辑名 PulseFitness，影响 IDE 项目显示和模块命名。

## 第 7 行

```text
include(":core", ":server")
```

总是包含纯 Java 核心模块 core 和可选 HTTP 网关 server。

## 第 8 行

```text
if (providers.gradleProperty("serverOnly").orNull != "true") include(":app")
```

没有传 -PserverOnly=true 时才包含 app；服务器机器可只构建 Java 模块，不要求 Android SDK。
